package RTC;


/**
* RTC/ActArrayActuatorStatus.java .
* IDL-to-Java\u30b3\u30f3\u30d1\u30a4\u30e9(\u30dd\u30fc\u30bf\u30d6\u30eb)\u3001\u30d0\u30fc\u30b8\u30e7\u30f3"3.2"\u306b\u3088\u3063\u3066\u751f\u6210\u3055\u308c\u307e\u3057\u305f
* idl/InterfaceDataTypes.idl\u304b\u3089
* 2016\u5e7411\u67081\u65e5 15\u664208\u520616\u79d2 JST
*/


/*!
     * @enum ActArrayActuatorStatus
     * @brief Describes the status of an actuator.
     */
public class ActArrayActuatorStatus implements org.omg.CORBA.portable.IDLEntity
{
  private        int __value;
  private static int __size = 4;
  private static RTC.ActArrayActuatorStatus[] __array = new RTC.ActArrayActuatorStatus [__size];

  public static final int _ACTUATOR_STATUS_IDLE = 0;
  public static final RTC.ActArrayActuatorStatus ACTUATOR_STATUS_IDLE = new RTC.ActArrayActuatorStatus(_ACTUATOR_STATUS_IDLE);
  public static final int _ACTUATOR_STATUS_MOVING = 1;
  public static final RTC.ActArrayActuatorStatus ACTUATOR_STATUS_MOVING = new RTC.ActArrayActuatorStatus(_ACTUATOR_STATUS_MOVING);
  public static final int _ACTUATOR_STATUS_BRAKED = 2;
  public static final RTC.ActArrayActuatorStatus ACTUATOR_STATUS_BRAKED = new RTC.ActArrayActuatorStatus(_ACTUATOR_STATUS_BRAKED);
  public static final int _ACTUATOR_STATUS_STALLED = 3;
  public static final RTC.ActArrayActuatorStatus ACTUATOR_STATUS_STALLED = new RTC.ActArrayActuatorStatus(_ACTUATOR_STATUS_STALLED);

  public int value ()
  {
    return __value;
  }

  public static RTC.ActArrayActuatorStatus from_int (int value)
  {
    if (value >= 0 && value < __size)
      return __array[value];
    else
      throw new org.omg.CORBA.BAD_PARAM ();
  }

  protected ActArrayActuatorStatus (int value)
  {
    __value = value;
    __array[__value] = this;
  }
} // class ActArrayActuatorStatus
