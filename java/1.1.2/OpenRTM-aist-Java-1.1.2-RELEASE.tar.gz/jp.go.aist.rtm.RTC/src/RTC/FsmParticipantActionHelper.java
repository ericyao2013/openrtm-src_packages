package RTC;


/**
* RTC/FsmParticipantActionHelper.java .
* IDL-to-Java\u30b3\u30f3\u30d1\u30a4\u30e9(\u30dd\u30fc\u30bf\u30d6\u30eb)\u3001\u30d0\u30fc\u30b8\u30e7\u30f3"3.2"\u306b\u3088\u3063\u3066\u751f\u6210\u3055\u308c\u307e\u3057\u305f
* idl/LogicalTimeTriggeredEC.idl\u304b\u3089
* 2016\u5e7411\u67081\u65e5 15\u664208\u520620\u79d2 JST
*/


/*!
   * @if jp
   * @brief 
   * @else
   * @brief FsmParticipantAction
   *
   * @section Description
   *
   * FsmParticipantAction is companion to ComponentAction (see Section
   * 5.2.2.4) that is intended for use with FSM participant RTCs. It
   * adds a callback for the interception of state transitions, state
   * entries, and state exits.
   *
   * @endif
   */
abstract public class FsmParticipantActionHelper
{
  private static String  _id = "IDL:omg.org/RTC/FsmParticipantAction:1.0";

  public static void insert (org.omg.CORBA.Any a, RTC.FsmParticipantAction that)
  {
    org.omg.CORBA.portable.OutputStream out = a.create_output_stream ();
    a.type (type ());
    write (out, that);
    a.read_value (out.create_input_stream (), type ());
  }

  public static RTC.FsmParticipantAction extract (org.omg.CORBA.Any a)
  {
    return read (a.create_input_stream ());
  }

  private static org.omg.CORBA.TypeCode __typeCode = null;
  synchronized public static org.omg.CORBA.TypeCode type ()
  {
    if (__typeCode == null)
    {
      __typeCode = org.omg.CORBA.ORB.init ().create_interface_tc (RTC.FsmParticipantActionHelper.id (), "FsmParticipantAction");
    }
    return __typeCode;
  }

  public static String id ()
  {
    return _id;
  }

  public static RTC.FsmParticipantAction read (org.omg.CORBA.portable.InputStream istream)
  {
    return narrow (istream.read_Object (_FsmParticipantActionStub.class));
  }

  public static void write (org.omg.CORBA.portable.OutputStream ostream, RTC.FsmParticipantAction value)
  {
    ostream.write_Object ((org.omg.CORBA.Object) value);
  }

  public static RTC.FsmParticipantAction narrow (org.omg.CORBA.Object obj)
  {
    if (obj == null)
      return null;
    else if (obj instanceof RTC.FsmParticipantAction)
      return (RTC.FsmParticipantAction)obj;
    else if (!obj._is_a (id ()))
      throw new org.omg.CORBA.BAD_PARAM ();
    else
    {
      org.omg.CORBA.portable.Delegate delegate = ((org.omg.CORBA.portable.ObjectImpl)obj)._get_delegate ();
      RTC._FsmParticipantActionStub stub = new RTC._FsmParticipantActionStub ();
      stub._set_delegate(delegate);
      return stub;
    }
  }

  public static RTC.FsmParticipantAction unchecked_narrow (org.omg.CORBA.Object obj)
  {
    if (obj == null)
      return null;
    else if (obj instanceof RTC.FsmParticipantAction)
      return (RTC.FsmParticipantAction)obj;
    else
    {
      org.omg.CORBA.portable.Delegate delegate = ((org.omg.CORBA.portable.ObjectImpl)obj)._get_delegate ();
      RTC._FsmParticipantActionStub stub = new RTC._FsmParticipantActionStub ();
      stub._set_delegate(delegate);
      return stub;
    }
  }

}
