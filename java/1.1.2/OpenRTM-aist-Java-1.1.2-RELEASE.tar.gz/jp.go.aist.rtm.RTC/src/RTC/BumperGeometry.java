package RTC;


/**
* RTC/BumperGeometry.java .
* IDL-to-Java\u30b3\u30f3\u30d1\u30a4\u30e9(\u30dd\u30fc\u30bf\u30d6\u30eb)\u3001\u30d0\u30fc\u30b8\u30e7\u30f3"3.2"\u306b\u3088\u3063\u3066\u751f\u6210\u3055\u308c\u307e\u3057\u305f
* idl/InterfaceDataTypes.idl\u304b\u3089
* 2016\u5e7411\u67081\u65e5 15\u664208\u520616\u79d2 JST
*/

public final class BumperGeometry implements org.omg.CORBA.portable.IDLEntity
{

  /// Pose of the bumper's base point in the array's coordinate space.
  public RTC.Pose3D pose = null;

  /// Size of the bumper.
  public RTC.Size3D size = null;

  /// Radius of curvature of the bump sensor in metres. Zero if the bumper is a straight line.
  public double roc = (double)0;

  public BumperGeometry ()
  {
  } // ctor

  public BumperGeometry (RTC.Pose3D _pose, RTC.Size3D _size, double _roc)
  {
    pose = _pose;
    size = _size;
    roc = _roc;
  } // ctor

} // class BumperGeometry
