package RTC;


/**
* RTC/PortInterfacePolarity.java .
* IDL-to-Java\u30b3\u30f3\u30d1\u30a4\u30e9(\u30dd\u30fc\u30bf\u30d6\u30eb)\u3001\u30d0\u30fc\u30b8\u30e7\u30f3"3.2"\u306b\u3088\u3063\u3066\u751f\u6210\u3055\u308c\u307e\u3057\u305f
* idl/LogicalTimeTriggeredEC.idl\u304b\u3089
* 2016\u5e7411\u67081\u65e5 15\u664208\u520620\u79d2 JST
*/


/*!
   * @if jp
   * @brief 
   * @else
   * @brief PortInterfacePolarity
   *
   * @section Description
   *
   * The PortInterfacePolarity enumeration identifies exposed
   * interface instances as provided or required.  @endif
   */
public class PortInterfacePolarity implements org.omg.CORBA.portable.IDLEntity
{
  private        int __value;
  private static int __size = 2;
  private static RTC.PortInterfacePolarity[] __array = new RTC.PortInterfacePolarity [__size];

  public static final int _PROVIDED = 0;
  public static final RTC.PortInterfacePolarity PROVIDED = new RTC.PortInterfacePolarity(_PROVIDED);
  public static final int _REQUIRED = 1;
  public static final RTC.PortInterfacePolarity REQUIRED = new RTC.PortInterfacePolarity(_REQUIRED);

  public int value ()
  {
    return __value;
  }

  public static RTC.PortInterfacePolarity from_int (int value)
  {
    if (value >= 0 && value < __size)
      return __array[value];
    else
      throw new org.omg.CORBA.BAD_PARAM ();
  }

  protected PortInterfacePolarity (int value)
  {
    __value = value;
    __array[__value] = this;
  }
} // class PortInterfacePolarity
