package RTC;


/**
* RTC/PointFeature.java .
* IDL-to-Java\u30b3\u30f3\u30d1\u30a4\u30e9(\u30dd\u30fc\u30bf\u30d6\u30eb)\u3001\u30d0\u30fc\u30b8\u30e7\u30f3"3.2"\u306b\u3088\u3063\u3066\u751f\u6210\u3055\u308c\u307e\u3057\u305f
* idl/InterfaceDataTypes.idl\u304b\u3089
* 2016\u5e7411\u67081\u65e5 15\u664208\u520616\u79d2 JST
*/

public final class PointFeature implements org.omg.CORBA.portable.IDLEntity
{

  /// Probability of the feature.
  public double probability = (double)0;

  /// Position of the feature.
  public RTC.Point2D position = null;

  /// Covariance matrix of the position.
  public RTC.PointCovariance2D covariance = null;

  public PointFeature ()
  {
  } // ctor

  public PointFeature (double _probability, RTC.Point2D _position, RTC.PointCovariance2D _covariance)
  {
    probability = _probability;
    position = _position;
    covariance = _covariance;
  } // ctor

} // class PointFeature
