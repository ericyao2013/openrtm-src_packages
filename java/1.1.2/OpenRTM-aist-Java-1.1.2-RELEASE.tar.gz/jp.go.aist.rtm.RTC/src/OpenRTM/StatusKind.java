package OpenRTM;


/**
* OpenRTM/StatusKind.java .
* IDL-to-Java\u30b3\u30f3\u30d1\u30a4\u30e9(\u30dd\u30fc\u30bf\u30d6\u30eb)\u3001\u30d0\u30fc\u30b8\u30e7\u30f3"3.2"\u306b\u3088\u3063\u3066\u751f\u6210\u3055\u308c\u307e\u3057\u305f
* idl/ComponentObserver.idl\u304b\u3089
* 2016\u5e7411\u67081\u65e5 15\u664208\u520617\u79d2 JST
*/


/*!
   * @if jp
   *
   * @brief \u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd?\u00fd\u00fd\u00fd\u00a4\u00bc\u00fd\u00fd\u00fd
   * 
   * \u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00e5\u00fdRTC\u00fd\u00f9\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd?\u00fd\u00fd\u00fd\u00a4\u00bc\u00fd\u00fd\u00fd\u00fd\u00ac\u00fd9\u00fd\u00fd\u00fd\u00fd\u009f\u00e1\u00fd
   * 
   * @else
   *
   * @brief A kind of updated status
   * 
   * This is a enumeration type to classify updated status in target RTC.
   *
   * @endif
   */
public class StatusKind implements org.omg.CORBA.portable.IDLEntity
{
  private        int __value;
  private static int __size = 7;
  private static OpenRTM.StatusKind[] __array = new OpenRTM.StatusKind [__size];

  public static final int _COMPONENT_PROFILE = 0;
  public static final OpenRTM.StatusKind COMPONENT_PROFILE = new OpenRTM.StatusKind(_COMPONENT_PROFILE);
  public static final int _RTC_STATUS = 1;
  public static final OpenRTM.StatusKind RTC_STATUS = new OpenRTM.StatusKind(_RTC_STATUS);
  public static final int _EC_STATUS = 2;
  public static final OpenRTM.StatusKind EC_STATUS = new OpenRTM.StatusKind(_EC_STATUS);
  public static final int _PORT_PROFILE = 3;
  public static final OpenRTM.StatusKind PORT_PROFILE = new OpenRTM.StatusKind(_PORT_PROFILE);
  public static final int _CONFIGURATION = 4;
  public static final OpenRTM.StatusKind CONFIGURATION = new OpenRTM.StatusKind(_CONFIGURATION);
  public static final int _HEARTBEAT = 5;
  public static final OpenRTM.StatusKind HEARTBEAT = new OpenRTM.StatusKind(_HEARTBEAT);
  public static final int _STATUS_KIND_NUM = 6;
  public static final OpenRTM.StatusKind STATUS_KIND_NUM = new OpenRTM.StatusKind(_STATUS_KIND_NUM);

  public int value ()
  {
    return __value;
  }

  public static OpenRTM.StatusKind from_int (int value)
  {
    if (value >= 0 && value < __size)
      return __array[value];
    else
      throw new org.omg.CORBA.BAD_PARAM ();
  }

  protected StatusKind (int value)
  {
    __value = value;
    __array[__value] = this;
  }
} // class StatusKind
