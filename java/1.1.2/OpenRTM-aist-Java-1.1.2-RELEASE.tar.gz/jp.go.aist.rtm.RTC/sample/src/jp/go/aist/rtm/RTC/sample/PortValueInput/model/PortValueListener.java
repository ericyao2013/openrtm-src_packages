package jp.go.aist.rtm.RTC.sample.PortValueInput.model;

public interface PortValueListener {

    public void onChanged(final PortValue portValue);
}
