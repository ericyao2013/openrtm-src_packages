package RTC;


/**
* RTC/OGMapConfig.java .
* IDL-to-Java\u30b3\u30f3\u30d1\u30a4\u30e9(\u30dd\u30fc\u30bf\u30d6\u30eb)\u3001\u30d0\u30fc\u30b8\u30e7\u30f3"3.2"\u306b\u3088\u3063\u3066\u751f\u6210\u3055\u308c\u307e\u3057\u305f
* idl/InterfaceDataTypes.idl\u304b\u3089
* 2016\u5e7411\u67081\u65e5 15\u664208\u520616\u79d2 JST
*/

public final class OGMapConfig implements org.omg.CORBA.portable.IDLEntity
{

  /// Scale on the x axis (metres per cell).
  public double xScale = (double)0;

  /// Scale on the y axis (metres per cell).
  public double yScale = (double)0;

  /// Number of cells along the x axis.
  public int width = (int)0;

  /// Number of cells along the y axis.
  public int height = (int)0;

  /// Pose of the cell at (0, 0) in the real world.
  public RTC.Pose2D origin = null;

  public OGMapConfig ()
  {
  } // ctor

  public OGMapConfig (double _xScale, double _yScale, int _width, int _height, RTC.Pose2D _origin)
  {
    xScale = _xScale;
    yScale = _yScale;
    width = _width;
    height = _height;
    origin = _origin;
  } // ctor

} // class OGMapConfig
