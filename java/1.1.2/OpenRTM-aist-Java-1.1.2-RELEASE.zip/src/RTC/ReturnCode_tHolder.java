package RTC;

/**
* RTC/ReturnCode_tHolder.java .
* IDL-to-Java\u30b3\u30f3\u30d1\u30a4\u30e9(\u30dd\u30fc\u30bf\u30d6\u30eb)\u3001\u30d0\u30fc\u30b8\u30e7\u30f3"3.2"\u306b\u3088\u3063\u3066\u751f\u6210\u3055\u308c\u307e\u3057\u305f
* idl/LogicalTimeTriggeredEC.idl\u304b\u3089
* 2016\u5e7411\u67081\u65e5 15\u664208\u520620\u79d2 JST
*/


/*!
   * @if jp
   * @brief ReturnCode_t
   *
   * OMG RTC 1.0 \u00fdd\u00fdl\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fdI\u00fdy\u00fd\u00fd\u00fd[\u00fdV\u00fd\u00fd\u00fd\u00fd\u00fdAA\u00fdN\u00fd\u00fd\u00fdC\u00fd\u00fd\u00fd\u0082Q\u0082\u00fd\u00fd
l\u00fd\u00fd
   * \u00fd\u00fd\u00fd\u00fdG\u00fd\u00fd\u00fd[\u00fd\u00fd\u00fd\u00f5\u00fd\u00fd\u00fdK\u00fdv\u00fd\u00fd\u00fd\u00fd\u00fd\u00fdB\u00fd\u00fd\u00fd\u00fdAAReturnCode_t\u00fd^\u00fd\u00fd\u00fd\u00fd
   * \u00fd\u00fd\u00fd^\u00fd[\u00fd\u00fd\u00fdR\u00fd[\u00fdh\u00fdB\u00fd\u00fds\u00fd\u00fd\u00fd\u00fdB
   *
   * OMG RTC 1.0 \u00fd\u00fd PIM \u00fd\u00fd\u00fdB\u00fd\u00fd\u00fd\u00fdAReturnCode_t\u00fd^\u00fdl\u00fd\u00fd\u00fd\u00fd\u00fd\u00fdI\u00fdy\u00fd\u00fd\u00fd[\u00fdV\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd
   * \u00fd\u00fd\u00fd\u00fd\u00fd\u00c2\u00fdl\u00fd^\u00fdH\u00d1\u00fd\u00fd\u00fd\u00fdA\u00fd\u00fd\u00fd\u00fd@\u00fdB\u00fd\u00fdG\u00fd\u00fd\u00fd[\u00fd\u00fd\u00f5\u00fd\u00fd\u00fd\u00fd\u00fd\u0082\u00fd\u00fd\u00fdB
   * -\u00fdI\u00fdy\u00fd\u00fd\u00fd[\u00fdV\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fdl\u00fd\u00fd\u00fd\u00fdG (OMG RTC 1.0 Section 5.2.2.6.4 \u00fd\u00fd
   *  get_rate\u00fd\u00a4\u00fd\u00fd)\u00fdA\u00fd\u00fd\u00fd\u00fd\u00fdl\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u0082B\u00fd\u00fdG\u00fd\u00fd\u00fd[\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u0082\u00fd\u00fd\u00fdB
   * - \u00fdI\u00fdy\u00fd\u00fd\u00fd[\u00fdV\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fdI\u00fdu\u00fdW\u00fdF\u00fdN\u00fdg\u00fd\u00fd\u00fdt\u00fd@\u00fd\u00fd\u00fd\u00fd\u00fdX(RTObject::get_component_profile
   *   OMG RTC 1.0 5.4.2.2.1\u00fd\u00fd\u00fdQ\u00fd\u00fd) \u00fd\u00fd\u008f\u00fd\u00fd\u00fdG\u00fdAnil\u00fdQ\u00fd\u0082\u00fd\u00fd\u00fd\u00fd\u00fd\u0082B\u00fd\u00fd
   *   \u00fdG\u00fd\u00fd\u00fd[\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u0082\u00fd\u00fd\u00fdB
   *
   * @else
   * @brief ReturnCode_t
   *
   * A number of operations in this specification will need to report
   * potential error conditions to their clients. This task shall be
   * accomplished by means of operation "return codes" of type
   * ReturnCode_t
   *
   * Operations in the PIM that do not return a value of type
   * ReturnCode_t shall report errors in the following ways, depending
   * on their return type:
   * - If an operation normally returns a positive numerical value (such as
   *   get_rate, see [OMG RTC 1.0 Section 5.2.2.6.4]), it shall indicate
   *   failure by returning a negative value.
   * - If an operation normally returns an object reference (such as
   *   RTObject::get_component_profile, see [OMG RTC 1.0 Section 5.4.2.2.1]),
   *   it shall indicate failure by returning a nil reference.
   *
   * @param RTC_OK The operation completed successfully.
   * @param RTC_ERROR The operation failed with a generic, unspecified error.
   * @param BAD_PARAMETER The operation failed because an illegal argument was
   *        passed to it.
   * @param UNSUPPORTED The operation is unsupported by the implementation
   *        (e.g., it belongs to a compliance point that is not implemented).
   * @param OUT_OF_RESOURCES The target of the operation ran out of the
   *        resources needed to complete the operation.
   * @param PRECONDITION_NOT_MET A pre-condition for the operation was not met.
   *
   * @endif
   */
public final class ReturnCode_tHolder implements org.omg.CORBA.portable.Streamable
{
  public RTC.ReturnCode_t value = null;

  public ReturnCode_tHolder ()
  {
  }

  public ReturnCode_tHolder (RTC.ReturnCode_t initialValue)
  {
    value = initialValue;
  }

  public void _read (org.omg.CORBA.portable.InputStream i)
  {
    value = RTC.ReturnCode_tHelper.read (i);
  }

  public void _write (org.omg.CORBA.portable.OutputStream o)
  {
    RTC.ReturnCode_tHelper.write (o, value);
  }

  public org.omg.CORBA.TypeCode _type ()
  {
    return RTC.ReturnCode_tHelper.type ();
  }

}
