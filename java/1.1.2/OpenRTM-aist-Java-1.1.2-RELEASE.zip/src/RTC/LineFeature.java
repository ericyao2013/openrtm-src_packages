package RTC;


/**
* RTC/LineFeature.java .
* IDL-to-Java\u30b3\u30f3\u30d1\u30a4\u30e9(\u30dd\u30fc\u30bf\u30d6\u30eb)\u3001\u30d0\u30fc\u30b8\u30e7\u30f3"3.2"\u306b\u3088\u3063\u3066\u751f\u6210\u3055\u308c\u307e\u3057\u305f
* idl/InterfaceDataTypes.idl\u304b\u3089
* 2016\u5e7411\u67081\u65e5 15\u664208\u520616\u79d2 JST
*/

public final class LineFeature implements org.omg.CORBA.portable.IDLEntity
{

  /// Probability of the feature.
  public double probability = (double)0;

  /// Length of the line vector in metres.
  public double rho = (double)0;

  /// Angle of the line vector from the x axis in radians.
  public double alpha = (double)0;

  /// Covariance matrix of rho and alpha.
  public RTC.PointCovariance2D covariance = null;

  /// Start point of the line segment.
  public RTC.Point2D start = null;

  /// End point of the line segment.
  public RTC.Point2D end = null;

  /// True if the start point of the line has been sighted (i.e. it is inside seen space).
  public boolean startSighted = false;

  /// True if the end point of the line has been sighted (i.e. it is inside seen space).
  public boolean endSighted = false;

  public LineFeature ()
  {
  } // ctor

  public LineFeature (double _probability, double _rho, double _alpha, RTC.PointCovariance2D _covariance, RTC.Point2D _start, RTC.Point2D _end, boolean _startSighted, boolean _endSighted)
  {
    probability = _probability;
    rho = _rho;
    alpha = _alpha;
    covariance = _covariance;
    start = _start;
    end = _end;
    startSighted = _startSighted;
    endSighted = _endSighted;
  } // ctor

} // class LineFeature
