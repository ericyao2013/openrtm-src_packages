package RTC;


/**
* RTC/GPSFixType.java .
* IDL-to-Java\u30b3\u30f3\u30d1\u30a4\u30e9(\u30dd\u30fc\u30bf\u30d6\u30eb)\u3001\u30d0\u30fc\u30b8\u30e7\u30f3"3.2"\u306b\u3088\u3063\u3066\u751f\u6210\u3055\u308c\u307e\u3057\u305f
* idl/InterfaceDataTypes.idl\u304b\u3089
* 2016\u5e7411\u67081\u65e5 15\u664208\u520616\u79d2 JST
*/


/*!
     * @enum GPSFixType
     */
public class GPSFixType implements org.omg.CORBA.portable.IDLEntity
{
  private        int __value;
  private static int __size = 3;
  private static RTC.GPSFixType[] __array = new RTC.GPSFixType [__size];

  public static final int _GPS_FIX_NONE = 0;
  public static final RTC.GPSFixType GPS_FIX_NONE = new RTC.GPSFixType(_GPS_FIX_NONE);
  public static final int _GPS_FIX_NORMAL = 1;
  public static final RTC.GPSFixType GPS_FIX_NORMAL = new RTC.GPSFixType(_GPS_FIX_NORMAL);
  public static final int _GPS_FIX_DGPS = 2;
  public static final RTC.GPSFixType GPS_FIX_DGPS = new RTC.GPSFixType(_GPS_FIX_DGPS);

  public int value ()
  {
    return __value;
  }

  public static RTC.GPSFixType from_int (int value)
  {
    if (value >= 0 && value < __size)
      return __array[value];
    else
      throw new org.omg.CORBA.BAD_PARAM ();
  }

  protected GPSFixType (int value)
  {
    __value = value;
    __array[__value] = this;
  }
} // class GPSFixType
