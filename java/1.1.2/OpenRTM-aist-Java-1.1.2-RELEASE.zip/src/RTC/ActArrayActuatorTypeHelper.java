package RTC;


/**
* RTC/ActArrayActuatorTypeHelper.java .
* IDL-to-Java\u30b3\u30f3\u30d1\u30a4\u30e9(\u30dd\u30fc\u30bf\u30d6\u30eb)\u3001\u30d0\u30fc\u30b8\u30e7\u30f3"3.2"\u306b\u3088\u3063\u3066\u751f\u6210\u3055\u308c\u307e\u3057\u305f
* idl/InterfaceDataTypes.idl\u304b\u3089
* 2016\u5e7411\u67081\u65e5 15\u664208\u520616\u79d2 JST
*/


/*!
     * @enum ActArrayActuatorType
     * @brief Describes the type of an actuator.
     */
abstract public class ActArrayActuatorTypeHelper
{
  private static String  _id = "IDL:RTC/ActArrayActuatorType:1.0";

  public static void insert (org.omg.CORBA.Any a, RTC.ActArrayActuatorType that)
  {
    org.omg.CORBA.portable.OutputStream out = a.create_output_stream ();
    a.type (type ());
    write (out, that);
    a.read_value (out.create_input_stream (), type ());
  }

  public static RTC.ActArrayActuatorType extract (org.omg.CORBA.Any a)
  {
    return read (a.create_input_stream ());
  }

  private static org.omg.CORBA.TypeCode __typeCode = null;
  synchronized public static org.omg.CORBA.TypeCode type ()
  {
    if (__typeCode == null)
    {
      __typeCode = org.omg.CORBA.ORB.init ().create_enum_tc (RTC.ActArrayActuatorTypeHelper.id (), "ActArrayActuatorType", new String[] { "ACTARRAY_ACTUATORTYPE_LINEAR", "ACTARRAY_ACTUATORTYPE_ROTARY"} );
    }
    return __typeCode;
  }

  public static String id ()
  {
    return _id;
  }

  public static RTC.ActArrayActuatorType read (org.omg.CORBA.portable.InputStream istream)
  {
    return RTC.ActArrayActuatorType.from_int (istream.read_long ());
  }

  public static void write (org.omg.CORBA.portable.OutputStream ostream, RTC.ActArrayActuatorType value)
  {
    ostream.write_long (value.value ());
  }

}
