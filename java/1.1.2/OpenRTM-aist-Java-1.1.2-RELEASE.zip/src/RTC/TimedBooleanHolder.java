package RTC;

/**
* RTC/TimedBooleanHolder.java .
* IDL-to-Java\u30b3\u30f3\u30d1\u30a4\u30e9(\u30dd\u30fc\u30bf\u30d6\u30eb)\u3001\u30d0\u30fc\u30b8\u30e7\u30f3"3.2"\u306b\u3088\u3063\u3066\u751f\u6210\u3055\u308c\u307e\u3057\u305f
* idl/Logger.idl\u304b\u3089
* 2016\u5e7411\u67081\u65e5 15\u664208\u520618\u79d2 JST
*/

public final class TimedBooleanHolder implements org.omg.CORBA.portable.Streamable
{
  public RTC.TimedBoolean value = null;

  public TimedBooleanHolder ()
  {
  }

  public TimedBooleanHolder (RTC.TimedBoolean initialValue)
  {
    value = initialValue;
  }

  public void _read (org.omg.CORBA.portable.InputStream i)
  {
    value = RTC.TimedBooleanHelper.read (i);
  }

  public void _write (org.omg.CORBA.portable.OutputStream o)
  {
    RTC.TimedBooleanHelper.write (o, value);
  }

  public org.omg.CORBA.TypeCode _type ()
  {
    return RTC.TimedBooleanHelper.type ();
  }

}
