package RTC;


/**
* RTC/LimbStatus.java .
* IDL-to-Java\u30b3\u30f3\u30d1\u30a4\u30e9(\u30dd\u30fc\u30bf\u30d6\u30eb)\u3001\u30d0\u30fc\u30b8\u30e7\u30f3"3.2"\u306b\u3088\u3063\u3066\u751f\u6210\u3055\u308c\u307e\u3057\u305f
* idl/InterfaceDataTypes.idl\u304b\u3089
* 2016\u5e7411\u67081\u65e5 15\u664208\u520616\u79d2 JST
*/


/*!
     * @enum LimbStatus
     */
public class LimbStatus implements org.omg.CORBA.portable.IDLEntity
{
  private        int __value;
  private static int __size = 5;
  private static RTC.LimbStatus[] __array = new RTC.LimbStatus [__size];

  public static final int _LIMB_STATUS_IDLE = 0;
  public static final RTC.LimbStatus LIMB_STATUS_IDLE = new RTC.LimbStatus(_LIMB_STATUS_IDLE);
  public static final int _LIMB_STATUS_BRAKED = 1;
  public static final RTC.LimbStatus LIMB_STATUS_BRAKED = new RTC.LimbStatus(_LIMB_STATUS_BRAKED);
  public static final int _LIMB_STATUS_MOVING = 2;
  public static final RTC.LimbStatus LIMB_STATUS_MOVING = new RTC.LimbStatus(_LIMB_STATUS_MOVING);
  public static final int _LIMB_STATUS_OOR = 3;
  public static final RTC.LimbStatus LIMB_STATUS_OOR = new RTC.LimbStatus(_LIMB_STATUS_OOR);
  public static final int _LIMB_STATUS_COLLISION = 4;
  public static final RTC.LimbStatus LIMB_STATUS_COLLISION = new RTC.LimbStatus(_LIMB_STATUS_COLLISION);

  public int value ()
  {
    return __value;
  }

  public static RTC.LimbStatus from_int (int value)
  {
    if (value >= 0 && value < __size)
      return __array[value];
    else
      throw new org.omg.CORBA.BAD_PARAM ();
  }

  protected LimbStatus (int value)
  {
    __value = value;
    __array[__value] = this;
  }
} // class LimbStatus
