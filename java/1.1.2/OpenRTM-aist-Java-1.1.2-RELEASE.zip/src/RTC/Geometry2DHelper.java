package RTC;


/**
* RTC/Geometry2DHelper.java .
* IDL-to-Java\u30b3\u30f3\u30d1\u30a4\u30e9(\u30dd\u30fc\u30bf\u30d6\u30eb)\u3001\u30d0\u30fc\u30b8\u30e7\u30f3"3.2"\u306b\u3088\u3063\u3066\u751f\u6210\u3055\u308c\u307e\u3057\u305f
* idl/InterfaceDataTypes.idl\u304b\u3089
* 2016\u5e7411\u67081\u65e5 15\u664208\u520616\u79d2 JST
*/

abstract public class Geometry2DHelper
{
  private static String  _id = "IDL:RTC/Geometry2D:1.0";

  public static void insert (org.omg.CORBA.Any a, RTC.Geometry2D that)
  {
    org.omg.CORBA.portable.OutputStream out = a.create_output_stream ();
    a.type (type ());
    write (out, that);
    a.read_value (out.create_input_stream (), type ());
  }

  public static RTC.Geometry2D extract (org.omg.CORBA.Any a)
  {
    return read (a.create_input_stream ());
  }

  private static org.omg.CORBA.TypeCode __typeCode = null;
  private static boolean __active = false;
  synchronized public static org.omg.CORBA.TypeCode type ()
  {
    if (__typeCode == null)
    {
      synchronized (org.omg.CORBA.TypeCode.class)
      {
        if (__typeCode == null)
        {
          if (__active)
          {
            return org.omg.CORBA.ORB.init().create_recursive_tc ( _id );
          }
          __active = true;
          org.omg.CORBA.StructMember[] _members0 = new org.omg.CORBA.StructMember [2];
          org.omg.CORBA.TypeCode _tcOf_members0 = null;
          _tcOf_members0 = RTC.Pose2DHelper.type ();
          _members0[0] = new org.omg.CORBA.StructMember (
            "pose",
            _tcOf_members0,
            null);
          _tcOf_members0 = RTC.Size2DHelper.type ();
          _members0[1] = new org.omg.CORBA.StructMember (
            "size",
            _tcOf_members0,
            null);
          __typeCode = org.omg.CORBA.ORB.init ().create_struct_tc (RTC.Geometry2DHelper.id (), "Geometry2D", _members0);
          __active = false;
        }
      }
    }
    return __typeCode;
  }

  public static String id ()
  {
    return _id;
  }

  public static RTC.Geometry2D read (org.omg.CORBA.portable.InputStream istream)
  {
    RTC.Geometry2D value = new RTC.Geometry2D ();
    value.pose = RTC.Pose2DHelper.read (istream);
    value.size = RTC.Size2DHelper.read (istream);
    return value;
  }

  public static void write (org.omg.CORBA.portable.OutputStream ostream, RTC.Geometry2D value)
  {
    RTC.Pose2DHelper.write (ostream, value.pose);
    RTC.Size2DHelper.write (ostream, value.size);
  }

}
