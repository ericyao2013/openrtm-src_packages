package RTC;


/**
* RTC/ReturnCode_tHelper.java .
* IDL-to-Java\u30b3\u30f3\u30d1\u30a4\u30e9(\u30dd\u30fc\u30bf\u30d6\u30eb)\u3001\u30d0\u30fc\u30b8\u30e7\u30f3"3.2"\u306b\u3088\u3063\u3066\u751f\u6210\u3055\u308c\u307e\u3057\u305f
* idl/LogicalTimeTriggeredEC.idl\u304b\u3089
* 2016\u5e7411\u67081\u65e5 15\u664208\u520620\u79d2 JST
*/


/*!
   * @if jp
   * @brief ReturnCode_t
   *
   * OMG RTC 1.0 \u00fdd\u00fdl\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fdI\u00fdy\u00fd\u00fd\u00fd[\u00fdV\u00fd\u00fd\u00fd\u00fd\u00fdAA\u00fdN\u00fd\u00fd\u00fdC\u00fd\u00fd\u00fd\u0082Q\u0082\u00fd\u00fd
l\u00fd\u00fd
   * \u00fd\u00fd\u00fd\u00fdG\u00fd\u00fd\u00fd[\u00fd\u00fd\u00fd\u00f5\u00fd\u00fd\u00fdK\u00fdv\u00fd\u00fd\u00fd\u00fd\u00fd\u00fdB\u00fd\u00fd\u00fd\u00fdAAReturnCode_t\u00fd^\u00fd\u00fd\u00fd\u00fd
   * \u00fd\u00fd\u00fd^\u00fd[\u00fd\u00fd\u00fdR\u00fd[\u00fdh\u00fdB\u00fd\u00fds\u00fd\u00fd\u00fd\u00fdB
   *
   * OMG RTC 1.0 \u00fd\u00fd PIM \u00fd\u00fd\u00fdB\u00fd\u00fd\u00fd\u00fdAReturnCode_t\u00fd^\u00fdl\u00fd\u00fd\u00fd\u00fd\u00fd\u00fdI\u00fdy\u00fd\u00fd\u00fd[\u00fdV\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd
   * \u00fd\u00fd\u00fd\u00fd\u00fd\u00c2\u00fdl\u00fd^\u00fdH\u00d1\u00fd\u00fd\u00fd\u00fdA\u00fd\u00fd\u00fd\u00fd@\u00fdB\u00fd\u00fdG\u00fd\u00fd\u00fd[\u00fd\u00fd\u00f5\u00fd\u00fd\u00fd\u00fd\u00fd\u0082\u00fd\u00fd\u00fdB
   * -\u00fdI\u00fdy\u00fd\u00fd\u00fd[\u00fdV\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fdl\u00fd\u00fd\u00fd\u00fdG (OMG RTC 1.0 Section 5.2.2.6.4 \u00fd\u00fd
   *  get_rate\u00fd\u00a4\u00fd\u00fd)\u00fdA\u00fd\u00fd\u00fd\u00fd\u00fdl\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u0082B\u00fd\u00fdG\u00fd\u00fd\u00fd[\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u0082\u00fd\u00fd\u00fdB
   * - \u00fdI\u00fdy\u00fd\u00fd\u00fd[\u00fdV\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fdI\u00fdu\u00fdW\u00fdF\u00fdN\u00fdg\u00fd\u00fd\u00fdt\u00fd@\u00fd\u00fd\u00fd\u00fd\u00fdX(RTObject::get_component_profile
   *   OMG RTC 1.0 5.4.2.2.1\u00fd\u00fd\u00fdQ\u00fd\u00fd) \u00fd\u00fd\u008f\u00fd\u00fd\u00fdG\u00fdAnil\u00fdQ\u00fd\u0082\u00fd\u00fd\u00fd\u00fd\u00fd\u0082B\u00fd\u00fd
   *   \u00fdG\u00fd\u00fd\u00fd[\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u0082\u00fd\u00fd\u00fdB
   *
   * @else
   * @brief ReturnCode_t
   *
   * A number of operations in this specification will need to report
   * potential error conditions to their clients. This task shall be
   * accomplished by means of operation "return codes" of type
   * ReturnCode_t
   *
   * Operations in the PIM that do not return a value of type
   * ReturnCode_t shall report errors in the following ways, depending
   * on their return type:
   * - If an operation normally returns a positive numerical value (such as
   *   get_rate, see [OMG RTC 1.0 Section 5.2.2.6.4]), it shall indicate
   *   failure by returning a negative value.
   * - If an operation normally returns an object reference (such as
   *   RTObject::get_component_profile, see [OMG RTC 1.0 Section 5.4.2.2.1]),
   *   it shall indicate failure by returning a nil reference.
   *
   * @param RTC_OK The operation completed successfully.
   * @param RTC_ERROR The operation failed with a generic, unspecified error.
   * @param BAD_PARAMETER The operation failed because an illegal argument was
   *        passed to it.
   * @param UNSUPPORTED The operation is unsupported by the implementation
   *        (e.g., it belongs to a compliance point that is not implemented).
   * @param OUT_OF_RESOURCES The target of the operation ran out of the
   *        resources needed to complete the operation.
   * @param PRECONDITION_NOT_MET A pre-condition for the operation was not met.
   *
   * @endif
   */
abstract public class ReturnCode_tHelper
{
  private static String  _id = "IDL:omg.org/RTC/ReturnCode_t:1.0";

  public static void insert (org.omg.CORBA.Any a, RTC.ReturnCode_t that)
  {
    org.omg.CORBA.portable.OutputStream out = a.create_output_stream ();
    a.type (type ());
    write (out, that);
    a.read_value (out.create_input_stream (), type ());
  }

  public static RTC.ReturnCode_t extract (org.omg.CORBA.Any a)
  {
    return read (a.create_input_stream ());
  }

  private static org.omg.CORBA.TypeCode __typeCode = null;
  synchronized public static org.omg.CORBA.TypeCode type ()
  {
    if (__typeCode == null)
    {
      __typeCode = org.omg.CORBA.ORB.init ().create_enum_tc (RTC.ReturnCode_tHelper.id (), "ReturnCode_t", new String[] { "RTC_OK", "RTC_ERROR", "BAD_PARAMETER", "UNSUPPORTED", "OUT_OF_RESOURCES", "PRECONDITION_NOT_MET"} );
    }
    return __typeCode;
  }

  public static String id ()
  {
    return _id;
  }

  public static RTC.ReturnCode_t read (org.omg.CORBA.portable.InputStream istream)
  {
    return RTC.ReturnCode_t.from_int (istream.read_long ());
  }

  public static void write (org.omg.CORBA.portable.OutputStream ostream, RTC.ReturnCode_t value)
  {
    ostream.write_long (value.value ());
  }

}
