package RTC;


/**
* RTC/TimedAngularVelocity3D.java .
* IDL-to-Java\u30b3\u30f3\u30d1\u30a4\u30e9(\u30dd\u30fc\u30bf\u30d6\u30eb)\u3001\u30d0\u30fc\u30b8\u30e7\u30f3"3.2"\u306b\u3088\u3063\u3066\u751f\u6210\u3055\u308c\u307e\u3057\u305f
* idl/InterfaceDataTypes.idl\u304b\u3089
* 2016\u5e7411\u67081\u65e5 15\u664208\u520616\u79d2 JST
*/

public final class TimedAngularVelocity3D implements org.omg.CORBA.portable.IDLEntity
{
  public RTC.Time tm = null;
  public RTC.AngularVelocity3D data = null;

  public TimedAngularVelocity3D ()
  {
  } // ctor

  public TimedAngularVelocity3D (RTC.Time _tm, RTC.AngularVelocity3D _data)
  {
    tm = _tm;
    data = _data;
  } // ctor

} // class TimedAngularVelocity3D
