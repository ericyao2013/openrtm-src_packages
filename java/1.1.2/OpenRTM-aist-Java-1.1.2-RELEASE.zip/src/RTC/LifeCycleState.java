package RTC;


/**
* RTC/LifeCycleState.java .
* IDL-to-Java\u30b3\u30f3\u30d1\u30a4\u30e9(\u30dd\u30fc\u30bf\u30d6\u30eb)\u3001\u30d0\u30fc\u30b8\u30e7\u30f3"3.2"\u306b\u3088\u3063\u3066\u751f\u6210\u3055\u308c\u307e\u3057\u305f
* idl/LogicalTimeTriggeredEC.idl\u304b\u3089
* 2016\u5e7411\u67081\u65e5 15\u664208\u520620\u79d2 JST
*/


/*!
   * @if jp
   * @brief 
   * @else
   * @brief LifeCycleState
   *
   * @section Description
   * LifeCycleState is an enumeration of the states in the lifecycle above.
   *
   * @endif
   */
public class LifeCycleState implements org.omg.CORBA.portable.IDLEntity
{
  private        int __value;
  private static int __size = 4;
  private static RTC.LifeCycleState[] __array = new RTC.LifeCycleState [__size];

  public static final int _CREATED_STATE = 0;
  public static final RTC.LifeCycleState CREATED_STATE = new RTC.LifeCycleState(_CREATED_STATE);
  public static final int _INACTIVE_STATE = 1;
  public static final RTC.LifeCycleState INACTIVE_STATE = new RTC.LifeCycleState(_INACTIVE_STATE);
  public static final int _ACTIVE_STATE = 2;
  public static final RTC.LifeCycleState ACTIVE_STATE = new RTC.LifeCycleState(_ACTIVE_STATE);
  public static final int _ERROR_STATE = 3;
  public static final RTC.LifeCycleState ERROR_STATE = new RTC.LifeCycleState(_ERROR_STATE);

  public int value ()
  {
    return __value;
  }

  public static RTC.LifeCycleState from_int (int value)
  {
    if (value >= 0 && value < __size)
      return __array[value];
    else
      throw new org.omg.CORBA.BAD_PARAM ();
  }

  protected LifeCycleState (int value)
  {
    __value = value;
    __array[__value] = this;
  }
} // class LifeCycleState
