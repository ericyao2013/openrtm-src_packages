package OpenRTM;


/**
* OpenRTM/PortStatus.java .
* IDL-to-Java\u30b3\u30f3\u30d1\u30a4\u30e9(\u30dd\u30fc\u30bf\u30d6\u30eb)\u3001\u30d0\u30fc\u30b8\u30e7\u30f3"3.2"\u306b\u3088\u3063\u3066\u751f\u6210\u3055\u308c\u307e\u3057\u305f
* idl/DataPort.idl\u304b\u3089
* 2016\u5e7411\u67081\u65e5 15\u664208\u520613\u79d2 JST
*/

public class PortStatus implements org.omg.CORBA.portable.IDLEntity
{
  private        int __value;
  private static int __size = 6;
  private static OpenRTM.PortStatus[] __array = new OpenRTM.PortStatus [__size];

  public static final int _PORT_OK = 0;
  public static final OpenRTM.PortStatus PORT_OK = new OpenRTM.PortStatus(_PORT_OK);
  public static final int _PORT_ERROR = 1;
  public static final OpenRTM.PortStatus PORT_ERROR = new OpenRTM.PortStatus(_PORT_ERROR);
  public static final int _BUFFER_FULL = 2;
  public static final OpenRTM.PortStatus BUFFER_FULL = new OpenRTM.PortStatus(_BUFFER_FULL);
  public static final int _BUFFER_EMPTY = 3;
  public static final OpenRTM.PortStatus BUFFER_EMPTY = new OpenRTM.PortStatus(_BUFFER_EMPTY);
  public static final int _BUFFER_TIMEOUT = 4;
  public static final OpenRTM.PortStatus BUFFER_TIMEOUT = new OpenRTM.PortStatus(_BUFFER_TIMEOUT);
  public static final int _UNKNOWN_ERROR = 5;
  public static final OpenRTM.PortStatus UNKNOWN_ERROR = new OpenRTM.PortStatus(_UNKNOWN_ERROR);

  public int value ()
  {
    return __value;
  }

  public static OpenRTM.PortStatus from_int (int value)
  {
    if (value >= 0 && value < __size)
      return __array[value];
    else
      throw new org.omg.CORBA.BAD_PARAM ();
  }

  protected PortStatus (int value)
  {
    __value = value;
    __array[__value] = this;
  }
} // class PortStatus
