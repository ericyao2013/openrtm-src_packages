package OpenRTM;


/**
* OpenRTM/ExtTrigExecutionContextService.java .
* IDL-to-Java\u30b3\u30f3\u30d1\u30a4\u30e9(\u30dd\u30fc\u30bf\u30d6\u30eb)\u3001\u30d0\u30fc\u30b8\u30e7\u30f3"3.2"\u306b\u3088\u3063\u3066\u751f\u6210\u3055\u308c\u307e\u3057\u305f
* idl/OpenRTM.idl\u304b\u3089
* 2016\u5e7411\u67081\u65e5 15\u664208\u520612\u79d2 JST
*/


//  };
public interface ExtTrigExecutionContextService extends ExtTrigExecutionContextServiceOperations, RTC.ExecutionContextService, org.omg.CORBA.portable.IDLEntity 
{
} // interface ExtTrigExecutionContextService
