package OpenRTM;


/**
* OpenRTM/LogRecord.java .
* IDL-to-Java\u30b3\u30f3\u30d1\u30a4\u30e9(\u30dd\u30fc\u30bf\u30d6\u30eb)\u3001\u30d0\u30fc\u30b8\u30e7\u30f3"3.2"\u306b\u3088\u3063\u3066\u751f\u6210\u3055\u308c\u307e\u3057\u305f
* idl/Logger.idl\u304b\u3089
* 2016\u5e7411\u67081\u65e5 15\u664208\u520618\u79d2 JST
*/

public final class LogRecord implements org.omg.CORBA.portable.IDLEntity
{

  /*!
       * @if jp
       * @brief \u00fd\u00fd\u00fd\u00fd
       * \u00fd\u00fd\u00fd\u00fd\u00fdy\u00fd\u00fd\u00fd\u00fd\u00fd
       * @else
       * @brief Time
       * Time stump.
       * @endif
       */
  public RTC.Time time = null;

  /*!
       * @if jp
       * @brief \u00fdl\u00fd\u00fd>
       * \u00fdp\u00fd\u00fdRd\u00fd\u00fd\u00fd\u00fd\u00fdl\u00fd\u00fd\u00fd\u00fd\u00fd\u00a5\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd>
       * @else
       * @brief logger name
       * The logger name which writes this record.
       * @endif
       */
  public String loggername = null;

  /*!
       * @if jp
       * @brief \u00fdp\u00fd\u00fde\u00fd
       * \u00fd\u00fd\u00fd\u00a5s\u00fd\u00fd\u00fdd\u00a5p\u00fd\u00fde\u00fd
       * @else
       * @brief Log level
       * The log level of this record
       * @endif
       */
  public OpenRTM.LogLevel level = null;

  /*!
       * @if jp
       * @brief \u00fd\u00fd\u00e5\u00fd\u00fd\u00fd\u00fd\u00fd
       * \u00fdp\u00fd\u00fd\u00e5\u00fd\u00fd\u00fd\u00fd\u00fd
       * @else
       * @brief Message
       * Log message.
       * @endif
       */
  public String message = null;

  public LogRecord ()
  {
  } // ctor

  public LogRecord (RTC.Time _time, String _loggername, OpenRTM.LogLevel _level, String _message)
  {
    time = _time;
    loggername = _loggername;
    level = _level;
    message = _message;
  } // ctor

} // class LogRecord
