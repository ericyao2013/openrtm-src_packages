package OpenRTM;


/**
* OpenRTM/ComponentObserverHelper.java .
* IDL-to-Java\u30b3\u30f3\u30d1\u30a4\u30e9(\u30dd\u30fc\u30bf\u30d6\u30eb)\u3001\u30d0\u30fc\u30b8\u30e7\u30f3"3.2"\u306b\u3088\u3063\u3066\u751f\u6210\u3055\u308c\u307e\u3057\u305f
* idl/ComponentObserver.idl\u304b\u3089
* 2016\u5e7411\u67081\u65e5 15\u664208\u520617\u79d2 JST
*/


/*!
   * @if jp
   *
   * @interface ComponentObserver
   * 
   * RTC\u00fd\u00b3\u00bc\u00fd\u00fd\u00fd\u00a4\u00b9\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00a4;\u00fd?\u00fd\u00fd\u00a5\u00fd\u00fd\u00a5\u00fd\u00fd\u00fd\u00fd!\u00fd\u00fd\u00fd\u00fd\u00a5\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd$\u00a4\u00fd\u00fd\u00fd
   * \u00fd\u00a5\u00fd\u00fdW\u00e1\u00fd\u00fde\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fdSDO Service \u00fd$\u00fd\u00fd\u00a1\u00fd\u00fd>d$\u00a4\u00fdRTC/SDO\u00fd\u00fd\u00fd$\u00fd\u00fd\u00fd
   * \u00fd\u00fd\u00fd\u00fd\u00fd\u00e5\u00fd\u00fd\u00fd\u00fdbRTC/SDO\u00fd\u00fd\u00be\u00fd\u00fd\u00a4\u00fd\u00fdy\u00fd\u00fd\u00fd\u00fd?\u00fd\u00fd\u00fd\u00e1\u00fd\u00fdy\u00fd\u00fd\u00fd\u00fd?\u00fd\u00fd\u00fd\u00a4\u00fd
   * \u00fd\u00fd\u00fd\u00fd%\u00a5\u00fd$\u00fd\u00b1\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00a4\u00fd\u00fdc\u00fd!\u00fd\u00fd\u00fd\u00a4d\u00e1\u00fd\u00fda\u00fd\u00fd\u00fdW$\u00e4\u00fd:RTC
   * \u00fd\u00be\u00fd\u00fd\u00a4\u00fd\u00fdr\u00fd\u00fd\u00fd\u00fd\u00a4?\u00fd\u00fd\u00fd\u00fd\u00fd\u00a4d\u00fd\u00fd\u00fd\u00fdd\u00fd\u00fdc
   *
   * \u00fd\u00fd\u00fd7\u00fd\u00a4\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00e1\u00fd\u00f0\u00b2\u00fd\u00fd\u00a4$\u00fd\u00fd\u00fd\u00e4\u00fd\u00fdc
   *
   * -# SDO::get_configuration() \u00fd\u00e4\u00fd\u00fd Configuration \u00fd\u00fd\u00fd\u00a5\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd$\u00fd\u00fd\u00fd\u00fd
   * -# Configuration::add_service_profile() \u00fd\u00e4\u00fd\u00fdTool\u00a6\u00fd\u00fd
   *     ComponentObserver \u00fd\u00fd ServiceProfile \u00fd\u00e4\u00fd\u00fd RTC \u00fd\u00fd\u00fd\u00fd\u00fdc
   *     ServiceProfile \u00fd\u00a5\u00fd\u00fd!\u00fd\u00fd\u00f0\u00b2\u00fd\u00fd\u00a4&\u00fd\u00fd\u00fd\u00fd\u00fd9\u00fd3\u00fd\u00fd
   *   - id: UUID \u00fd\u00a4p\u00fdd\u00fdID\u00fd\u00fd\u00fd\u00fd\u00fd9\u00fdc\u00fd\u00fd\u00fd\u00fd\u00fd\u00e4\u00fdl\u00fd\u00e4\u00e4\u00a4\u00fd\u00a4\u00e1\u00fdTool
   *     \u00a6\u00fd\u00e4\u00fdID\u00fd\u00fd\u00fd{\u00fd\u00a4\u00fd\u00fd\u00fd\u00fd\u00a4\u00fd\u00fd\u00fd$\u00a4\u00fd\u00a4\u00fd\u00fd\u00fd
   *   - interface_type: \u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00e5\u00fd\u00fd\u00fdIFR\u00fd\u00fdID\u00fd\u00fd\u00b8\u00fd\u00fd\u00fd\u00fd$\u00fd\u00fd\u00bb\u00fd\u00fdcRTC\u00a6\u00fd\u00fd
   *     \u00fd\u00e4\u00fd\u00fd\u00fd\u00b8\u00fd\u00fd\u00fd\u00fd\u00e4\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00e5\u00fd\u00fd\u00fd\u00fd\u00a5\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd$\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd+\u00fd\u00fd\u00fd9
   *     \u00fd?\u00fd\u00fd\u00fd\u00fd\u00fd\u00fdl\u00fd$$\u00a4c
   *   - properties: RTC\u00a6\u00fd\u00a5\u00fd\u00fd\u00fd\u00fd\u00e5\u00fd\u00fd\u00bc\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00a6\u00fd\u00fd\u00fd\u00fd\u00fd\u00a4\u00fd\u00fd\u00fd\u00e5\u00fde\u00a5\u00fd\u00fd\u00fd\u00fd\u00fd
   *     \u00fd9\u00fdc\u00fd\u00fd\u00fd\u00a5\u00fd\u00fd\u00fd\u00fd\u00e5\u00fd\u00fd\u00e4\u00e1\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd heartbeat \u00fd\u00fd\u00e2\u00fd\u00a5\u00e5\u00fde\u00a5\u00fd\u00fd\u00fd
   *     \u00fd\u00fd\u00fd9\u00fdc
   *    - service: SDOService \u00fd\u00fd\u00fd\u00a5\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd$\u00bb\u00fd\u00fd$\u00fd\u00fd\u00fd9\u00fdc
   * -# RTC\u00a6\u00fd\u00fe\u00fd\u00fd\u00a4\u00fd\u00fdr\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00e4\u00fd\u00fd\u00fd\u00fd\u00fd update_status() \u00fd\u00fd\u00fd\u00a5|\u00fd\u00fd\u00fd\u00fd\u00fd
   *     \u00fd\u00fd StatusKind \u00fd\u00fd\u00fd\u00fd\u00fd hint \u00fd\u00fd\u00b8\u00fd\u00fd\u00fd\u00fd$$\u00fd\u00f8\u00a4\u00fd$\u00fd\u00fd\u00fdcTool\u00a6
   *     \u00fd\u00e4\u00e1\u00fdStatusKind \u00fd\u00fd hint \u00fd\u00f4\u00fdd\u00fd RTC \u00fd\u00a4\u00fd\u00fd\u00fd\u00fd\u00fd\u00ac\u00fd\u00be\u00fd\u00fd\u00a4\u00fd\u00fdr\u00fd\u00fd\u00fd
   *     \u00fd\u00fd\u00fd\u00fd\u00fd$\u00fd\u00fd\u00a4bl\u00fd\u00e4\u00bd\u00fd\u00fd\u00fd\u00fd$\u00fd\u00fd\u00fd
   * -# \u00fd\u00fd\u00fdj\u00fd\u00fdComponentObserver\u00fd\u00fd\u00fd\u00a5\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd$\u00fd\u00fd\u00fd\u00fd\u00e4\u00e4\u00a4\u00e4\u00fd\u00fd\u00fd\u00fd\u00e4\u00e1\u00fd
   *     Configuration::remove_service_profile() \u00fd\u00fd id \u00fd$$\u00fd\u00f8\u00a4\u00fd$\u00fd
   *     RTC \u00fd\u00fd\u00fd\u00fd\u00fd\u00fdc
   *
   * <pre>
   * 
   *   [RTC]    [Configuration]           [Observer]    [Tool]
   *     |            |                       |            |
   *     |            | get_configuration()   |            |
   *     |<------------------------------------------------|
   *     |            |                       |            |
   *     |            | add_service_profile(prof)          |
   *     |            |<-----------------------------------|
   *     |            |                       |            |
   *     |            | update_status(kind, hint)          |
   *     |----------------------------------->|            |
   *     |            | update_status(kind, hint)          |
   *     |----------------------------------->|            |
   *     |            |       :               |            |
   *     |            |                       |            |
   *     |            | remove_service_profile(id)         |
   *     |            |<-----------------------------------|
   *     |            |                       |            |
   *     |            |                       x            x
   *
   * </pre>
   *
   * \u00fd\u00a4\u00fd\u00fd\u00fdServiceProfile::properties \u00fd\u00fb\u00fd\u00fd9\u00fd\u00fd\u00e5\u00fde\u00a5\u00fd\u00fd$\u00fd\u00fd\u00a4\u00e1\u00fd
   *
   * - observed_status: ALL or kind of status
   * - heartbeat.enable: YES/NO
   * - heartbeat.interval: x [s]
   * 
   * \u00fd\u00fd\u00fd\u00fd\u00fdc
   * 
   * - observed_staus: ALL \u00fd\u00a4\u00fd\u00fd\u00fe\u00fd\u00fd\u00a4\u00bc\u00fd\u00fd\u00fdV\u00e5\u00fd\u00b6\u00fd\u00fd\u00a4\u00fd\u00fb\u00fd\u00fd\u00fd
   *   \u00fd\u00bb9\u00fd\u00fd\u00fd\u00fd\u00a4\u00fd\u00fd\u00fd9\u00fdc\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00be\u00fd\u00fd\u00a4\u00fd}\u00fd\u00fd\u00b8\u00fd\u00fd\u00fd\u00fd\u00e1\u00fd
   *   COMPONENT_PROFILE, RTC_STATUS, EC_STATUS, PORT_PROFILE,
   *   CONFIGURATION 5\u00fd\u00fd\u00fd\u00fd\u00e4\u00fd\u00fdc\u00fd\u00bb7\u00fd\u00fd\u00fd\u00fd\u00fd>dV\u00e5\u00fd\u00a4\u00f6\u00fd\u00fd\u00a4\u00fd\u00a3\u00fd\u00fd\u00fd\u00fd
   *   \u00fd9\u00fd3\u00fd$\u00fd\u00fd\u00e4\u00fd\u00fdc\u00fd\u00a4\u00fd\u00fd\u00fd\u00fd\u00fd\u00fdd\u00a4\u00be\u00fd\u00fd\u00a4\u00fd\u00bb9\u00fd\u00fd\u00fdbALL \u00fd\u00fd\u00fd\u00fd\u00fd
   *   \u00fd\u00fd\u00fd3\u00fd$\u00fd\u00fd\u00e4\u00fd\u00fdc\u00fd\u00fd\u00fd\u00fd\u00b8\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00b8\u00fd\u00fd\u00b8\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00a4\u00fd\u00fd\u00fd
   *
   * - heartbeat.interval: \u00fd\u00fd\u00f1\u00fd$\u00ff\u00fd\u00fdd\u00fb\u00fd\u00fd\u00fd
   *   \u00fd\u00e1\u00fd\u00fd%\u00e1\u00fd\u00fd$\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00f1\u00fd$\u00fb\u00fd\u00fd9\u00fdc\u00fd\u00a4\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd7\u00fd\u00fd\u00fd\u00ff\u00fd
   *   \u00fd\u00e5\u00e1\u00fd\u00fd%\u00e1\u00fd\u00fd$\u00fdl\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd~\u00a4\u00e4\u00a4\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00e4\u00a1\u00fdRTC\u00fd\u00fd\u00fd\u00fd\u00fd
   *   \u00fd\u00fd\u00fd\u00fd\u00fdd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00e7\u00fd\u00fd\u00fd\u00fd\u00e4\u00e1\u00fdheartbeat.interval \u00fd\u00fd\u00fd\u00fd\u00ac\u00fd\u00bb\u00fd\u00fd\u00a4\u00fd\u00fd$\u00fd
   *   l\u00fd\u00e4\u00fd\u00fd\u00fd\u00fdc
   *
   * - heartbeat.enable: YES \u00fd\u00a4\u00fd\u00fd\u00fd NO\u00fd\u00fb\u00fd\u00fd\u00fd
   *   Tool\u00a6\u00fd\u00e4\u00e1\u00fd\u00fd\u00fd\u00fd\u00a4\u00fd\u00fdr\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00a4\u00fd RTC \u00fd\u00fd\u00fd\u00fd\u00b8\u00fd\u00fd\u00fd\u00a4\u00fd\u00fd+\u00fdd\u00fd\u00fd\u00fd\u00fd\u00a4\u00fd
   *   \u00fd\u00fd\u00fd$\u00e4\u00e4\u00fd\u00fd\u00a4\u00fd\u00fd\u00fd\u00fdb\u00fd\u00fd\u00fd\u00fdRTC\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00e4\u00e1\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00a43\u00fd$\u00fd\u00fd\u00fd
   *   \u00fd\u00fd\u00fd\u00a4\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00e1\u00fdHEART_BEAT \u00fd\u00fd\u00fde\u00fd$\u00fd\u00fd\u00fd\u00fdj\u00fd\u00fdRTC\u00a6\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd;\u00fd3
   *   \u00fd$\u00fd\u00fd\u00e4\u00fd\u00fdc\u00fd\u00e1\u00fd\u00fd%\u00e1\u00fd\u00fd$\u00fdm\u00fd\u00fd\u00e4\u00fd\u00fd+\u00fdd\u00fd\u00fdS\u00e4\u00a5\u00fd\u00fd\u00e5\u00fd\u00fd\u00fd\u00fd\u00fb\u00fd\u00fd\u00fd
   *   \u00fd\u00fd\u00fdc
   * 
   * 
   * @else
   *
   * @interface ComponentObserver
   * 
   * This is an interface to notify various status changed in RTC to
   * others.  This is attached into a target RTC/SDO as a SDO service,
   * and if an RTC/SDO's status change, a kind of changed status and
   * its hints are notified to observers.  For example, it can be used
   * to notify RTC's status changed without polling in certain tools.
   *
   * An assumed usage is as follows.
   *
   * -# SDO::get_configuration() is called to get a Configuration object
   *
   * -# Configuration::add_service_profile() is called by Tool.
   *     A ComponentObserver in a ServiceProfile is given to RTC.
   *     ServiceProfile members should be set as follows.
   *
   *    - id: UUID and other unique ID should be specified. Since this ID
   *      is used when the service is removed, tools should remember
   *      this ID.
   *
   *    - interface_type: IFR ID should be specified here. Since the RTC
   *      decides if the given SDO service object can be accepted by
   *      using the interface_type string, this member is mandatory.
   * 
   *    - properties: This member specifies properties to be notified to
   *      RTC side. In this service, the following heartbeat related
   *      properties should be specified.
   *
   *    - service: SDOService object reference should be specified.
   * 
   * -# If some changes happen in RTC, the update_status() operation
   *    is called with StatusKind and hint string. RTC's status change
   *    is notified to tool and some processes would be performed by
   *    the tool according to the StatusKind and hint.
   *
   * -# Finally, When the ComponentObserver object becomes
   *     unnecessary, Configuration::remove_service_profile() is called
   *     with id and it is removed from RTC.
   *
   * <pre>
   * 
   *   [RTC]    [Configuration]           [Observer]    [Tool]
   *     |            |                       |            |
   *     |            | get_configuration()   |            |
   *     |<------------------------------------------------|
   *     |            |                       |            |
   *     |            | add_service_profile(prof)          |
   *     |            |<-----------------------------------|
   *     |            |                       |            |
   *     |            | update_status(kind, hint)          |
   *     |----------------------------------->|            |
   *     |            | update_status(kind, hint)          |
   *     |----------------------------------->|            |
   *     |            |       :               |            |
   *     |            |                       |            |
   *     |            | remove_service_profile(id)         |
   *     |            |<-----------------------------------|
   *     |            |                       |            |
   *     |            |                       x            x
   *
   * </pre>
   *
   * Properties which is specified in ServiceProfile::properties is as follows.
   *
   * - observed_status: ALL or kind of status
   * - heartbeat.enable: YES/NO
   * - heartbeat.interval: x [s]
   * 
   *
   * - observed_staus: ALL or comma separated status kinds This
   *   property specifies kind of status to be observed. Available
   *   kind of statuses are COMPONENT_PROFILE, RTC_STATUS, EC_STATUS,
   *   PORT_PROFILE, CONFIGURATION. You can specify comma-separated
   *   status list to be observed. And if you want to observe all the
   *   status, you just specify ALL instead of all the status kind
   *   list. Uppercase, lowercase and mixture are allowed in the
   *   specified status kind.
   *
   * - heartbeat.enable: YES or NO
   *
   *   Since tools cannot know whether the RTC is alive or not until
   *   status change happens, if the RTC suddenly died, the tools
   *   cannot know it forever. To eliminate this problems, Observer
   *   object can send periodic heartbeat signals to observers. The
   *   heartbeat.enable option specifies whether the functionality is
   *   activated or not.
   *
   * - heartbeat.interval: Heartbeat interval should be specified in
   *   seconds.  This specification does not guarantee that heartbeat
   *   signals precisely send back to observer. Therefore if you need
   *   to decide whether an RTC died or not, you have to wait for
   *   several heartbeat signals.
   *
   * @endif
   */
abstract public class ComponentObserverHelper
{
  private static String  _id = "IDL:OpenRTM/ComponentObserver:1.0";

  public static void insert (org.omg.CORBA.Any a, OpenRTM.ComponentObserver that)
  {
    org.omg.CORBA.portable.OutputStream out = a.create_output_stream ();
    a.type (type ());
    write (out, that);
    a.read_value (out.create_input_stream (), type ());
  }

  public static OpenRTM.ComponentObserver extract (org.omg.CORBA.Any a)
  {
    return read (a.create_input_stream ());
  }

  private static org.omg.CORBA.TypeCode __typeCode = null;
  synchronized public static org.omg.CORBA.TypeCode type ()
  {
    if (__typeCode == null)
    {
      __typeCode = org.omg.CORBA.ORB.init ().create_interface_tc (OpenRTM.ComponentObserverHelper.id (), "ComponentObserver");
    }
    return __typeCode;
  }

  public static String id ()
  {
    return _id;
  }

  public static OpenRTM.ComponentObserver read (org.omg.CORBA.portable.InputStream istream)
  {
    return narrow (istream.read_Object (_ComponentObserverStub.class));
  }

  public static void write (org.omg.CORBA.portable.OutputStream ostream, OpenRTM.ComponentObserver value)
  {
    ostream.write_Object ((org.omg.CORBA.Object) value);
  }

  public static OpenRTM.ComponentObserver narrow (org.omg.CORBA.Object obj)
  {
    if (obj == null)
      return null;
    else if (obj instanceof OpenRTM.ComponentObserver)
      return (OpenRTM.ComponentObserver)obj;
    else if (!obj._is_a (id ()))
      throw new org.omg.CORBA.BAD_PARAM ();
    else
    {
      org.omg.CORBA.portable.Delegate delegate = ((org.omg.CORBA.portable.ObjectImpl)obj)._get_delegate ();
      OpenRTM._ComponentObserverStub stub = new OpenRTM._ComponentObserverStub ();
      stub._set_delegate(delegate);
      return stub;
    }
  }

  public static OpenRTM.ComponentObserver unchecked_narrow (org.omg.CORBA.Object obj)
  {
    if (obj == null)
      return null;
    else if (obj instanceof OpenRTM.ComponentObserver)
      return (OpenRTM.ComponentObserver)obj;
    else
    {
      org.omg.CORBA.portable.Delegate delegate = ((org.omg.CORBA.portable.ObjectImpl)obj)._get_delegate ();
      OpenRTM._ComponentObserverStub stub = new OpenRTM._ComponentObserverStub ();
      stub._set_delegate(delegate);
      return stub;
    }
  }

}
