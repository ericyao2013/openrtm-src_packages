package OpenRTM;

/**
* OpenRTM/ExtTrigExecutionContextServiceHolder.java .
* IDL-to-Java �R���p�C�� (�|�[�^�u��), �o�[�W���� "3.1" �Ő���
* ������: idl/OpenRTM.idl
* 2010�N5��10�� 16��53��57�b JST
*/


//  };
public final class ExtTrigExecutionContextServiceHolder implements org.omg.CORBA.portable.Streamable
{
  public OpenRTM.ExtTrigExecutionContextService value = null;

  public ExtTrigExecutionContextServiceHolder ()
  {
  }

  public ExtTrigExecutionContextServiceHolder (OpenRTM.ExtTrigExecutionContextService initialValue)
  {
    value = initialValue;
  }

  public void _read (org.omg.CORBA.portable.InputStream i)
  {
    value = OpenRTM.ExtTrigExecutionContextServiceHelper.read (i);
  }

  public void _write (org.omg.CORBA.portable.OutputStream o)
  {
    OpenRTM.ExtTrigExecutionContextServiceHelper.write (o, value);
  }

  public org.omg.CORBA.TypeCode _type ()
  {
    return OpenRTM.ExtTrigExecutionContextServiceHelper.type ();
  }

}
