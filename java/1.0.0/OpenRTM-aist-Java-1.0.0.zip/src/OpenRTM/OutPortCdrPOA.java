package OpenRTM;


/**
* OpenRTM/OutPortCdrPOA.java .
* IDL-to-Java �R���p�C�� (�|�[�^�u��), �o�[�W���� "3.1" �Ő���
* ������: idl/DataPort.idl
* 2010�N5��10�� 16��53��57�b JST
*/

public abstract class OutPortCdrPOA extends org.omg.PortableServer.Servant
 implements OpenRTM.OutPortCdrOperations, org.omg.CORBA.portable.InvokeHandler
{

  // Constructors

  private static java.util.Hashtable _methods = new java.util.Hashtable ();
  static
  {
    _methods.put ("get", new java.lang.Integer (0));
  }

  public org.omg.CORBA.portable.OutputStream _invoke (String $method,
                                org.omg.CORBA.portable.InputStream in,
                                org.omg.CORBA.portable.ResponseHandler $rh)
  {
    org.omg.CORBA.portable.OutputStream out = null;
    java.lang.Integer __method = (java.lang.Integer)_methods.get ($method);
    if (__method == null)
      throw new org.omg.CORBA.BAD_OPERATION (0, org.omg.CORBA.CompletionStatus.COMPLETED_MAYBE);

    switch (__method.intValue ())
    {
       case 0:  // OpenRTM/OutPortCdr/get
       {
         OpenRTM.CdrDataHolder data = new OpenRTM.CdrDataHolder ();
         OpenRTM.PortStatus $result = null;
         $result = this.get (data);
         out = $rh.createReply();
         OpenRTM.PortStatusHelper.write (out, $result);
         OpenRTM.CdrDataHelper.write (out, data.value);
         break;
       }

       default:
         throw new org.omg.CORBA.BAD_OPERATION (0, org.omg.CORBA.CompletionStatus.COMPLETED_MAYBE);
    }

    return out;
  } // _invoke

  // Type-specific CORBA::Object operations
  private static String[] __ids = {
    "IDL:OpenRTM/OutPortCdr:1.0"};

  public String[] _all_interfaces (org.omg.PortableServer.POA poa, byte[] objectId)
  {
    return (String[])__ids.clone ();
  }

  public OutPortCdr _this() 
  {
    return OutPortCdrHelper.narrow(
    super._this_object());
  }

  public OutPortCdr _this(org.omg.CORBA.ORB orb) 
  {
    return OutPortCdrHelper.narrow(
    super._this_object(orb));
  }


} // class OutPortCdrPOA
