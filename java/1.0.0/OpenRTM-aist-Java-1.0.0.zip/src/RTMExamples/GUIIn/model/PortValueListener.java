package RTMExamples.GUIIn.model;

public interface PortValueListener {

    public void onChanged(final PortValue portValue);
}
