package RTC;


/**
* RTC/MulticameraGeometryListHolder.java .
* IDL-to-Java �R���p�C�� (�|�[�^�u��), �o�[�W���� "3.1" �Ő���
* ������: idl/InterfaceDataTypes.idl
* 2010�N5��10�� 16��54��04�b JST
*/


/*!
     * @typedef MulticameraGeometryList
     */
public final class MulticameraGeometryListHolder implements org.omg.CORBA.portable.Streamable
{
  public RTC.Geometry3D value[] = null;

  public MulticameraGeometryListHolder ()
  {
  }

  public MulticameraGeometryListHolder (RTC.Geometry3D[] initialValue)
  {
    value = initialValue;
  }

  public void _read (org.omg.CORBA.portable.InputStream i)
  {
    value = RTC.MulticameraGeometryListHelper.read (i);
  }

  public void _write (org.omg.CORBA.portable.OutputStream o)
  {
    RTC.MulticameraGeometryListHelper.write (o, value);
  }

  public org.omg.CORBA.TypeCode _type ()
  {
    return RTC.MulticameraGeometryListHelper.type ();
  }

}
