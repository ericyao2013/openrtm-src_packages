package RTC;

/**
* RTC/ActArrayActuatorTypeHolder.java .
* IDL-to-Java �R���p�C�� (�|�[�^�u��), �o�[�W���� "3.1" �Ő���
* ������: idl/InterfaceDataTypes.idl
* 2010�N5��10�� 16��54��04�b JST
*/


/*!
     * @enum ActArrayActuatorType
     * @brief Describes the type of an actuator.
     */
public final class ActArrayActuatorTypeHolder implements org.omg.CORBA.portable.Streamable
{
  public RTC.ActArrayActuatorType value = null;

  public ActArrayActuatorTypeHolder ()
  {
  }

  public ActArrayActuatorTypeHolder (RTC.ActArrayActuatorType initialValue)
  {
    value = initialValue;
  }

  public void _read (org.omg.CORBA.portable.InputStream i)
  {
    value = RTC.ActArrayActuatorTypeHelper.read (i);
  }

  public void _write (org.omg.CORBA.portable.OutputStream o)
  {
    RTC.ActArrayActuatorTypeHelper.write (o, value);
  }

  public org.omg.CORBA.TypeCode _type ()
  {
    return RTC.ActArrayActuatorTypeHelper.type ();
  }

}
