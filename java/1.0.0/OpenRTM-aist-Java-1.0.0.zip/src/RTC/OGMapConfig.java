package RTC;


/**
* RTC/OGMapConfig.java .
* IDL-to-Java �R���p�C�� (�|�[�^�u��), �o�[�W���� "3.1" �Ő���
* ������: idl/InterfaceDataTypes.idl
* 2010�N5��10�� 16��54��04�b JST
*/

public final class OGMapConfig implements org.omg.CORBA.portable.IDLEntity
{

  /// Scale on the x axis (metres per cell).
  public double xScale = (double)0;

  /// Scale on the y axis (metres per cell).
  public double yScale = (double)0;

  /// Number of cells along the x axis.
  public int width = (int)0;

  /// Number of cells along the y axis.
  public int height = (int)0;

  /// Pose of the cell at (0, 0) in the real world.
  public RTC.Pose2D origin = null;

  public OGMapConfig ()
  {
  } // ctor

  public OGMapConfig (double _xScale, double _yScale, int _width, int _height, RTC.Pose2D _origin)
  {
    xScale = _xScale;
    yScale = _yScale;
    width = _width;
    height = _height;
    origin = _origin;
  } // ctor

} // class OGMapConfig
