package RTC;

/**
* RTC/MulticameraGeometryHolder.java .
* IDL-to-Java �R���p�C�� (�|�[�^�u��), �o�[�W���� "3.1" �Ő���
* ������: idl/InterfaceDataTypes.idl
* 2010�N5��10�� 16��54��04�b JST
*/

public final class MulticameraGeometryHolder implements org.omg.CORBA.portable.Streamable
{
  public RTC.MulticameraGeometry value = null;

  public MulticameraGeometryHolder ()
  {
  }

  public MulticameraGeometryHolder (RTC.MulticameraGeometry initialValue)
  {
    value = initialValue;
  }

  public void _read (org.omg.CORBA.portable.InputStream i)
  {
    value = RTC.MulticameraGeometryHelper.read (i);
  }

  public void _write (org.omg.CORBA.portable.OutputStream o)
  {
    RTC.MulticameraGeometryHelper.write (o, value);
  }

  public org.omg.CORBA.TypeCode _type ()
  {
    return RTC.MulticameraGeometryHelper.type ();
  }

}
