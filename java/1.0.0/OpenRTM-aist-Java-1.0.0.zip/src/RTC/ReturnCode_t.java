package RTC;


/**
* RTC/ReturnCode_t.java .
* IDL-to-Java �R���p�C�� (�|�[�^�u��), �o�[�W���� "3.1" �Ő���
* ������: idl/OpenRTM.idl
* 2010�N5��10�� 16��53��56�b JST
*/


/*!
   * @if jp
   * @brief ReturnCode_t
   *
   * OMG RTC 1.0 ??-nOn????�E??o�P???hk?WfH
   * ???�N??��K?1JY???LB?S?oReturnCode_t?n@
   * ???????k??L???
   *
   * OMG RTC 1.0 n PIM ?kJDfReturnCode_t?n$??UjD????�E??o
   * ]??n;?$n?k?XWf!n??k??�N???1JY??nhY?
   * -????�E??Lcp$??Y4 (OMG RTC 1.0 Section 5.2.2.6.4 n
   *  get_raten?Fk)?p$??YShk??�N???:Y?nhY?
   * - ????�E??L??�C���P???????(RTObject::get_component_profile
   *   OMG RTC 1.0 5.4.2.2.1??g) ?8?Y4nil?g??YShk??
   *   �N???:Y?nhY?
   *
   * @else
   * @brief ReturnCode_t
   *
   * A number of operations in this specification will need to report
   * potential error conditions to their clients. This task shall be
   * accomplished by means of operation "return codes" of type
   * ReturnCode_t
   *
   * Operations in the PIM that do not return a value of type
   * ReturnCode_t shall report errors in the following ways, depending
   * on their return type:
   * - If an operation normally returns a positive numerical value (such as
   *   get_rate, see [OMG RTC 1.0 Section 5.2.2.6.4]), it shall indicate
   *   failure by returning a negative value.
   * - If an operation normally returns an object reference (such as
   *   RTObject::get_component_profile, see [OMG RTC 1.0 Section 5.4.2.2.1]),
   *   it shall indicate failure by returning a nil reference.
   *
   * @param RTC_OK The operation completed successfully.
   * @param RTC_ERROR The operation failed with a generic, unspecified error.
   * @param BAD_PARAMETER The operation failed because an illegal argument was
   *        passed to it.
   * @param UNSUPPORTED The operation is unsupported by the implementation
   *        (e.g., it belongs to a compliance point that is not implemented).
   * @param OUT_OF_RESOURCES The target of the operation ran out of the
   *        resources needed to complete the operation.
   * @param PRECONDITION_NOT_MET A pre-condition for the operation was not met.
   *
   * @endif
   */
public class ReturnCode_t implements org.omg.CORBA.portable.IDLEntity
{
  private        int __value;
  private static int __size = 6;
  private static RTC.ReturnCode_t[] __array = new RTC.ReturnCode_t [__size];

  public static final int _RTC_OK = 0;
  public static final RTC.ReturnCode_t RTC_OK = new RTC.ReturnCode_t(_RTC_OK);
  public static final int _RTC_ERROR = 1;
  public static final RTC.ReturnCode_t RTC_ERROR = new RTC.ReturnCode_t(_RTC_ERROR);
  public static final int _BAD_PARAMETER = 2;
  public static final RTC.ReturnCode_t BAD_PARAMETER = new RTC.ReturnCode_t(_BAD_PARAMETER);
  public static final int _UNSUPPORTED = 3;
  public static final RTC.ReturnCode_t UNSUPPORTED = new RTC.ReturnCode_t(_UNSUPPORTED);
  public static final int _OUT_OF_RESOURCES = 4;
  public static final RTC.ReturnCode_t OUT_OF_RESOURCES = new RTC.ReturnCode_t(_OUT_OF_RESOURCES);
  public static final int _PRECONDITION_NOT_MET = 5;
  public static final RTC.ReturnCode_t PRECONDITION_NOT_MET = new RTC.ReturnCode_t(_PRECONDITION_NOT_MET);

  public int value ()
  {
    return __value;
  }

  public static RTC.ReturnCode_t from_int (int value)
  {
    if (value >= 0 && value < __size)
      return __array[value];
    else
      throw new org.omg.CORBA.BAD_PARAM ();
  }

  protected ReturnCode_t (int value)
  {
    __value = value;
    __array[__value] = this;
  }
} // class ReturnCode_t
