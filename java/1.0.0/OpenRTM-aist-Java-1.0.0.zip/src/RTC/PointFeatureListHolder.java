package RTC;


/**
* RTC/PointFeatureListHolder.java .
* IDL-to-Java �R���p�C�� (�|�[�^�u��), �o�[�W���� "3.1" �Ő���
* ������: idl/InterfaceDataTypes.idl
* 2010�N5��10�� 16��54��04�b JST
*/


/*!
     * @typedef PointFeatureList
     */
public final class PointFeatureListHolder implements org.omg.CORBA.portable.Streamable
{
  public RTC.PointFeature value[] = null;

  public PointFeatureListHolder ()
  {
  }

  public PointFeatureListHolder (RTC.PointFeature[] initialValue)
  {
    value = initialValue;
  }

  public void _read (org.omg.CORBA.portable.InputStream i)
  {
    value = RTC.PointFeatureListHelper.read (i);
  }

  public void _write (org.omg.CORBA.portable.OutputStream o)
  {
    RTC.PointFeatureListHelper.write (o, value);
  }

  public org.omg.CORBA.TypeCode _type ()
  {
    return RTC.PointFeatureListHelper.type ();
  }

}
