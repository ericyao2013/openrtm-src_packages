package RTC;

/**
* RTC/ActArrayStateHolder.java .
* IDL-to-Java �R���p�C�� (�|�[�^�u��), �o�[�W���� "3.1" �Ő���
* ������: idl/InterfaceDataTypes.idl
* 2010�N5��10�� 16��54��04�b JST
*/

public final class ActArrayStateHolder implements org.omg.CORBA.portable.Streamable
{
  public RTC.ActArrayState value = null;

  public ActArrayStateHolder ()
  {
  }

  public ActArrayStateHolder (RTC.ActArrayState initialValue)
  {
    value = initialValue;
  }

  public void _read (org.omg.CORBA.portable.InputStream i)
  {
    value = RTC.ActArrayStateHelper.read (i);
  }

  public void _write (org.omg.CORBA.portable.OutputStream o)
  {
    RTC.ActArrayStateHelper.write (o, value);
  }

  public org.omg.CORBA.TypeCode _type ()
  {
    return RTC.ActArrayStateHelper.type ();
  }

}
