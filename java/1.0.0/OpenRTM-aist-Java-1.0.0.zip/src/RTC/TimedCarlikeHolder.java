package RTC;

/**
* RTC/TimedCarlikeHolder.java .
* IDL-to-Java �R���p�C�� (�|�[�^�u��), �o�[�W���� "3.1" �Ő���
* ������: idl/InterfaceDataTypes.idl
* 2010�N5��10�� 16��54��03�b JST
*/

public final class TimedCarlikeHolder implements org.omg.CORBA.portable.Streamable
{
  public RTC.TimedCarlike value = null;

  public TimedCarlikeHolder ()
  {
  }

  public TimedCarlikeHolder (RTC.TimedCarlike initialValue)
  {
    value = initialValue;
  }

  public void _read (org.omg.CORBA.portable.InputStream i)
  {
    value = RTC.TimedCarlikeHelper.read (i);
  }

  public void _write (org.omg.CORBA.portable.OutputStream o)
  {
    RTC.TimedCarlikeHelper.write (o, value);
  }

  public org.omg.CORBA.TypeCode _type ()
  {
    return RTC.TimedCarlikeHelper.type ();
  }

}
