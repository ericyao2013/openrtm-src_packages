package RTC;

/**
* RTC/ComponentProfileHolder.java .
* IDL-to-Java �R���p�C�� (�|�[�^�u��), �o�[�W���� "3.1" �Ő���
* ������: idl/OpenRTM.idl
* 2010�N5��10�� 16��53��57�b JST
*/

public final class ComponentProfileHolder implements org.omg.CORBA.portable.Streamable
{
  public RTC.ComponentProfile value = null;

  public ComponentProfileHolder ()
  {
  }

  public ComponentProfileHolder (RTC.ComponentProfile initialValue)
  {
    value = initialValue;
  }

  public void _read (org.omg.CORBA.portable.InputStream i)
  {
    value = RTC.ComponentProfileHelper.read (i);
  }

  public void _write (org.omg.CORBA.portable.OutputStream o)
  {
    RTC.ComponentProfileHelper.write (o, value);
  }

  public org.omg.CORBA.TypeCode _type ()
  {
    return RTC.ComponentProfileHelper.type ();
  }

}
