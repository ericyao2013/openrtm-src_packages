package RTC;


/**
* RTC/OGMapCellsHolder.java .
* IDL-to-Java �R���p�C�� (�|�[�^�u��), �o�[�W���� "3.1" �Ő���
* ������: idl/InterfaceDataTypes.idl
* 2010�N5��10�� 16��54��04�b JST
*/


/*!
     * @typedef OGMapCells
     */
public final class OGMapCellsHolder implements org.omg.CORBA.portable.Streamable
{
  public byte value[] = null;

  public OGMapCellsHolder ()
  {
  }

  public OGMapCellsHolder (byte[] initialValue)
  {
    value = initialValue;
  }

  public void _read (org.omg.CORBA.portable.InputStream i)
  {
    value = RTC.OGMapCellsHelper.read (i);
  }

  public void _write (org.omg.CORBA.portable.OutputStream o)
  {
    RTC.OGMapCellsHelper.write (o, value);
  }

  public org.omg.CORBA.TypeCode _type ()
  {
    return RTC.OGMapCellsHelper.type ();
  }

}
