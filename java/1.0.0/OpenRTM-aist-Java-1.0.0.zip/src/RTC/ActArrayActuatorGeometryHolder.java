package RTC;

/**
* RTC/ActArrayActuatorGeometryHolder.java .
* IDL-to-Java �R���p�C�� (�|�[�^�u��), �o�[�W���� "3.1" �Ő���
* ������: idl/InterfaceDataTypes.idl
* 2010�N5��10�� 16��54��04�b JST
*/

public final class ActArrayActuatorGeometryHolder implements org.omg.CORBA.portable.Streamable
{
  public RTC.ActArrayActuatorGeometry value = null;

  public ActArrayActuatorGeometryHolder ()
  {
  }

  public ActArrayActuatorGeometryHolder (RTC.ActArrayActuatorGeometry initialValue)
  {
    value = initialValue;
  }

  public void _read (org.omg.CORBA.portable.InputStream i)
  {
    value = RTC.ActArrayActuatorGeometryHelper.read (i);
  }

  public void _write (org.omg.CORBA.portable.OutputStream o)
  {
    RTC.ActArrayActuatorGeometryHelper.write (o, value);
  }

  public org.omg.CORBA.TypeCode _type ()
  {
    return RTC.ActArrayActuatorGeometryHelper.type ();
  }

}
