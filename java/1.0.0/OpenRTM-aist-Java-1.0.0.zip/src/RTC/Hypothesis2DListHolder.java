package RTC;


/**
* RTC/Hypothesis2DListHolder.java .
* IDL-to-Java �R���p�C�� (�|�[�^�u��), �o�[�W���� "3.1" �Ő���
* ������: idl/InterfaceDataTypes.idl
* 2010�N5��10�� 16��54��04�b JST
*/


/*!
     * @typedef Hypothesis2DList
     */
public final class Hypothesis2DListHolder implements org.omg.CORBA.portable.Streamable
{
  public RTC.Hypothesis2D value[] = null;

  public Hypothesis2DListHolder ()
  {
  }

  public Hypothesis2DListHolder (RTC.Hypothesis2D[] initialValue)
  {
    value = initialValue;
  }

  public void _read (org.omg.CORBA.portable.InputStream i)
  {
    value = RTC.Hypothesis2DListHelper.read (i);
  }

  public void _write (org.omg.CORBA.portable.OutputStream o)
  {
    RTC.Hypothesis2DListHelper.write (o, value);
  }

  public org.omg.CORBA.TypeCode _type ()
  {
    return RTC.Hypothesis2DListHelper.type ();
  }

}
