package RTC;


/**
* RTC/RFIDTagDataHolder.java .
* IDL-to-Java �R���p�C�� (�|�[�^�u��), �o�[�W���� "3.1" �Ő���
* ������: idl/InterfaceDataTypes.idl
* 2010�N5��10�� 16��54��04�b JST
*/


/*!
     * @typedef RFIDTagData
     */
public final class RFIDTagDataHolder implements org.omg.CORBA.portable.Streamable
{
  public byte value[] = null;

  public RFIDTagDataHolder ()
  {
  }

  public RFIDTagDataHolder (byte[] initialValue)
  {
    value = initialValue;
  }

  public void _read (org.omg.CORBA.portable.InputStream i)
  {
    value = RTC.RFIDTagDataHelper.read (i);
  }

  public void _write (org.omg.CORBA.portable.OutputStream o)
  {
    RTC.RFIDTagDataHelper.write (o, value);
  }

  public org.omg.CORBA.TypeCode _type ()
  {
    return RTC.RFIDTagDataHelper.type ();
  }

}
