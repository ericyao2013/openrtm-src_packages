package RTC;

/**
* RTC/BumperGeometryHolder.java .
* IDL-to-Java �R���p�C�� (�|�[�^�u��), �o�[�W���� "3.1" �Ő���
* ������: idl/InterfaceDataTypes.idl
* 2010�N5��10�� 16��54��04�b JST
*/

public final class BumperGeometryHolder implements org.omg.CORBA.portable.Streamable
{
  public RTC.BumperGeometry value = null;

  public BumperGeometryHolder ()
  {
  }

  public BumperGeometryHolder (RTC.BumperGeometry initialValue)
  {
    value = initialValue;
  }

  public void _read (org.omg.CORBA.portable.InputStream i)
  {
    value = RTC.BumperGeometryHelper.read (i);
  }

  public void _write (org.omg.CORBA.portable.OutputStream o)
  {
    RTC.BumperGeometryHelper.write (o, value);
  }

  public org.omg.CORBA.TypeCode _type ()
  {
    return RTC.BumperGeometryHelper.type ();
  }

}
