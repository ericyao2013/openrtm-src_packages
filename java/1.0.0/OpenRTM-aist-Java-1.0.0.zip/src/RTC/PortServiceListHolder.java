package RTC;


/**
* RTC/PortServiceListHolder.java .
* IDL-to-Java �R���p�C�� (�|�[�^�u��), �o�[�W���� "3.1" �Ő���
* ������: idl/OpenRTM.idl
* 2010�N5��10�� 16��53��56�b JST
*/

public final class PortServiceListHolder implements org.omg.CORBA.portable.Streamable
{
  public RTC.PortService value[] = null;

  public PortServiceListHolder ()
  {
  }

  public PortServiceListHolder (RTC.PortService[] initialValue)
  {
    value = initialValue;
  }

  public void _read (org.omg.CORBA.portable.InputStream i)
  {
    value = RTC.PortServiceListHelper.read (i);
  }

  public void _write (org.omg.CORBA.portable.OutputStream o)
  {
    RTC.PortServiceListHelper.write (o, value);
  }

  public org.omg.CORBA.TypeCode _type ()
  {
    return RTC.PortServiceListHelper.type ();
  }

}
