package RTC;


/**
* RTC/Hypothesis3DListHolder.java .
* IDL-to-Java �R���p�C�� (�|�[�^�u��), �o�[�W���� "3.1" �Ő���
* ������: idl/InterfaceDataTypes.idl
* 2010�N5��10�� 16��54��04�b JST
*/


/*!
     * @typedef Hypothesis3DList
     */
public final class Hypothesis3DListHolder implements org.omg.CORBA.portable.Streamable
{
  public RTC.Hypothesis3D value[] = null;

  public Hypothesis3DListHolder ()
  {
  }

  public Hypothesis3DListHolder (RTC.Hypothesis3D[] initialValue)
  {
    value = initialValue;
  }

  public void _read (org.omg.CORBA.portable.InputStream i)
  {
    value = RTC.Hypothesis3DListHelper.read (i);
  }

  public void _write (org.omg.CORBA.portable.OutputStream o)
  {
    RTC.Hypothesis3DListHelper.write (o, value);
  }

  public org.omg.CORBA.TypeCode _type ()
  {
    return RTC.Hypothesis3DListHelper.type ();
  }

}
