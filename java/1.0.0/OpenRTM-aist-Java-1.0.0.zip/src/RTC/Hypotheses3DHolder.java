package RTC;

/**
* RTC/Hypotheses3DHolder.java .
* IDL-to-Java �R���p�C�� (�|�[�^�u��), �o�[�W���� "3.1" �Ő���
* ������: idl/InterfaceDataTypes.idl
* 2010�N5��10�� 16��54��04�b JST
*/

public final class Hypotheses3DHolder implements org.omg.CORBA.portable.Streamable
{
  public RTC.Hypotheses3D value = null;

  public Hypotheses3DHolder ()
  {
  }

  public Hypotheses3DHolder (RTC.Hypotheses3D initialValue)
  {
    value = initialValue;
  }

  public void _read (org.omg.CORBA.portable.InputStream i)
  {
    value = RTC.Hypotheses3DHelper.read (i);
  }

  public void _write (org.omg.CORBA.portable.OutputStream o)
  {
    RTC.Hypotheses3DHelper.write (o, value);
  }

  public org.omg.CORBA.TypeCode _type ()
  {
    return RTC.Hypotheses3DHelper.type ();
  }

}
