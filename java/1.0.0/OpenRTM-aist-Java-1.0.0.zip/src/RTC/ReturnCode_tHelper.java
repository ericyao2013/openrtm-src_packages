package RTC;


/**
* RTC/ReturnCode_tHelper.java .
* IDL-to-Java �R���p�C�� (�|�[�^�u��), �o�[�W���� "3.1" �Ő���
* ������: idl/OpenRTM.idl
* 2010�N5��10�� 16��53��56�b JST
*/


/*!
   * @if jp
   * @brief ReturnCode_t
   *
   * OMG RTC 1.0 ??-nOn????�E??o�P???hk?WfH
   * ???�N??��K?1JY???LB?S?oReturnCode_t?n@
   * ???????k??L???
   *
   * OMG RTC 1.0 n PIM ?kJDfReturnCode_t?n$??UjD????�E??o
   * ]??n;?$n?k?XWf!n??k??�N???1JY??nhY?
   * -????�E??Lcp$??Y4 (OMG RTC 1.0 Section 5.2.2.6.4 n
   *  get_raten?Fk)?p$??YShk??�N???:Y?nhY?
   * - ????�E??L??�C���P???????(RTObject::get_component_profile
   *   OMG RTC 1.0 5.4.2.2.1??g) ?8?Y4nil?g??YShk??
   *   �N???:Y?nhY?
   *
   * @else
   * @brief ReturnCode_t
   *
   * A number of operations in this specification will need to report
   * potential error conditions to their clients. This task shall be
   * accomplished by means of operation "return codes" of type
   * ReturnCode_t
   *
   * Operations in the PIM that do not return a value of type
   * ReturnCode_t shall report errors in the following ways, depending
   * on their return type:
   * - If an operation normally returns a positive numerical value (such as
   *   get_rate, see [OMG RTC 1.0 Section 5.2.2.6.4]), it shall indicate
   *   failure by returning a negative value.
   * - If an operation normally returns an object reference (such as
   *   RTObject::get_component_profile, see [OMG RTC 1.0 Section 5.4.2.2.1]),
   *   it shall indicate failure by returning a nil reference.
   *
   * @param RTC_OK The operation completed successfully.
   * @param RTC_ERROR The operation failed with a generic, unspecified error.
   * @param BAD_PARAMETER The operation failed because an illegal argument was
   *        passed to it.
   * @param UNSUPPORTED The operation is unsupported by the implementation
   *        (e.g., it belongs to a compliance point that is not implemented).
   * @param OUT_OF_RESOURCES The target of the operation ran out of the
   *        resources needed to complete the operation.
   * @param PRECONDITION_NOT_MET A pre-condition for the operation was not met.
   *
   * @endif
   */
abstract public class ReturnCode_tHelper
{
  private static String  _id = "IDL:omg.org/RTC/ReturnCode_t:1.0";

  public static void insert (org.omg.CORBA.Any a, RTC.ReturnCode_t that)
  {
    org.omg.CORBA.portable.OutputStream out = a.create_output_stream ();
    a.type (type ());
    write (out, that);
    a.read_value (out.create_input_stream (), type ());
  }

  public static RTC.ReturnCode_t extract (org.omg.CORBA.Any a)
  {
    return read (a.create_input_stream ());
  }

  private static org.omg.CORBA.TypeCode __typeCode = null;
  synchronized public static org.omg.CORBA.TypeCode type ()
  {
    if (__typeCode == null)
    {
      __typeCode = org.omg.CORBA.ORB.init ().create_enum_tc (RTC.ReturnCode_tHelper.id (), "ReturnCode_t", new String[] { "RTC_OK", "RTC_ERROR", "BAD_PARAMETER", "UNSUPPORTED", "OUT_OF_RESOURCES", "PRECONDITION_NOT_MET"} );
    }
    return __typeCode;
  }

  public static String id ()
  {
    return _id;
  }

  public static RTC.ReturnCode_t read (org.omg.CORBA.portable.InputStream istream)
  {
    return RTC.ReturnCode_t.from_int (istream.read_long ());
  }

  public static void write (org.omg.CORBA.portable.OutputStream ostream, RTC.ReturnCode_t value)
  {
    ostream.write_long (value.value ());
  }

}
