package OpenRTM;

/**
* OpenRTM/OutPortCdrHolder.java .
* IDL-to-Java �R���p�C�� (�|�[�^�u��), �o�[�W���� "3.1" �Ő���
* ������: idl/DataPort.idl
* 2010�N5��10�� 16��53��57�b JST
*/

public final class OutPortCdrHolder implements org.omg.CORBA.portable.Streamable
{
  public OpenRTM.OutPortCdr value = null;

  public OutPortCdrHolder ()
  {
  }

  public OutPortCdrHolder (OpenRTM.OutPortCdr initialValue)
  {
    value = initialValue;
  }

  public void _read (org.omg.CORBA.portable.InputStream i)
  {
    value = OpenRTM.OutPortCdrHelper.read (i);
  }

  public void _write (org.omg.CORBA.portable.OutputStream o)
  {
    OpenRTM.OutPortCdrHelper.write (o, value);
  }

  public org.omg.CORBA.TypeCode _type ()
  {
    return OpenRTM.OutPortCdrHelper.type ();
  }

}
