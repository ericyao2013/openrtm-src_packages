package RTC;

/**
* RTC/TimedWStringHolder.java .
* IDL-to-Java �R���p�C�� (�|�[�^�u��), �o�[�W���� "3.1" �Ő���
* ������: idl/InterfaceDataTypes.idl
* 2010�N5��10�� 16��54��03�b JST
*/

public final class TimedWStringHolder implements org.omg.CORBA.portable.Streamable
{
  public RTC.TimedWString value = null;

  public TimedWStringHolder ()
  {
  }

  public TimedWStringHolder (RTC.TimedWString initialValue)
  {
    value = initialValue;
  }

  public void _read (org.omg.CORBA.portable.InputStream i)
  {
    value = RTC.TimedWStringHelper.read (i);
  }

  public void _write (org.omg.CORBA.portable.OutputStream o)
  {
    RTC.TimedWStringHelper.write (o, value);
  }

  public org.omg.CORBA.TypeCode _type ()
  {
    return RTC.TimedWStringHelper.type ();
  }

}
