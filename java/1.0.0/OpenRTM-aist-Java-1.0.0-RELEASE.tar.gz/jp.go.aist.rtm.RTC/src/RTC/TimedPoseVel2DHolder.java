package RTC;

/**
* RTC/TimedPoseVel2DHolder.java .
* IDL-to-Java �R���p�C�� (�|�[�^�u��), �o�[�W���� "3.1" �Ő���
* ������: idl/InterfaceDataTypes.idl
* 2010�N5��10�� 16��54��03�b JST
*/

public final class TimedPoseVel2DHolder implements org.omg.CORBA.portable.Streamable
{
  public RTC.TimedPoseVel2D value = null;

  public TimedPoseVel2DHolder ()
  {
  }

  public TimedPoseVel2DHolder (RTC.TimedPoseVel2D initialValue)
  {
    value = initialValue;
  }

  public void _read (org.omg.CORBA.portable.InputStream i)
  {
    value = RTC.TimedPoseVel2DHelper.read (i);
  }

  public void _write (org.omg.CORBA.portable.OutputStream o)
  {
    RTC.TimedPoseVel2DHelper.write (o, value);
  }

  public org.omg.CORBA.TypeCode _type ()
  {
    return RTC.TimedPoseVel2DHelper.type ();
  }

}
