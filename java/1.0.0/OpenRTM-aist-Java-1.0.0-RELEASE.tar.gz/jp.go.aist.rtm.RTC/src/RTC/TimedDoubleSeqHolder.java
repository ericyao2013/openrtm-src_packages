package RTC;

/**
* RTC/TimedDoubleSeqHolder.java .
* IDL-to-Java �R���p�C�� (�|�[�^�u��), �o�[�W���� "3.1" �Ő���
* ������: idl/InterfaceDataTypes.idl
* 2010�N5��10�� 16��54��03�b JST
*/

public final class TimedDoubleSeqHolder implements org.omg.CORBA.portable.Streamable
{
  public RTC.TimedDoubleSeq value = null;

  public TimedDoubleSeqHolder ()
  {
  }

  public TimedDoubleSeqHolder (RTC.TimedDoubleSeq initialValue)
  {
    value = initialValue;
  }

  public void _read (org.omg.CORBA.portable.InputStream i)
  {
    value = RTC.TimedDoubleSeqHelper.read (i);
  }

  public void _write (org.omg.CORBA.portable.OutputStream o)
  {
    RTC.TimedDoubleSeqHelper.write (o, value);
  }

  public org.omg.CORBA.TypeCode _type ()
  {
    return RTC.TimedDoubleSeqHelper.type ();
  }

}
