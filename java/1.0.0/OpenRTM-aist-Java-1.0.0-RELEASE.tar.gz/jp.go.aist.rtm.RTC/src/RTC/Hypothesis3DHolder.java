package RTC;

/**
* RTC/Hypothesis3DHolder.java .
* IDL-to-Java �R���p�C�� (�|�[�^�u��), �o�[�W���� "3.1" �Ő���
* ������: idl/InterfaceDataTypes.idl
* 2010�N5��10�� 16��54��04�b JST
*/

public final class Hypothesis3DHolder implements org.omg.CORBA.portable.Streamable
{
  public RTC.Hypothesis3D value = null;

  public Hypothesis3DHolder ()
  {
  }

  public Hypothesis3DHolder (RTC.Hypothesis3D initialValue)
  {
    value = initialValue;
  }

  public void _read (org.omg.CORBA.portable.InputStream i)
  {
    value = RTC.Hypothesis3DHelper.read (i);
  }

  public void _write (org.omg.CORBA.portable.OutputStream o)
  {
    RTC.Hypothesis3DHelper.write (o, value);
  }

  public org.omg.CORBA.TypeCode _type ()
  {
    return RTC.Hypothesis3DHelper.type ();
  }

}
