package RTC;


/**
* RTC/LineFeatureListHolder.java .
* IDL-to-Java �R���p�C�� (�|�[�^�u��), �o�[�W���� "3.1" �Ő���
* ������: idl/InterfaceDataTypes.idl
* 2010�N5��10�� 16��54��04�b JST
*/


/*!
     * @typedef LineFeatureList
     */
public final class LineFeatureListHolder implements org.omg.CORBA.portable.Streamable
{
  public RTC.LineFeature value[] = null;

  public LineFeatureListHolder ()
  {
  }

  public LineFeatureListHolder (RTC.LineFeature[] initialValue)
  {
    value = initialValue;
  }

  public void _read (org.omg.CORBA.portable.InputStream i)
  {
    value = RTC.LineFeatureListHelper.read (i);
  }

  public void _write (org.omg.CORBA.portable.OutputStream o)
  {
    RTC.LineFeatureListHelper.write (o, value);
  }

  public org.omg.CORBA.TypeCode _type ()
  {
    return RTC.LineFeatureListHelper.type ();
  }

}
