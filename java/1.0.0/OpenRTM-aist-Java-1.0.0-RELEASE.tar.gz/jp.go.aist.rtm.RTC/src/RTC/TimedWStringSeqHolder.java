package RTC;

/**
* RTC/TimedWStringSeqHolder.java .
* IDL-to-Java �R���p�C�� (�|�[�^�u��), �o�[�W���� "3.1" �Ő���
* ������: idl/InterfaceDataTypes.idl
* 2010�N5��10�� 16��54��03�b JST
*/

public final class TimedWStringSeqHolder implements org.omg.CORBA.portable.Streamable
{
  public RTC.TimedWStringSeq value = null;

  public TimedWStringSeqHolder ()
  {
  }

  public TimedWStringSeqHolder (RTC.TimedWStringSeq initialValue)
  {
    value = initialValue;
  }

  public void _read (org.omg.CORBA.portable.InputStream i)
  {
    value = RTC.TimedWStringSeqHelper.read (i);
  }

  public void _write (org.omg.CORBA.portable.OutputStream o)
  {
    RTC.TimedWStringSeqHelper.write (o, value);
  }

  public org.omg.CORBA.TypeCode _type ()
  {
    return RTC.TimedWStringSeqHelper.type ();
  }

}
