package RTC;

/**
* RTC/FsmParticipantHolder.java .
* IDL-to-Java �R���p�C�� (�|�[�^�u��), �o�[�W���� "3.1" �Ő���
* ������: idl/OpenRTM.idl
* 2010�N5��10�� 16��53��56�b JST
*/


/*!
   * @if jp
   * @brief 
   * @else
   * @brief 
   * @endif
   */
public final class FsmParticipantHolder implements org.omg.CORBA.portable.Streamable
{
  public RTC.FsmParticipant value = null;

  public FsmParticipantHolder ()
  {
  }

  public FsmParticipantHolder (RTC.FsmParticipant initialValue)
  {
    value = initialValue;
  }

  public void _read (org.omg.CORBA.portable.InputStream i)
  {
    value = RTC.FsmParticipantHelper.read (i);
  }

  public void _write (org.omg.CORBA.portable.OutputStream o)
  {
    RTC.FsmParticipantHelper.write (o, value);
  }

  public org.omg.CORBA.TypeCode _type ()
  {
    return RTC.FsmParticipantHelper.type ();
  }

}
