package RTC;

/**
* RTC/ActArrayActuatorPosHolder.java .
* IDL-to-Java �R���p�C�� (�|�[�^�u��), �o�[�W���� "3.1" �Ő���
* ������: idl/InterfaceDataTypes.idl
* 2010�N5��10�� 16��54��04�b JST
*/

public final class ActArrayActuatorPosHolder implements org.omg.CORBA.portable.Streamable
{
  public RTC.ActArrayActuatorPos value = null;

  public ActArrayActuatorPosHolder ()
  {
  }

  public ActArrayActuatorPosHolder (RTC.ActArrayActuatorPos initialValue)
  {
    value = initialValue;
  }

  public void _read (org.omg.CORBA.portable.InputStream i)
  {
    value = RTC.ActArrayActuatorPosHelper.read (i);
  }

  public void _write (org.omg.CORBA.portable.OutputStream o)
  {
    RTC.ActArrayActuatorPosHelper.write (o, value);
  }

  public org.omg.CORBA.TypeCode _type ()
  {
    return RTC.ActArrayActuatorPosHelper.type ();
  }

}
