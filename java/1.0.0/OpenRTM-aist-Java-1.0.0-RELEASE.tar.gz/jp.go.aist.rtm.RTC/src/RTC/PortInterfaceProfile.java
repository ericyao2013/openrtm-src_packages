package RTC;


/**
* RTC/PortInterfaceProfile.java .
* IDL-to-Java �R���p�C�� (�|�[�^�u��), �o�[�W���� "3.1" �Ő���
* ������: idl/OpenRTM.idl
* 2010�N5��10�� 16��53��56�b JST
*/

public final class PortInterfaceProfile implements org.omg.CORBA.portable.IDLEntity
{

  /*!
     * @if jp
     * @brief 
     * @else
     * @brief instance_name
     *
     * @section Description
     *
     * This attribute stores the name of the target interface instance.
     *
     * @endif
     */
  public String instance_name = null;

  /*!
     * @if jp
     * @brief 
     * @else
     * @brief type_name
     *
     * @section Description
     *
     * This attribute stores the name of the target interface type.
     *
     * @endif
     */
  public String type_name = null;

  /*!
     * @if jp
     * @brief 
     * @else
     * @brief polarity
     *
     * @section Description
     *
     * This attribute indicates whether the target interface instance
     * is provided or required by the RTC.
     *
     * @endif
     */
  public RTC.PortInterfacePolarity polarity = null;

  public PortInterfaceProfile ()
  {
  } // ctor

  public PortInterfaceProfile (String _instance_name, String _type_name, RTC.PortInterfacePolarity _polarity)
  {
    instance_name = _instance_name;
    type_name = _type_name;
    polarity = _polarity;
  } // ctor

} // class PortInterfaceProfile
