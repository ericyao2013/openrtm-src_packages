package RTC;


/**
* RTC/ExecutionContextServiceListHolder.java .
* IDL-to-Java �R���p�C�� (�|�[�^�u��), �o�[�W���� "3.1" �Ő���
* ������: idl/OpenRTM.idl
* 2010�N5��10�� 16��53��57�b JST
*/

public final class ExecutionContextServiceListHolder implements org.omg.CORBA.portable.Streamable
{
  public RTC.ExecutionContextService value[] = null;

  public ExecutionContextServiceListHolder ()
  {
  }

  public ExecutionContextServiceListHolder (RTC.ExecutionContextService[] initialValue)
  {
    value = initialValue;
  }

  public void _read (org.omg.CORBA.portable.InputStream i)
  {
    value = RTC.ExecutionContextServiceListHelper.read (i);
  }

  public void _write (org.omg.CORBA.portable.OutputStream o)
  {
    RTC.ExecutionContextServiceListHelper.write (o, value);
  }

  public org.omg.CORBA.TypeCode _type ()
  {
    return RTC.ExecutionContextServiceListHelper.type ();
  }

}
