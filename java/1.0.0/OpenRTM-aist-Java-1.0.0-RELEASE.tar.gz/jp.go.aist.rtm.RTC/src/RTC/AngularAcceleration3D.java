package RTC;


/**
* RTC/AngularAcceleration3D.java .
* IDL-to-Java �R���p�C�� (�|�[�^�u��), �o�[�W���� "3.1" �Ő���
* ������: idl/InterfaceDataTypes.idl
* 2010�N5��10�� 16��54��03�b JST
*/

public final class AngularAcceleration3D implements org.omg.CORBA.portable.IDLEntity
{

  /// Acceleration around the x axis, in radians per second per second.
  public double aax = (double)0;

  /// Acceleration around the y axis, in radians per second per second.
  public double aay = (double)0;

  /// Acceleration around the z axis, in radians per second per second.
  public double aaz = (double)0;

  public AngularAcceleration3D ()
  {
  } // ctor

  public AngularAcceleration3D (double _aax, double _aay, double _aaz)
  {
    aax = _aax;
    aay = _aay;
    aaz = _aaz;
  } // ctor

} // class AngularAcceleration3D
