package RTC;

/**
* RTC/FsmBehaviorProfileHolder.java .
* IDL-to-Java �R���p�C�� (�|�[�^�u��), �o�[�W���� "3.1" �Ő���
* ������: idl/OpenRTM.idl
* 2010�N5��10�� 16��53��57�b JST
*/

public final class FsmBehaviorProfileHolder implements org.omg.CORBA.portable.Streamable
{
  public RTC.FsmBehaviorProfile value = null;

  public FsmBehaviorProfileHolder ()
  {
  }

  public FsmBehaviorProfileHolder (RTC.FsmBehaviorProfile initialValue)
  {
    value = initialValue;
  }

  public void _read (org.omg.CORBA.portable.InputStream i)
  {
    value = RTC.FsmBehaviorProfileHelper.read (i);
  }

  public void _write (org.omg.CORBA.portable.OutputStream o)
  {
    RTC.FsmBehaviorProfileHelper.write (o, value);
  }

  public org.omg.CORBA.TypeCode _type ()
  {
    return RTC.FsmBehaviorProfileHelper.type ();
  }

}
