package RTC;


/**
* RTC/PointFeature.java .
* IDL-to-Java �R���p�C�� (�|�[�^�u��), �o�[�W���� "3.1" �Ő���
* ������: idl/InterfaceDataTypes.idl
* 2010�N5��10�� 16��54��04�b JST
*/

public final class PointFeature implements org.omg.CORBA.portable.IDLEntity
{

  /// Probability of the feature.
  public double probability = (double)0;

  /// Position of the feature.
  public RTC.Point2D position = null;

  /// Covariance matrix of the position.
  public RTC.PointCovariance2D covariance = null;

  public PointFeature ()
  {
  } // ctor

  public PointFeature (double _probability, RTC.Point2D _position, RTC.PointCovariance2D _covariance)
  {
    probability = _probability;
    position = _position;
    covariance = _covariance;
  } // ctor

} // class PointFeature
