package RTC;

/**
* RTC/IntensityDataHolder.java .
* IDL-to-Java �R���p�C�� (�|�[�^�u��), �o�[�W���� "3.1" �Ő���
* ������: idl/InterfaceDataTypes.idl
* 2010�N5��10�� 16��54��04�b JST
*/

public final class IntensityDataHolder implements org.omg.CORBA.portable.Streamable
{
  public RTC.IntensityData value = null;

  public IntensityDataHolder ()
  {
  }

  public IntensityDataHolder (RTC.IntensityData initialValue)
  {
    value = initialValue;
  }

  public void _read (org.omg.CORBA.portable.InputStream i)
  {
    value = RTC.IntensityDataHelper.read (i);
  }

  public void _write (org.omg.CORBA.portable.OutputStream o)
  {
    RTC.IntensityDataHelper.write (o, value);
  }

  public org.omg.CORBA.TypeCode _type ()
  {
    return RTC.IntensityDataHelper.type ();
  }

}
