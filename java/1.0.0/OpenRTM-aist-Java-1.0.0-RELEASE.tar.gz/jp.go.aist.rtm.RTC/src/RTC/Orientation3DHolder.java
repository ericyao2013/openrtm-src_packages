package RTC;

/**
* RTC/Orientation3DHolder.java .
* IDL-to-Java �R���p�C�� (�|�[�^�u��), �o�[�W���� "3.1" �Ő���
* ������: idl/InterfaceDataTypes.idl
* 2010�N5��10�� 16��54��03�b JST
*/

public final class Orientation3DHolder implements org.omg.CORBA.portable.Streamable
{
  public RTC.Orientation3D value = null;

  public Orientation3DHolder ()
  {
  }

  public Orientation3DHolder (RTC.Orientation3D initialValue)
  {
    value = initialValue;
  }

  public void _read (org.omg.CORBA.portable.InputStream i)
  {
    value = RTC.Orientation3DHelper.read (i);
  }

  public void _write (org.omg.CORBA.portable.OutputStream o)
  {
    RTC.Orientation3DHelper.write (o, value);
  }

  public org.omg.CORBA.TypeCode _type ()
  {
    return RTC.Orientation3DHelper.type ();
  }

}
