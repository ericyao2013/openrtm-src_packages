package jp.go.aist.rtm.RTC.sample.PortValueInput.view;

import javax.swing.BoxLayout;
import javax.swing.JPanel;

public class RootPane extends JPanel {

    private static final long serialVersionUID = 4643119789977766100L;

    public RootPane() {
        
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
    }
}
