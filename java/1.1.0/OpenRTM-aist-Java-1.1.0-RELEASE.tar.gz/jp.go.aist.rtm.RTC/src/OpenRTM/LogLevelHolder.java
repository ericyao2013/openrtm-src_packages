package OpenRTM;

/**
* OpenRTM/LogLevelHolder.java .
* IDL-to-Java \u30b3\u30f3\u30d1\u30a4\u30e9 (\u30dd\u30fc\u30bf\u30d6\u30eb), \u30d0\u30fc\u30b8\u30e7\u30f3 "3.1" \u3067\u751f\u6210
* \u751f\u6210\u5143: idl/Logger.idl
* 2015\u5e743\u670820\u65e5 14\u664235\u520650\u79d2 JST
*/


/*!
   * @if jp
   *
   * @brief \u00fdp\u00fd\u00fde\u00fd
   * 
   * \u00fdp\u00fd\u00fdec\u00fdp\u00fd\u00fde\u00fd\u00fd9\u00fd\u00b3\u00fd\u00fd\u00fd\u00fdb\u00fd\u00fd\u00fd>\u00fd\u00fd\u00b2\u00fd\u00fd\u00b0\u00fd#\u00fd\u00fd\u00fd!\u00fd
   * 
   *  - SILENT  : \u00fdn\u00fdW5\u00fd\u00fd\u00fdV\u00a5d\u00e4\u00fd\u00fd?\u00fd\u00fd\u00b5\u00fd\u00fd\u00fd\u00fd\u00fde\u00fd
   *  - ERROR   : \u00fd\u00fd\u00fd|\u00fd\u00fd/\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd$\u00fd\u00fd#\u00fd\u00fd\u00fd\u00fdp\u00fd\u00fde\u00fd
   *  - WARN    : \u00fd\u00fd\u00fd|\u00fd\u00e4\u00e4\u00a4\u00fd\u00fd\u00fd\u00fd\u00fdd\u00fd\u00fdd\u00fd\u00fdy\u00fd\u00fd\u00fd#\u00fd\u00fd\u00fd\u00fdp\u00fd\u00fde\u00fd
   *  - INFO    : \u00fdr\u00fdj\u00fd\u00be\u00fd\u00fd\u00fd\u00fd\u00fd\u009ad\u00fd\u00fd?\u00fd\u00fd\u00a5p\u00fd\u00fde\u00fd
   *  - NORMAL  : \u00fd>\u00fd\u00be\u00fd\u00fd\u00fd\u00fd\u00fd\u009ad\u00fd\u00fd?\u00fd\u00fd\u00a5p\u00fd\u00fde\u00fd
   *  - DEBUG   : \u00fd\u00e5%\u00e5\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u009ad\u00fd\u00fd\u00fdd\u00a5p\u00fd\u00fde\u00fd
   *  - TRACE   : \u00fd%|\u00fd\u00fd\u00fd\u00fde\u00fd\u00be\u00fd\u00fd\u00fd\u00fd\u00fd\u009ad\u00fd\u00fd\u00fdd\u00a5p\u00fd\u00fde\u00fd
   *  - VERBOSE : \u00fd%|\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00be\u00fd\u00fe:d\u00be\u00fd\u00fd\u00fd\u00fd\u00fd\u009ad\u00fd\u00fd\u00fdd\u00a5p\u00fd\u00fde\u00fd
   *  - PARANOID: \u00fdb\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00b9;\u00fd\u00fd\u00fd\u00be\u00fd\u00fd\u00fd\u00fd\u00fd\u009ad\u00fd\u00fd\u00fdp\u00fd\u00fde\u00fd
   * 
   * @else
   *
   * @brief Log level
   * 
   * This enumeration defines log levels. The log level consists of
   * nine levels, and each level means the following meaning.
   * 
   *  - SILENT  : Pseudo log level to stop logging function.
   *  - ERROR   : This log level means that an error event is occurring.
   *  - WARN    : This log level means that a warning event is occurring.
   *  - INFO    : This log level used to notify information.
   *  - NORMAL  : This log level means that an event is normal thing.
   *  - DEBUG   : This log level used to notify debugging information.
   *  - TRACE   : This log level used to notify trace information.
   *  - VERBOSE : This log level used to notify more detailed information.
   *  - PARANOID: This is used only to notify information in real-time loop.
   *
   * @endif
   */
public final class LogLevelHolder implements org.omg.CORBA.portable.Streamable
{
  public OpenRTM.LogLevel value = null;

  public LogLevelHolder ()
  {
  }

  public LogLevelHolder (OpenRTM.LogLevel initialValue)
  {
    value = initialValue;
  }

  public void _read (org.omg.CORBA.portable.InputStream i)
  {
    value = OpenRTM.LogLevelHelper.read (i);
  }

  public void _write (org.omg.CORBA.portable.OutputStream o)
  {
    OpenRTM.LogLevelHelper.write (o, value);
  }

  public org.omg.CORBA.TypeCode _type ()
  {
    return OpenRTM.LogLevelHelper.type ();
  }

}
