package OpenRTM;


/**
* OpenRTM/StatusKindHelper.java .
* IDL-to-Java \u30b3\u30f3\u30d1\u30a4\u30e9 (\u30dd\u30fc\u30bf\u30d6\u30eb), \u30d0\u30fc\u30b8\u30e7\u30f3 "3.1" \u3067\u751f\u6210
* \u751f\u6210\u5143: idl/ComponentObserver.idl
* 2015\u5e743\u670820\u65e5 14\u664235\u520649\u79d2 JST
*/


/*!
   * @if jp
   *
   * @brief \u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd?\u00fd\u00fd\u00fd\u00a4\u00bc\u00fd\u00fd\u00fd
   * 
   * \u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00e5\u00fdRTC\u00fd\u00f9\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd?\u00fd\u00fd\u00fd\u00a4\u00bc\u00fd\u00fd\u00fd\u00fd\u00ac\u00fd9\u00fd\u00fd\u00fd\u00fd\u009f\u00e1\u00fd
   * 
   * @else
   *
   * @brief A kind of updated status
   * 
   * This is a enumeration type to classify updated status in target RTC.
   *
   * @endif
   */
abstract public class StatusKindHelper
{
  private static String  _id = "IDL:OpenRTM/StatusKind:1.0";

  public static void insert (org.omg.CORBA.Any a, OpenRTM.StatusKind that)
  {
    org.omg.CORBA.portable.OutputStream out = a.create_output_stream ();
    a.type (type ());
    write (out, that);
    a.read_value (out.create_input_stream (), type ());
  }

  public static OpenRTM.StatusKind extract (org.omg.CORBA.Any a)
  {
    return read (a.create_input_stream ());
  }

  private static org.omg.CORBA.TypeCode __typeCode = null;
  synchronized public static org.omg.CORBA.TypeCode type ()
  {
    if (__typeCode == null)
    {
      __typeCode = org.omg.CORBA.ORB.init ().create_enum_tc (OpenRTM.StatusKindHelper.id (), "StatusKind", new String[] { "COMPONENT_PROFILE", "RTC_STATUS", "EC_STATUS", "PORT_PROFILE", "CONFIGURATION", "HEARTBEAT", "STATUS_KIND_NUM"} );
    }
    return __typeCode;
  }

  public static String id ()
  {
    return _id;
  }

  public static OpenRTM.StatusKind read (org.omg.CORBA.portable.InputStream istream)
  {
    return OpenRTM.StatusKind.from_int (istream.read_long ());
  }

  public static void write (org.omg.CORBA.portable.OutputStream ostream, OpenRTM.StatusKind value)
  {
    ostream.write_long (value.value ());
  }

}
