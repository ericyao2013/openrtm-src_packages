package OpenRTM;


/**
* OpenRTM/Logger.java .
* IDL-to-Java \u30b3\u30f3\u30d1\u30a4\u30e9 (\u30dd\u30fc\u30bf\u30d6\u30eb), \u30d0\u30fc\u30b8\u30e7\u30f3 "3.1" \u3067\u751f\u6210
* \u751f\u6210\u5143: idl/Logger.idl
* 2015\u5e743\u670820\u65e5 14\u664235\u520650\u79d2 JST
*/


/*!
   * @if jp
   *
   * @interface Logger \u00fd\u00fd\u00fdW\u00e1\u00fd\u00fde\u00fd\u00fd\u00fd\u00fd\u00fd
   *
   * \u00fd\u00fd\u00fd$\u00fdRTC\u00fd\u00a5p\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd?\u00fd\u00fd\u00a5\u00fd\u00fd\u00fd\u00fd\u00e5\u00fd\u00fd\u00fd\u00fdW\u00e1\u00fd\u00fde\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fdSDO
   * Service \u00fd$\u00fd\u00fd\u00fd\u00fd>d$\u00a4\u00fdRTC/SDO\u00fd\u00fd\u00fd$\u00fd\u00fd\u00a5\u00fd\u00fd\u00fd\u00fd\u00e5\u00fd\u00fd\u00fd\u00fdbRTC/SDO\u00fd\u00a5p
   * \u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fdc\u00fd\u00bad\u00bd\u00fd\u00fd\u00fd\u00fd\u00fdWd\u00f0\u00b2\u00fd\u00fd\u00fd\u00fd$\u00fd\u00e4\u00fd\u00fdc
   *
   * -# SDO::get_configuration() \u00fd\u00e4\u00fd\u00fd Configuration \u00fd\u00fd\u00fd\u00a5\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd$\u00fd\u00fd\u00fd\u00fd
   * -# Configuration::add_service_profile() \u00fd\u00e4\u00fd\u00fdTool\u00a6\u00fd\u00fd
   *     Logger \u00fd\u00fd ServiceProfile \u00fd\u00e4\u00fd\u00fd RTC \u00fd\u00fd\u00fd\u00fd\u00fdc
   *     ServiceProfile \u00fd\u00a5\u00fd\u00fd!\u00fd\u00fd\u00f0\u00b2\u00fd\u00fd\u00a4&\u00fd\u00fd\u00fd\u00fd\u00fd9\u00fd3\u00fd\u00fd
   *   - id: UUID \u00fd\u00a4p\u00fdd\u00fdID\u00fd\u00fd\u00fd\u00fd\u00fd9\u00fdc\u00fd\u00fd\u00fd\u00fd\u00fd\u00e4\u00fdl\u00fd\u00e4\u00e4\u00a4\u00fd\u00a4\u00e1\u00fdTool
   *     \u00a6\u00fd\u00e4\u00fdID\u00fd\u00fd\u00fd{\u00fd\u00a4\u00fd\u00fd\u00fd\u00fd\u00a4\u00fd\u00fd\u00fd$\u00a4\u00fd\u00a4\u00fd\u00fd\u00fd
   *   - interface_type: \u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00e5\u00fd\u00fd\u00fdIFR\u00fd\u00fdID\u00fd\u00fd\u00b8\u00fd\u00fd\u00fd\u00fd$\u00fd\u00fd\u00bb\u00fd\u00fdcRTC\u00a6\u00fd\u00fd
   *     \u00fd\u00e4\u00fd\u00fd\u00fd\u00b8\u00fd\u00fd\u00fd\u00fd\u00e4\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00e5\u00fd\u00fd\u00fd\u00fd\u00a5\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd$\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd+\u00fd\u00fd\u00fd9
   *     \u00fd?\u00fd\u00fd\u00fd\u00fd\u00fd\u00fdl\u00fd$$\u00a4c
   *   - properties: RTC\u00a6\u00fd\u00a5\u00fd\u00fd\u00fd\u00fd\u00e5\u00fd\u00fd\u00bc\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00a6\u00fd\u00fd\u00fd\u00fd\u00fd\u00a4\u00fd\u00fd\u00fd\u00e5\u00fde\u00a5\u00fd\u00fd\u00fd\u00fd\u00fd
   *     \u00fd9\u00fdc\u00fd\u00fd\u00fd\u00a5\u00fd\u00fd\u00fd\u00fd\u00e5\u00fd\u00fd\u00e4\u00e1\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00a5p\u00fd\u00fde\u00fd\u00fd\u00e2\u00fd\u00a5\u00e5\u00fde\u00a5\u00fd\u00fd\u00fd
   *     \u00fd\u00fd\u00fd9\u00fdc
   *    - service: SDOService \u00fd\u00fd\u00fd\u00a5\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd$\u00bb\u00fd\u00fd$\u00fd\u00fd\u00fd9\u00fdc
   * -# RTC\u00a6\u00fd\u00e5l\u00fd\u00fd\u00fd$\u00bdRy\u00fd\u00fd\u00e4\u00fdm\u00fd\u00e4\u00fd\u00fd\u00fd\u00fd\u00e4\u00fd publish() \u00fd\u00fd\u00fd\u00a5|\u00fd\u00fd\u00fd\u00fd\u00fd
   *     \u00fd\u00fd LogRecord \u00fd\u00fd\u00a4\u00fd\u00a4$\u00fd\u00fd\u00a5p\u00fd\u00fd\u00e5\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fdy\u00fd\u00fd\u00fd\u00fd\u00e4Wa\u00fd
   *     \u00fd\u00e5\u00fd\u00a6\u00fd\u00fd\u00fd\u00fd\u00fd\u00a4\u00fd\u00fdc\u00fd\u00fd\u00fd\u00fd\u00fd\u00e5\u00fd\u00fd\u00fd\u00fd{\u00fd\u00fd\u00a6\u00fd\u00e4\u00e1\u00fdLogRecord\u00fd\u00fd\u00be\u00fd\u00fd\u00fd
   *     \u00fd\u00fde\u00fd\u00fd\u00fd\u00fd\u00fd\u00fdRy\u00fd\u00fdb}\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00e1\u00fd\u00fd\u00fd\u00fd\u00fdd\u00fd\u00fd3\u00fd$\u00fd\u00fd\u00e4\u00fd\u00fdc
   * -# RTC\u00a6\u00fd\u00fd\u00fd\u00fd\u00bb\u00fd\u00fd\u00fd\u00fd$\u00fd\u00fd\u00e4\u00e1\u00fdclose() \u00fd\u00fd\u00fd\u00a5|\u00fd\u00fd\u00fd\u00fdR8\u00a4\u00fd$\u00fd\u00fd\u00fd\u00fd\u00fd
   *    \u00fd\u00e1\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00e5\u00fd\u00fd\u00fd\u00a6\u00fd\u00fdl\u00fd\u00a4\u00bd\u00fd\u00bb\u00fd\u00fd\u00fd\u00fd\u00fd$\u00fdl\u00fd\u00e4\u00fd\u00fd\u00fd\u00fdcclose()\u00fd\u00fd\u00fd\u00fd
   *    \u00fd$?\u00fd\u00fd\u00fd\u00e1\u00fdremove_service_profile() \u00fd\u00e4\u00fd\u00fd\u00fd\u00fd\u00fd\u00fdj\u00fd\u00e5\u00fd\u00fd\u00fd\u00fd\u00e5\u00fd\u00fd\u00fd
   *    \u00fd\u00fd\u00fd\u00fdl\u00fd\u00e4\u00e4\u00a4\u00fd\u00fd\u00fd\u00fd\u00a4\u00fdRTC\u00a6\u00fd\u00e4\u00fdclose() \u00fd\u00fd\u00a4\u00fd\u00fd\u00fd\u00fd\u00e1\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd
   *    \u00fd\u00e5\u00fd\u00fd\u00f4$\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd}\u00fd\u00fd\u00fd\u00fd\u00fd\u00fdl\u00fd\u00a4\u00f3\u00fd\u00fd\u00fd\u00a4\u00fd\u00fd\u00fd$\u00a4\u00fd\u00a4\u00fd\u00fd\u00fd
   * -# \u00fd!\u00fd\u00fd\u00fd\u00fd\u00fd\u00a5\u00fd\u00fd\u00fd\u00fd\u00e5\u00fd\u00fd\u00fd\u00a6\u00fd\u00fd\u00fd\u00fd\u00bb\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00a4d\u00e1\u00fd
   *    remove_service_profile() \u00fd\u00fd\u00fd\u00a5|\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00a4\u00fd$\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fdRTC\u00fd\u00fd\u00fd
   *    \u00fd}\u00fd\u00fd\u00fd\u00fd\u00fd\u00fdl\u00fd\u00a4\u00f3\u00fd\u00fd\u00fd\u00fdl\u00fd\u00e4\u00fd\u00fd\u00fd\u00fdcRTC\u00a6\u00fd\u00e1\u00fd
   *    remove_service_profile() \u00fd\u00fd\u00fd\u00a4\u00fd$\u00fd\u00fd?\u00fdd\u00e4\u00e1\u00fd\u00fd\u00fd\u00fd\u00fd\u00fdn\u00fdW$\u00f4\u00fd
   *    \u00fd\u00fd\u00fd\u00fd}\u00fd\u00fd\u00fd\u00fd\u00fd\u00fdl\u00fd\u00a4\u00f3\u00fd\u00fd\u00fd\u00fdl\u00fd\u00e4\u00fd\u00fd\u00fd\u00fdc
   *
   * \u00fdm\u00fd\u00a5\u00e5{\u00fd\u00fd\u00fd\u008b5\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fdW\u00a4\u00fc\u00fd\u00fd\u00fd\u00fd\u00fd
   *
   * <pre>
   * 
   *   [RTC]    [Configuration]           [Logger]      [Tool]
   *     |            |                       |            |
   *     |            | get_configuration()   |            |
   *     |<------------------------------------------------|
   *     |            |                       |            |
   *     |            | add_service_profile(prof)          |
   *     |            |<-----------------------------------|
   *     |            |                       |            |
   *     |            | publish(logrecord)    |            |
   *     |----------------------------------->|            |
   *     |            | publish(logrecord)    |            |
   *     |----------------------------------->|            |
   *     |            |       :               |            |
   *     |            |       :               |            |
   *     |            | 1) RTC\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00bb\u00fd\u00fd\u00fd\u00fd$\u00fd           |
   *     |            |       :               |            |
   *     |            | [close()]             |            |
   *     |----------------------------------->|            |
   *     |            |       :               |            |
   *     |            | 2) \u00fd!\u00fd\u00fd,\u00fdn\u00fdW$\u00fd\u00bb\u00fd\u00fd\u00fd\u00fd$\u00fd  |
   *     |            |       :               |            |
   *     |            | remove_service_profile(id)         |
   *     |            |<-----------------------------------|
   *     |            |                       |            |
   *     |            |                       x            x
   *
   * </pre>
   *
   * \u00fd\u00a4\u00fd\u00fd\u00fdServiceProfile::properties \u00fd\u00fb\u00fd\u00fd9\u00fd\u00fd\u00e5\u00fde\u00a5\u00fd\u00fd$\u00fd\u00fd\u00a4\u00e1\u00fd
   *
   * - logger.log_level: (ERROR, WARN, INFO, NORMAL, DEBUG, TRACE, VERBOSE,
   *                     PARANOID)
   * - logger.filter: logger name or "ALL"
   *
   * \u00fd\u00fd\u00fd\u00fd\u00fdb
   *
   * - logger.log_level: ERROR, WARN, INFO, NORMAL, DEBUG, TRACE,
   *   VERBOSE \u00fd\u00a4\u00fd\u00fd\u00fdPARANOID \u00fd\u00a4\u00fd\u00fd\u00fd\u00fd\u00fd$\u00fd\u00fd\u00fd9\u00fdc5\u00fd\u00fd\u00fd\u00fd\u00be\u00fd\u00fd\u00fd
   *   NORMAL \u00fd\u00fd\u00b1\u00fd\u00fd$\u00a4c\u00fd\u00fd\u00fd5\u00fd?\u00fd\u00fde\u00fd\u00fd\u00b1\u00fd\u00fd$\u00fd\u00e4\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd
   *   \u00fd\u00be\u00fd\u00fdR%n\u00fdW$\u00fd\u00fd\u00fdc\u00fd\u00fd\u00fd\u00a4\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd>\u00fd\u00fd\u00a5p\u00fd\u00fde\u00fd\u00fd\u00fd\u00fd7\u00fd\u00fd
   *   \u00fdd\u00fd\u00fd\u00fd\u00e4\u00fd\u00fd\u00fd\u00fdp\u00fd\u00f0\u00b2\u00fd\u00fd\u00b47\u00fd\u00fd\u00e4\u00a4c
   *   - ERROR   : (ERROR)
   *   - WARN    : (ERROR, WARN)
   *   - INFO    : (ERROR, WARN, INFO)
   *   - NORMAL  : (ERROR, WARN, INFO, NORMAL)
   *   - DEBUG   : (ERROR, WARN, INFO, NORMAL, DEBUG)
   *   - TRACE   : (ERROR, WARN, INFO, NORMAL, DEBUG, TRACE)
   *   - VERBOSE : (ERROR, WARN, INFO, NORMAL, DEBUG, TRACE, VERBOSE)
   *   - PARANOID: (ERROR, WARN, INFO, NORMAL, DEBUG, TRACE, VERBOSE, PARA)
   * - logger.filter: RTC\u00fd\u00fd\u00fd\u00fd\u00fd\u00e1\u00fdRTC\u00fd\u00fd\u00fd\u00a1\u00fd\u00fd\u00e1\u00fd\u00fd\u00fd\u00fda\u00fd\u00fd!\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00e5\u00fd\u00fda\u00fd\u00fd\u00fd
   *   \u00fd\u00fd>\u00fd\u00fd\u00a5\u00fd\u00fd\u00a5\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd$\u00e5l\u00fd\u00fd\u00fd\u00fd\u00fd\u00a5\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd$\u00fd\u00b8\u00fd\u00e4\u00fd\u00fdc\u00fd\u00fd\u00fd\u00a5\u00e5\u00fd
   *   \u00fde\u00a5\u00fd\u00fd\u00e5n\u00fdW$\u00fd\u00fd\u00fd\u00fd>d\u00a5l\u00fd\u00fd\u00fd\u00fd\u00fd\u00a5\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd$V\u00e5\u00fd\u00b6\u00fd\u00fd\u00a4\u00fd\u00fb\u00fd\u00fd\u00fd
   *   \u00fd\u00fd\u00fdc\u00fd\u00a4\u00fd\u00fd\u00e1\u00fdALL\u00fd\u00fd\u00fd\u00fd9\u00fd3\u00fd$\u00fdRTC\u00fd\u00f2\u00fd\u00fd\u00a4\u00fd\u00fdd\u00a4\u00a5n\u00fdW%\u00fd\u00fd\u00a5\u00fd\u00fd\u00fd
   *   \u00fd\u00fd\u00fd$\u00fd\u00fd\u00fd\u00a5\u00fd\u00e5\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fdc5\u00fd\u00fd\u00fd\u00fd\u00be\u00fd\u00fd\u00fdALL\u00fd\u00fd\u00b1\u00fd\u00fd\u00e4\u00a4c
   *
   * @else
   * @class
   *
   * @interface Logger interface
   *
   * This interface defines logging service for each RT-Component.
   * This service would be attached to a target RTC/SDO, and provides
   * functionality to collect log information from remote
   * applications.  Actual process sequences are the following.
   *
   * -# Get configuration object by SDO::get_configuration() 
   * -# Attach Logger object with ServiceProfile by
   *    Configuration::add_service_profile(). ServiceProfile should be
   *    set as follows.
   *   - id: An unique ID like UUID. This ID is used when this service
   *         is removed. Tools or applications should keep the ID for
   *         this.
   *   - interface_type: Specify this service's IFR ID in string. This
   *         string is used to search available service in the RTC,
   *         and if it matches with available SDO services, this
   *         service is accepted.
   *   - properties: This member specifies properties to notify
   *         information to the target RTC.  The following properties
   *         for log level and others would be specified in this
   *         properties.
   *
   *   - service: A SDOService object reference is specified.
   * -# When logging occurs in the RTC side, the "publish()" operation
   *    notifies a log message, time stump and so on to the service
   *    provider as a LogRecord structure. The service provider can
   *    use notified information for example writing to files and
   *    showing them on the display.
   * -# When RTC is terminated, the "close()" operation is called, and
   *    the service provider has to terminate the logging service
   *    properly.  In this case, tools and applications that have
   *    service provider do not need to call remove_service_profile()
   *    and remove the service explicitly. After calling close()
   *    operation, the RTC has to release the service profile and
   *    resources.
   * -# When tools and applications terminate services, they have to
   *    call remove_service_profile() operation, and have to release
   *    resources in the target RTC. When remove_service_profile() is
   *    called, the RTC have to release service profile and resources
   *    for this service.
   *
   * The following diagram shows above mentioned sequence.
   *
   * <pre>
   * 
   *   [RTC]    [Configuration]           [Logger]      [Tool]
   *     |            |                       |            |
   *     |            | get_configuration()   |            |
   *     |<------------------------------------------------|
   *     |            |                       |            |
   *     |            | add_service_profile(prof)          |
   *     |            |<-----------------------------------|
   *     |            |                       |            |
   *     |            | publish(logrecord)    |            |
   *     |----------------------------------->|            |
   *     |            | publish(logrecord)    |            |
   *     |----------------------------------->|            |
   *     |            |       :               |            |
   *     |            |       :               |            |
   *     |            | 1) When RTC is terminated          |
   *     |            |       :               |            |
   *     |            | [close()]             |            |
   *     |----------------------------------->|            |
   *     |            |       :               |            |
   *     |            | 2) When tool terminates logging    |
   *     |            |       :               |            |
   *     |            | remove_service_profile(id)         |
   *     |            |<-----------------------------------|
   *     |            |                       |            |
   *     |            |                       x            x
   *
   * </pre>
   *
   * So far, the following properties for ServiceProfile::properties
   * are available.
   *
   * - logger.log_level: (ERROR, WARN, INFO, NORMAL, DEBUG, TRACE, VERBOSE,
   *                     PARANOID)
   * - logger.filter: logger name or "ALL"
   *
   *
   * - logger.log_level: One of ERROR, WARN, INFO, NORMAL, DEBUG,
   *     TRACE, VERBOSE or PARANOID can be specified.  If no
   *     properties are specified, it will be NORMAL.  Log messages
   *     equals and/or more important specified log level would be
   *     published.  The following list shows the relation between
   *     specified level and published level.
   *   - ERROR   : (ERROR)
   *   - WARN    : (ERROR, WARN)
   *   - INFO    : (ERROR, WARN, INFO)
   *   - NORMAL  : (ERROR, WARN, INFO, NORMAL)
   *   - DEBUG   : (ERROR, WARN, INFO, NORMAL, DEBUG)
   *   - TRACE   : (ERROR, WARN, INFO, NORMAL, DEBUG, TRACE)
   *   - VERBOSE : (ERROR, WARN, INFO, NORMAL, DEBUG, TRACE, VERBOSE)
   *   - PARANOID: (ERROR, WARN, INFO, NORMAL, DEBUG, TRACE, VERBOSE, PARA)
   * - logger.filter: Some logger objects exist in some object of an
   *     RTC such as RTC body, data port, service port and so on.
   *     Some logger objects exist in some object of an RTC such as
   *     RTC body, data port, service port and so on.  This properties
   *     specify target logger names separated with commas.  If ALL is
   *     specified, all the logger's messages under the target RTC's
   *     logger would be published.  If no property is specified, all
   *     the messages will be published.
   *
   * @endif
   *
   */
public interface Logger extends LoggerOperations, _SDOPackage.SDOService, org.omg.CORBA.portable.IDLEntity 
{
} // interface Logger
