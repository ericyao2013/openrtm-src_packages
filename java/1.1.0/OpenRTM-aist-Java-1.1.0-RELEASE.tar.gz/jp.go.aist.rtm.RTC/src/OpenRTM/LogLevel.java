package OpenRTM;


/**
* OpenRTM/LogLevel.java .
* IDL-to-Java \u30b3\u30f3\u30d1\u30a4\u30e9 (\u30dd\u30fc\u30bf\u30d6\u30eb), \u30d0\u30fc\u30b8\u30e7\u30f3 "3.1" \u3067\u751f\u6210
* \u751f\u6210\u5143: idl/Logger.idl
* 2015\u5e743\u670820\u65e5 14\u664235\u520650\u79d2 JST
*/


/*!
   * @if jp
   *
   * @brief \u00fdp\u00fd\u00fde\u00fd
   * 
   * \u00fdp\u00fd\u00fdec\u00fdp\u00fd\u00fde\u00fd\u00fd9\u00fd\u00b3\u00fd\u00fd\u00fd\u00fdb\u00fd\u00fd\u00fd>\u00fd\u00fd\u00b2\u00fd\u00fd\u00b0\u00fd#\u00fd\u00fd\u00fd!\u00fd
   * 
   *  - SILENT  : \u00fdn\u00fdW5\u00fd\u00fd\u00fdV\u00a5d\u00e4\u00fd\u00fd?\u00fd\u00fd\u00b5\u00fd\u00fd\u00fd\u00fd\u00fde\u00fd
   *  - ERROR   : \u00fd\u00fd\u00fd|\u00fd\u00fd/\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd$\u00fd\u00fd#\u00fd\u00fd\u00fd\u00fdp\u00fd\u00fde\u00fd
   *  - WARN    : \u00fd\u00fd\u00fd|\u00fd\u00e4\u00e4\u00a4\u00fd\u00fd\u00fd\u00fd\u00fdd\u00fd\u00fdd\u00fd\u00fdy\u00fd\u00fd\u00fd#\u00fd\u00fd\u00fd\u00fdp\u00fd\u00fde\u00fd
   *  - INFO    : \u00fdr\u00fdj\u00fd\u00be\u00fd\u00fd\u00fd\u00fd\u00fd\u009ad\u00fd\u00fd?\u00fd\u00fd\u00a5p\u00fd\u00fde\u00fd
   *  - NORMAL  : \u00fd>\u00fd\u00be\u00fd\u00fd\u00fd\u00fd\u00fd\u009ad\u00fd\u00fd?\u00fd\u00fd\u00a5p\u00fd\u00fde\u00fd
   *  - DEBUG   : \u00fd\u00e5%\u00e5\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u009ad\u00fd\u00fd\u00fdd\u00a5p\u00fd\u00fde\u00fd
   *  - TRACE   : \u00fd%|\u00fd\u00fd\u00fd\u00fde\u00fd\u00be\u00fd\u00fd\u00fd\u00fd\u00fd\u009ad\u00fd\u00fd\u00fdd\u00a5p\u00fd\u00fde\u00fd
   *  - VERBOSE : \u00fd%|\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00be\u00fd\u00fe:d\u00be\u00fd\u00fd\u00fd\u00fd\u00fd\u009ad\u00fd\u00fd\u00fdd\u00a5p\u00fd\u00fde\u00fd
   *  - PARANOID: \u00fdb\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00fd\u00b9;\u00fd\u00fd\u00fd\u00be\u00fd\u00fd\u00fd\u00fd\u00fd\u009ad\u00fd\u00fd\u00fdp\u00fd\u00fde\u00fd
   * 
   * @else
   *
   * @brief Log level
   * 
   * This enumeration defines log levels. The log level consists of
   * nine levels, and each level means the following meaning.
   * 
   *  - SILENT  : Pseudo log level to stop logging function.
   *  - ERROR   : This log level means that an error event is occurring.
   *  - WARN    : This log level means that a warning event is occurring.
   *  - INFO    : This log level used to notify information.
   *  - NORMAL  : This log level means that an event is normal thing.
   *  - DEBUG   : This log level used to notify debugging information.
   *  - TRACE   : This log level used to notify trace information.
   *  - VERBOSE : This log level used to notify more detailed information.
   *  - PARANOID: This is used only to notify information in real-time loop.
   *
   * @endif
   */
public class LogLevel implements org.omg.CORBA.portable.IDLEntity
{
  private        int __value;
  private static int __size = 9;
  private static OpenRTM.LogLevel[] __array = new OpenRTM.LogLevel [__size];

  public static final int _SILENT = 0;
  public static final OpenRTM.LogLevel SILENT = new OpenRTM.LogLevel(_SILENT);
  public static final int _ERROR = 1;
  public static final OpenRTM.LogLevel ERROR = new OpenRTM.LogLevel(_ERROR);
  public static final int _WARN = 2;
  public static final OpenRTM.LogLevel WARN = new OpenRTM.LogLevel(_WARN);
  public static final int _INFO = 3;
  public static final OpenRTM.LogLevel INFO = new OpenRTM.LogLevel(_INFO);
  public static final int _NORMAL = 4;
  public static final OpenRTM.LogLevel NORMAL = new OpenRTM.LogLevel(_NORMAL);
  public static final int _DEBUG = 5;
  public static final OpenRTM.LogLevel DEBUG = new OpenRTM.LogLevel(_DEBUG);
  public static final int _TRACE = 6;
  public static final OpenRTM.LogLevel TRACE = new OpenRTM.LogLevel(_TRACE);
  public static final int _VERBOSE = 7;
  public static final OpenRTM.LogLevel VERBOSE = new OpenRTM.LogLevel(_VERBOSE);
  public static final int _PARANOID = 8;
  public static final OpenRTM.LogLevel PARANOID = new OpenRTM.LogLevel(_PARANOID);

  public int value ()
  {
    return __value;
  }

  public static OpenRTM.LogLevel from_int (int value)
  {
    if (value >= 0 && value < __size)
      return __array[value];
    else
      throw new org.omg.CORBA.BAD_PARAM ();
  }

  protected LogLevel (int value)
  {
    __value = value;
    __array[__value] = this;
  }
} // class LogLevel
