package OpenRTM;


/**
* OpenRTM/InPortCdrPOA.java .
* IDL-to-Java \u30b3\u30f3\u30d1\u30a4\u30e9 (\u30dd\u30fc\u30bf\u30d6\u30eb), \u30d0\u30fc\u30b8\u30e7\u30f3 "3.1" \u3067\u751f\u6210
* \u751f\u6210\u5143: idl/DataPort.idl
* 2015\u5e743\u670820\u65e5 14\u664235\u520645\u79d2 JST
*/

public abstract class InPortCdrPOA extends org.omg.PortableServer.Servant
 implements OpenRTM.InPortCdrOperations, org.omg.CORBA.portable.InvokeHandler
{

  // Constructors

  private static java.util.Hashtable _methods = new java.util.Hashtable ();
  static
  {
    _methods.put ("put", new java.lang.Integer (0));
  }

  public org.omg.CORBA.portable.OutputStream _invoke (String $method,
                                org.omg.CORBA.portable.InputStream in,
                                org.omg.CORBA.portable.ResponseHandler $rh)
  {
    org.omg.CORBA.portable.OutputStream out = null;
    java.lang.Integer __method = (java.lang.Integer)_methods.get ($method);
    if (__method == null)
      throw new org.omg.CORBA.BAD_OPERATION (0, org.omg.CORBA.CompletionStatus.COMPLETED_MAYBE);

    switch (__method.intValue ())
    {
       case 0:  // OpenRTM/InPortCdr/put
       {
         byte data[] = OpenRTM.CdrDataHelper.read (in);
         OpenRTM.PortStatus $result = null;
         $result = this.put (data);
         out = $rh.createReply();
         OpenRTM.PortStatusHelper.write (out, $result);
         break;
       }

       default:
         throw new org.omg.CORBA.BAD_OPERATION (0, org.omg.CORBA.CompletionStatus.COMPLETED_MAYBE);
    }

    return out;
  } // _invoke

  // Type-specific CORBA::Object operations
  private static String[] __ids = {
    "IDL:OpenRTM/InPortCdr:1.0"};

  public String[] _all_interfaces (org.omg.PortableServer.POA poa, byte[] objectId)
  {
    return (String[])__ids.clone ();
  }

  public InPortCdr _this() 
  {
    return InPortCdrHelper.narrow(
    super._this_object());
  }

  public InPortCdr _this(org.omg.CORBA.ORB orb) 
  {
    return InPortCdrHelper.narrow(
    super._this_object(orb));
  }


} // class InPortCdrPOA
