package RTC;


/**
* RTC/RangerConfig.java .
* IDL-to-Java \u30b3\u30f3\u30d1\u30a4\u30e9 (\u30dd\u30fc\u30bf\u30d6\u30eb), \u30d0\u30fc\u30b8\u30e7\u30f3 "3.1" \u3067\u751f\u6210
* \u751f\u6210\u5143: idl/InterfaceDataTypes.idl
* 2015\u5e743\u670820\u65e5 14\u664235\u520648\u79d2 JST
*/

public final class RangerConfig implements org.omg.CORBA.portable.IDLEntity
{

  /// Minimum scannable angle in radians.
  public double minAngle = (double)0;

  /// Maximum scannable angle in radians.
  public double maxAngle = (double)0;

  /// Angular resolution in radians.
  public double angularRes = (double)0;

  /// Minimum scannable range in metres.
  public double minRange = (double)0;

  /// Maximum scannable range in metres.
  public double maxRange = (double)0;

  /// Range resolution in metres.
  public double rangeRes = (double)0;

  /// Scanning frequency in Hertz.
  public double frequency = (double)0;

  public RangerConfig ()
  {
  } // ctor

  public RangerConfig (double _minAngle, double _maxAngle, double _angularRes, double _minRange, double _maxRange, double _rangeRes, double _frequency)
  {
    minAngle = _minAngle;
    maxAngle = _maxAngle;
    angularRes = _angularRes;
    minRange = _minRange;
    maxRange = _maxRange;
    rangeRes = _rangeRes;
    frequency = _frequency;
  } // ctor

} // class RangerConfig
