package RTC;


/**
* RTC/PanTiltState.java .
* IDL-to-Java \u30b3\u30f3\u30d1\u30a4\u30e9 (\u30dd\u30fc\u30bf\u30d6\u30eb), \u30d0\u30fc\u30b8\u30e7\u30f3 "3.1" \u3067\u751f\u6210
* \u751f\u6210\u5143: idl/InterfaceDataTypes.idl
* 2015\u5e743\u670820\u65e5 14\u664235\u520648\u79d2 JST
*/

public final class PanTiltState implements org.omg.CORBA.portable.IDLEntity
{

  /// Time stamp.
  public RTC.Time tm = null;

  /// Pan and tilt angles.
  public RTC.PanTiltAngles angles = null;

  /// Speed at which the pan-tilt unit is changing its pan angle in radians per second.
  public double panSpeed = (double)0;

  /// Speed at which the pan-tilt unit is changing its tilt angle in radians per second.
  public double tiltSpeed = (double)0;

  public PanTiltState ()
  {
  } // ctor

  public PanTiltState (RTC.Time _tm, RTC.PanTiltAngles _angles, double _panSpeed, double _tiltSpeed)
  {
    tm = _tm;
    angles = _angles;
    panSpeed = _panSpeed;
    tiltSpeed = _tiltSpeed;
  } // ctor

} // class PanTiltState
