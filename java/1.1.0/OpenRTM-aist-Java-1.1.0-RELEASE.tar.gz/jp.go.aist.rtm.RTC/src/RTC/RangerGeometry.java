package RTC;


/**
* RTC/RangerGeometry.java .
* IDL-to-Java \u30b3\u30f3\u30d1\u30a4\u30e9 (\u30dd\u30fc\u30bf\u30d6\u30eb), \u30d0\u30fc\u30b8\u30e7\u30f3 "3.1" \u3067\u751f\u6210
* \u751f\u6210\u5143: idl/InterfaceDataTypes.idl
* 2015\u5e743\u670820\u65e5 14\u664235\u520648\u79d2 JST
*/

public final class RangerGeometry implements org.omg.CORBA.portable.IDLEntity
{

  /// Overall geometry of the ranger device, such as the centroid of an array of sonar sensors.
  public RTC.Geometry3D geometry = null;

  /// measured from each of these.
  public RTC.Geometry3D elementGeometries[] = null;

  public RangerGeometry ()
  {
  } // ctor

  public RangerGeometry (RTC.Geometry3D _geometry, RTC.Geometry3D[] _elementGeometries)
  {
    geometry = _geometry;
    elementGeometries = _elementGeometries;
  } // ctor

} // class RangerGeometry
