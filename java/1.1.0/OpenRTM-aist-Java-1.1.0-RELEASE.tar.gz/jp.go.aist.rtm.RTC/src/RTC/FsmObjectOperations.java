package RTC;


/**
* RTC/FsmObjectOperations.java .
* IDL-to-Java \u30b3\u30f3\u30d1\u30a4\u30e9 (\u30dd\u30fc\u30bf\u30d6\u30eb), \u30d0\u30fc\u30b8\u30e7\u30f3 "3.1" \u3067\u751f\u6210
* \u751f\u6210\u5143: idl/LogicalTimeTriggeredEC.idl
* 2015\u5e743\u670820\u65e5 14\u664235\u520651\u79d2 JST
*/


/*!
   * @if jp
   * @brief 
   * @else
   * @brief FsmObject
   *
   * @section Description
   *
   * The FsmObject interface allows programs to send stimuli to a
   * finite state machine, possibly causing it to change states.
   *
   * @endif
   */
public interface FsmObjectOperations 
{

  /*!
       * @if jp
       * @brief 
       * @else
       * @brief send_stimulus
       *
       * @section Description
       *
       * Send a stimulus to an FSM that realizes this interface.
       *
       * @section Semantics
       *
       * If the stimulus corresponds to any outgoing transition of the
       * current state, that transition shall be taken and the state
       * shall change. Any FSM participants associated with the exit of
       * the current state, the transition to the new state, or the
       * entry to the new state shall be invoked. If the stimulus does
       * not correspond to any such transition, this operation shall
       * succeed but have no effect.  
       *
       * If the given execution context is a non-nil reference to a
       * context in which this FSM participates, the transition shall be
       * executed in that context. If the argument is nil, the FSM shall
       * choose an EVENT_DRIVEN context in which to execute the
       * transition. If the argument is non-nil, but this FSM does not
       * participate in the given context, this operation shall fail
       * with * ReturnCode_t::BAD_PARAMETER.
       *
       * @section Constraints
       *
       * - The given execution context shall be of kind EVENT_DRIVEN.
       *
       * @endif
       */
  RTC.ReturnCode_t send_stimulus (String message, int exec_handle);
} // interface FsmObjectOperations
