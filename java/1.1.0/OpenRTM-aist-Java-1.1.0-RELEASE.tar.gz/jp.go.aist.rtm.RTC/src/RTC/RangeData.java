package RTC;


/**
* RTC/RangeData.java .
* IDL-to-Java \u30b3\u30f3\u30d1\u30a4\u30e9 (\u30dd\u30fc\u30bf\u30d6\u30eb), \u30d0\u30fc\u30b8\u30e7\u30f3 "3.1" \u3067\u751f\u6210
* \u751f\u6210\u5143: idl/InterfaceDataTypes.idl
* 2015\u5e743\u670820\u65e5 14\u664235\u520648\u79d2 JST
*/

public final class RangeData implements org.omg.CORBA.portable.IDLEntity
{

  /// Time stamp.
  public RTC.Time tm = null;

  /// Range values in metres.
  public double ranges[] = null;

  /// Geometry of the ranger at the time the scan data was measured.
  public RTC.RangerGeometry geometry = null;

  /// Configuration of the ranger at the time the scan data was measured.
  public RTC.RangerConfig config = null;

  public RangeData ()
  {
  } // ctor

  public RangeData (RTC.Time _tm, double[] _ranges, RTC.RangerGeometry _geometry, RTC.RangerConfig _config)
  {
    tm = _tm;
    ranges = _ranges;
    geometry = _geometry;
    config = _config;
  } // ctor

} // class RangeData
