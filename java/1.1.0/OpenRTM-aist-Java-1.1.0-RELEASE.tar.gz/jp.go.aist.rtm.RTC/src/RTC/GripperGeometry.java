package RTC;


/**
* RTC/GripperGeometry.java .
* IDL-to-Java \u30b3\u30f3\u30d1\u30a4\u30e9 (\u30dd\u30fc\u30bf\u30d6\u30eb), \u30d0\u30fc\u30b8\u30e7\u30f3 "3.1" \u3067\u751f\u6210
* \u751f\u6210\u5143: idl/InterfaceDataTypes.idl
* 2015\u5e743\u670820\u65e5 14\u664235\u520648\u79d2 JST
*/

public final class GripperGeometry implements org.omg.CORBA.portable.IDLEntity
{

  /// Geometry of the exterior of the gripper when open, in parent coordinate space.
  public RTC.Geometry3D exterior = null;

  /// Geometry of the interior of the gripper when open, in gripper coordinate space.
  public RTC.Geometry3D interior = null;

  public GripperGeometry ()
  {
  } // ctor

  public GripperGeometry (RTC.Geometry3D _exterior, RTC.Geometry3D _interior)
  {
    exterior = _exterior;
    interior = _interior;
  } // ctor

} // class GripperGeometry
