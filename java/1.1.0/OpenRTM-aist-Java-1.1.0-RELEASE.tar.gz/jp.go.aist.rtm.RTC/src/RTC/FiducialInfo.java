package RTC;


/**
* RTC/FiducialInfo.java .
* IDL-to-Java \u30b3\u30f3\u30d1\u30a4\u30e9 (\u30dd\u30fc\u30bf\u30d6\u30eb), \u30d0\u30fc\u30b8\u30e7\u30f3 "3.1" \u3067\u751f\u6210
* \u751f\u6210\u5143: idl/InterfaceDataTypes.idl
* 2015\u5e743\u670820\u65e5 14\u664235\u520648\u79d2 JST
*/

public final class FiducialInfo implements org.omg.CORBA.portable.IDLEntity
{

  /// Identification number.
  public int id = (int)0;

  /// Detected pose.
  public RTC.Pose3D pose = null;

  /// Uncertainty in the pose.
  public RTC.Pose3D poseUncertainty = null;

  /// Detected size.
  public RTC.Size3D size = null;

  /// Uncertainty in the size.
  public RTC.Size3D sizeUncertainty = null;

  public FiducialInfo ()
  {
  } // ctor

  public FiducialInfo (int _id, RTC.Pose3D _pose, RTC.Pose3D _poseUncertainty, RTC.Size3D _size, RTC.Size3D _sizeUncertainty)
  {
    id = _id;
    pose = _pose;
    poseUncertainty = _poseUncertainty;
    size = _size;
    sizeUncertainty = _sizeUncertainty;
  } // ctor

} // class FiducialInfo
