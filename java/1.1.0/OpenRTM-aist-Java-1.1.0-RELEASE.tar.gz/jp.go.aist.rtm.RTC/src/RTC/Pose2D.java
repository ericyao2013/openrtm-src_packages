package RTC;


/**
* RTC/Pose2D.java .
* IDL-to-Java \u30b3\u30f3\u30d1\u30a4\u30e9 (\u30dd\u30fc\u30bf\u30d6\u30eb), \u30d0\u30fc\u30b8\u30e7\u30f3 "3.1" \u3067\u751f\u6210
* \u751f\u6210\u5143: idl/InterfaceDataTypes.idl
* 2015\u5e743\u670820\u65e5 14\u664235\u520648\u79d2 JST
*/

public final class Pose2D implements org.omg.CORBA.portable.IDLEntity
{

  /// 2D position.
  public RTC.Point2D position = null;

  /// Heading in radians.
  public double heading = (double)0;

  public Pose2D ()
  {
  } // ctor

  public Pose2D (RTC.Point2D _position, double _heading)
  {
    position = _position;
    heading = _heading;
  } // ctor

} // class Pose2D
