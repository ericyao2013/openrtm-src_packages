package RTC;


/**
* RTC/GripperStatus.java .
* IDL-to-Java \u30b3\u30f3\u30d1\u30a4\u30e9 (\u30dd\u30fc\u30bf\u30d6\u30eb), \u30d0\u30fc\u30b8\u30e7\u30f3 "3.1" \u3067\u751f\u6210
* \u751f\u6210\u5143: idl/InterfaceDataTypes.idl
* 2015\u5e743\u670820\u65e5 14\u664235\u520648\u79d2 JST
*/


/*!
     * @enum GripperStatus
     * @brief Describes the status of a gripper.
     */
public class GripperStatus implements org.omg.CORBA.portable.IDLEntity
{
  private        int __value;
  private static int __size = 4;
  private static RTC.GripperStatus[] __array = new RTC.GripperStatus [__size];

  public static final int _GRIPPER_STATE_OPEN = 0;
  public static final RTC.GripperStatus GRIPPER_STATE_OPEN = new RTC.GripperStatus(_GRIPPER_STATE_OPEN);
  public static final int _GRIPPER_STATE_CLOSED = 1;
  public static final RTC.GripperStatus GRIPPER_STATE_CLOSED = new RTC.GripperStatus(_GRIPPER_STATE_CLOSED);
  public static final int _GRIPPER_STATE_MOVING = 2;
  public static final RTC.GripperStatus GRIPPER_STATE_MOVING = new RTC.GripperStatus(_GRIPPER_STATE_MOVING);
  public static final int _GRIPPER_STATE_UNKNOWN = 3;
  public static final RTC.GripperStatus GRIPPER_STATE_UNKNOWN = new RTC.GripperStatus(_GRIPPER_STATE_UNKNOWN);

  public int value ()
  {
    return __value;
  }

  public static RTC.GripperStatus from_int (int value)
  {
    if (value >= 0 && value < __size)
      return __array[value];
    else
      throw new org.omg.CORBA.BAD_PARAM ();
  }

  protected GripperStatus (int value)
  {
    __value = value;
    __array[__value] = this;
  }
} // class GripperStatus
