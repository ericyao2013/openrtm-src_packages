package RTC;


/**
* RTC/BumperGeometry.java .
* IDL-to-Java \u30b3\u30f3\u30d1\u30a4\u30e9 (\u30dd\u30fc\u30bf\u30d6\u30eb), \u30d0\u30fc\u30b8\u30e7\u30f3 "3.1" \u3067\u751f\u6210
* \u751f\u6210\u5143: idl/InterfaceDataTypes.idl
* 2015\u5e743\u670820\u65e5 14\u664235\u520648\u79d2 JST
*/

public final class BumperGeometry implements org.omg.CORBA.portable.IDLEntity
{

  /// Pose of the bumper's base point in the array's coordinate space.
  public RTC.Pose3D pose = null;

  /// Size of the bumper.
  public RTC.Size3D size = null;

  /// Radius of curvature of the bump sensor in metres. Zero if the bumper is a straight line.
  public double roc = (double)0;

  public BumperGeometry ()
  {
  } // ctor

  public BumperGeometry (RTC.Pose3D _pose, RTC.Size3D _size, double _roc)
  {
    pose = _pose;
    size = _size;
    roc = _roc;
  } // ctor

} // class BumperGeometry
