package RTC;


/**
* RTC/ComponentActionOperations.java .
* IDL-to-Java \u30b3\u30f3\u30d1\u30a4\u30e9 (\u30dd\u30fc\u30bf\u30d6\u30eb), \u30d0\u30fc\u30b8\u30e7\u30f3 "3.1" \u3067\u751f\u6210
* \u751f\u6210\u5143: idl/LogicalTimeTriggeredEC.idl
* 2015\u5e743\u670820\u65e5 14\u664235\u520651\u79d2 JST
*/


/*!
   * @if jp
   * @brief
   * @else
   * @brief ComponentAction
   *
   * @section Description
   *
   * The ComponentAction interface provides callbacks corresponding to
   * the execution of the lifecycle operations of LightweightRTObject
   * (see Section 5.2.2.2) and ExecutionContext (see Section
   * 5.2.2.5). An RTC developer may implement these callback
   * operations in order to execute application-specific logic
   * pointing response to those transitions.
   *
   * @section Semantics
   *
   * Clients of an RTC are not expected to invoke these operations
   * directly; they are provided for the benefit of the RTC middleware
   * implementation.
   *
   * @endif
   */
public interface ComponentActionOperations 
{

  /*!
       * @if jp
       * @brief 
       * @else
       * @brief on_initialize
       *
       * @section Description
       *
       * The RTC has been initialized and entered the Alive state.
       *
       * @section Semantics
       *
       * Any RTC-specific initialization logic should be performed here.
       *
       * @endif
       */
  RTC.ReturnCode_t on_initialize ();

  /*!
       * @if jp
       * @brief 
       * @else
       * @brief on_finalize
       *
       * @section Description
       *
       * The RTC is being destroyed.
       *
       * @section Semantics
       *
       * Any final RTC-specific tear-down logic should be performed here.
       *
       * @endif
       */
  RTC.ReturnCode_t on_finalize ();

  /*!
       * @if jp
       * @brief 
       * @else
       * @brief on_startup
       *
       * @section Description
       *
       * The given execution context, in which the RTC is participating,
       * has transitioned from Stopped to Running.
       *
       * @endif
       */
  RTC.ReturnCode_t on_startup (int exec_handle);

  /*!
       * @if jp
       * @brief 
       * @else
       * @brief on_shutdown
       *
       * @section Description
       *
       * The given execution context, in which the RTC is participating,
       * has transitioned from Running to Stopped.
       *
       * @endif
       */
  RTC.ReturnCode_t on_shutdown (int exec_handle);

  /*!
       * @if jp
       * @brief 
       * @else
       * @brief on_activated
       *
       * @section Description
       *
       * The RTC has been activated in the given execution context.
       *
       * @endif
       */
  RTC.ReturnCode_t on_activated (int exec_handle);

  /*!
       * @if jp
       * @brief 
       * @else
       * @brief on_deactivated
       *
       * @section Description
       *
       * The RTC has been deactivated in the given execution context.
       *
       * @endif
       */
  RTC.ReturnCode_t on_deactivated (int exec_handle);

  /*!
       * @if jp
       * @brief 
       * @else
       * @brief on_aborting
       *
       * @section Description
       *
       * The RTC is transitioning from the Active state to the Error
       * state in some execution context.
       *
       * @section Semantics
       *
       * This callback is invoked only a single time for time that the
       * RTC transitions into the Error state from another state. This
       * behavior is in contrast to that of on_error.  
       *
       * @endif
       */
  RTC.ReturnCode_t on_aborting (int exec_handle);

  /*!
       * @if jp
       * @brief 
       * @else
       * @brief on_error
       *
       * @section Description
       *
       * The RTC remains in the Error state.
       *
       * @section Semantics
       *
       * If the RTC is in the Error state relative to some execution
       * context when it would otherwise be invoked from that context
       * (according to the context\u00fdfs ExecutionKind), this callback
       * shall be invoked instead. For example,
       *
       * - If the ExecutionKind is PERIODIC, this operation shall be
       *   invoked in sorted order at the rate of the context instead of
       *   DataFlowComponentAction::on_execute and on_state_update.
       *
       * - If the ExecutionKind is EVENT_DRIVEN, this operation shall be
       *   invoked whenever FsmParticipantAction::on_action would
       *   otherwise have been invoked.
       *
       * @endif
       */
  RTC.ReturnCode_t on_error (int exec_handle);

  /*!
       * @if jp
       * @brief 
       * @else
       * @brief on_reset
       *
       * @section Description
       *
       * The RTC is in the Error state. An attempt is being made to
       * recover it such that it can return to the Inactive state.
       *
       * @section Semantics
       *
       * If the RTC was successfully recovered and can safely return to
       * the Inactive state, this method shall complete with
       * ReturnCode_t::OK. Any other result shall indicate that the RTC
       * should remain in the Error state.
       *
       * @endif
       */
  RTC.ReturnCode_t on_reset (int exec_handle);
} // interface ComponentActionOperations
