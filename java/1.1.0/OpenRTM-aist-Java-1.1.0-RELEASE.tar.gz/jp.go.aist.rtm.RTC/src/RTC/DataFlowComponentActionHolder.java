package RTC;

/**
* RTC/DataFlowComponentActionHolder.java .
* IDL-to-Java \u30b3\u30f3\u30d1\u30a4\u30e9 (\u30dd\u30fc\u30bf\u30d6\u30eb), \u30d0\u30fc\u30b8\u30e7\u30f3 "3.1" \u3067\u751f\u6210
* \u751f\u6210\u5143: idl/LogicalTimeTriggeredEC.idl
* 2015\u5e743\u670820\u65e5 14\u664235\u520651\u79d2 JST
*/


/*!
   * @if jp
   * @brief 
   * @else
   * @brief DataFlowComponentAction
   *
   * @section Description
   *
   * DataFlowComponentAction is a companion to ComponentAction (see
   * Section 5.2.2.4) that provides additional callbacks for
   * intercepting the two execution passes defined in Section
   * 5.3.1.1.2.
   *
   * @endif
   */
public final class DataFlowComponentActionHolder implements org.omg.CORBA.portable.Streamable
{
  public RTC.DataFlowComponentAction value = null;

  public DataFlowComponentActionHolder ()
  {
  }

  public DataFlowComponentActionHolder (RTC.DataFlowComponentAction initialValue)
  {
    value = initialValue;
  }

  public void _read (org.omg.CORBA.portable.InputStream i)
  {
    value = RTC.DataFlowComponentActionHelper.read (i);
  }

  public void _write (org.omg.CORBA.portable.OutputStream o)
  {
    RTC.DataFlowComponentActionHelper.write (o, value);
  }

  public org.omg.CORBA.TypeCode _type ()
  {
    return RTC.DataFlowComponentActionHelper.type ();
  }

}
