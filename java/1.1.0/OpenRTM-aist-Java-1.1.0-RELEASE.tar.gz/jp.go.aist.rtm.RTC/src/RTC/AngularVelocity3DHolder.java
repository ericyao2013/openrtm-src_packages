package RTC;

/**
* RTC/AngularVelocity3DHolder.java .
* IDL-to-Java \u30b3\u30f3\u30d1\u30a4\u30e9 (\u30dd\u30fc\u30bf\u30d6\u30eb), \u30d0\u30fc\u30b8\u30e7\u30f3 "3.1" \u3067\u751f\u6210
* \u751f\u6210\u5143: idl/InterfaceDataTypes.idl
* 2015\u5e743\u670820\u65e5 14\u664235\u520648\u79d2 JST
*/

public final class AngularVelocity3DHolder implements org.omg.CORBA.portable.Streamable
{
  public RTC.AngularVelocity3D value = null;

  public AngularVelocity3DHolder ()
  {
  }

  public AngularVelocity3DHolder (RTC.AngularVelocity3D initialValue)
  {
    value = initialValue;
  }

  public void _read (org.omg.CORBA.portable.InputStream i)
  {
    value = RTC.AngularVelocity3DHelper.read (i);
  }

  public void _write (org.omg.CORBA.portable.OutputStream o)
  {
    RTC.AngularVelocity3DHelper.write (o, value);
  }

  public org.omg.CORBA.TypeCode _type ()
  {
    return RTC.AngularVelocity3DHelper.type ();
  }

}
