package RTC;

/**
* RTC/LifeCycleStateHolder.java .
* IDL-to-Java \u30b3\u30f3\u30d1\u30a4\u30e9 (\u30dd\u30fc\u30bf\u30d6\u30eb), \u30d0\u30fc\u30b8\u30e7\u30f3 "3.1" \u3067\u751f\u6210
* \u751f\u6210\u5143: idl/LogicalTimeTriggeredEC.idl
* 2015\u5e743\u670820\u65e5 14\u664235\u520651\u79d2 JST
*/


/*!
   * @if jp
   * @brief 
   * @else
   * @brief LifeCycleState
   *
   * @section Description
   * LifeCycleState is an enumeration of the states in the lifecycle above.
   *
   * @endif
   */
public final class LifeCycleStateHolder implements org.omg.CORBA.portable.Streamable
{
  public RTC.LifeCycleState value = null;

  public LifeCycleStateHolder ()
  {
  }

  public LifeCycleStateHolder (RTC.LifeCycleState initialValue)
  {
    value = initialValue;
  }

  public void _read (org.omg.CORBA.portable.InputStream i)
  {
    value = RTC.LifeCycleStateHelper.read (i);
  }

  public void _write (org.omg.CORBA.portable.OutputStream o)
  {
    RTC.LifeCycleStateHelper.write (o, value);
  }

  public org.omg.CORBA.TypeCode _type ()
  {
    return RTC.LifeCycleStateHelper.type ();
  }

}
