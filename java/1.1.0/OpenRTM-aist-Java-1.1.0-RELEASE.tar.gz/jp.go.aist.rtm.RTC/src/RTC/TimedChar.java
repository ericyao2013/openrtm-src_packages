package RTC;


/**
* RTC/TimedChar.java .
* IDL-to-Java \u30b3\u30f3\u30d1\u30a4\u30e9 (\u30dd\u30fc\u30bf\u30d6\u30eb), \u30d0\u30fc\u30b8\u30e7\u30f3 "3.1" \u3067\u751f\u6210
* \u751f\u6210\u5143: idl/Logger.idl
* 2015\u5e743\u670820\u65e5 14\u664235\u520650\u79d2 JST
*/

public final class TimedChar implements org.omg.CORBA.portable.IDLEntity
{
  public RTC.Time tm = null;
  public char data = (char)0;

  public TimedChar ()
  {
  } // ctor

  public TimedChar (RTC.Time _tm, char _data)
  {
    tm = _tm;
    data = _data;
  } // ctor

} // class TimedChar
