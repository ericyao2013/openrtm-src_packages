#!/usr/bin/env python
# -*- coding: euc-jp -*-

openrtm_name    = "OpenRTM-aist-1.0.2"
openrtm_version = "1.0.2"
corba_name      = "omniORB"
