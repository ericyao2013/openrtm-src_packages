#include "subscriber.h"

#include <iostream>

static const char* subscriber_spec[] =
{
    "implementation_id", "Subscriber",
    "type_name",         "Subscriber",
    "description",       "Example ROS subscriber",
    "version",           "1.0",
    "vendor",            "AIST",
    "category",          "Example",
    "activity_type",     "Periodic",
    "kind",              "DataFlowComponent",
    "max_instance",      "1",
    "language",          "C++",
    "lang_type",         "compile",
    "exec_cxt.periodic.rate", "1.0",
    ""
};

Subscriber::Subscriber(RTC::Manager* manager)
    : RTC::DataFlowComponentBase(manager),
    // The subscriber port is initialised here. We pass in the topic name, node
    // name and the variable the port will write its data to.
      _numIn("number", "test_ros_Sub", _num)
{
}

Subscriber::~Subscriber()
{
}

RTC::ReturnCode_t Subscriber::onInitialize()
{
    // Remember to add your port to your component - this is typically done in
    // onInitialize().
    addRosInPort("number", _numIn);
    return RTC::RTC_OK;
}

RTC::ReturnCode_t Subscriber::onExecute(RTC::UniqueId ec_id)
{
    // In onExecute, we can check if the port has any data waiting by calling
    // isEmpty().
    if (!_numIn.isEmpty())
    {
        // If there is, call read() to read the data into the destination
        // variable.
        _numIn.read();
        std::cout << "Read " << _num.num << std::endl;
    }
    return RTC::RTC_OK;
}

extern "C"
{
    void subscriberInit(RTC::Manager* manager)
    {
        RTC::Properties profile(subscriber_spec);
        manager->registerFactory(profile,
                RTC::Create<Subscriber>,
                RTC::Delete<Subscriber>);
    }
};

