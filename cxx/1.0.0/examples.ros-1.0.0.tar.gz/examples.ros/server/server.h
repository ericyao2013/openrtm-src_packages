#ifndef SERVER_H
#define SERVER_H

#include <rtm/Manager.h>
#include <rtm/DataFlowComponentBase.h>
#include <rtm/RosServerPort.h>
#include "AddTwoInts.h"
#include <iostream>

using namespace RTC;

// Inherit from RosServiceHandler to create a functor that implements our
// service's behaviour. Don't forget to make your functor copy-constructable,
// and remember that the operator() method must be public.
class Handler
    : public RosServiceHandler
{
    public:
        virtual bool operator()(beginner_tutorials::AddTwoInts::Request &req,
                beginner_tutorials::AddTwoInts::Response &resp)
        {
            resp.sum = req.a + req.b;
            std::cout << req.a << " + " << req.b << " = " << resp.sum <<
                std::endl;
            // Return true for success.
            return true;
        }
};

class Server
    : public RTC::DataFlowComponentBase
{
    public:
        Server(RTC::Manager* manager);
        ~Server();

        virtual RTC::ReturnCode_t onInitialize();

    protected:
        // This creates the port, specifying the data types of the request and
        // reply.
        RosServerPort<beginner_tutorials::AddTwoInts::Request,
                      beginner_tutorials::AddTwoInts::Response> _port;
        // Also create a handler functor object - this will be reponsible for
        // handling all calls to the service.
        Handler _handler;
};

extern "C"
{
    void serverInit(RTC::Manager* manager);
};

#endif // SERVER_H

