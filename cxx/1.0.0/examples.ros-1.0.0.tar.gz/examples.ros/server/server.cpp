#include "server.h"

static const char* server_spec[] =
{
    "implementation_id", "Server",
    "type_name",         "Server",
    "description",       "Example ROS service server",
    "version",           "1.0",
    "vendor",            "AIST",
    "category",          "Example",
    "activity_type",     "PERIODIC",
    "kind",              "DataFlowComponent",
    "max_instance",      "1",
    "language",          "C++",
    "lang_type",         "compile",
    "exec_cxt.periodic.rate", "1.0",
    ""
};

Server::Server(RTC::Manager* manager)
    : RTC::DataFlowComponentBase(manager),
    // The service port is initialised here. We pass in the topic name, node
    // name and the functor object.
    _port("add_two_ints", "test_server", _handler)
{
}

Server::~Server()
{
}

RTC::ReturnCode_t Server::onInitialize()
{
    // Remember to add your port to your component - this is typically done in
    // onInitialize().
    addRosServerPort("add_two_ints", _port);
    return RTC::RTC_OK;
}

// No onExecute is necessary because we do not have any other behaviour.

extern "C"
{
    void serverInit(RTC::Manager* manager)
    {
        RTC::Properties profile(server_spec);
        manager->registerFactory(profile,
                RTC::Create<Server>,
                RTC::Delete<Server>);
    }
};

