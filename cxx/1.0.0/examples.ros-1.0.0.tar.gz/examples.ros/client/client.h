#ifndef CLIENT_H
#define CLIENT_H

#include <rtm/Manager.h>
#include <rtm/DataFlowComponentBase.h>
#include <rtm/RosClientPort.h>
#include "AddTwoInts.h"

using namespace RTC;

class Client
: public RTC::DataFlowComponentBase
{
    public:
        Client(RTC::Manager* manager);
        ~Client();

        virtual RTC::ReturnCode_t onInitialize();
        virtual RTC::ReturnCode_t onExecute(RTC::UniqueId ec_id);

    protected:
        // This creates the port. We need to tell it the type of request it
        // will be handling, which we get from the header generated from the
        // message definition.
        RosClientPort<beginner_tutorials::AddTwoInts> _port;
};

extern "C"
{
    void clientInit(RTC::Manager* manager);
};

#endif // CLIENT_H

