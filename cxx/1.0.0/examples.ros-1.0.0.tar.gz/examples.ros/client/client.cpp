#include "client.h"

#include <iostream>

static const char* client_spec[] =
{
    "implementation_id", "Client",
    "type_name",         "Client",
    "description",       "Example ROS service client",
    "version",           "1.0",
    "vendor",            "AIST",
    "category",          "Example",
    "activity_type",     "PERIODIC",
    "kind",              "DataFlowComponent",
    "max_instance",      "1",
    "language",          "C++",
    "lang_type",         "compile",
    "exec_cxt.periodic.rate", "1.0",
    ""
};

Client::Client(RTC::Manager* manager)
    : RTC::DataFlowComponentBase(manager),
    // The service port is initialised here. We pass in the topic name and node
    // name.
    _port("add_two_ints", "test_ros")
{
}

Client::~Client()
{
}

RTC::ReturnCode_t Client::onInitialize()
{
    // Remember to add your port to your component - this is typically done in
    // onInitialize().
    addRosClientPort("add_two_ints", _port);
    return RTC::RTC_OK;
}

RTC::ReturnCode_t Client::onExecute(RTC::UniqueId ec_id)
{
    // In onExecute, we can make a call to the server by constructing an
    // instance of our request type and passing it to the port.
    beginner_tutorials::AddTwoInts srv;
    srv.request.a = 40;
    srv.request.b = 2;
    if (!_port.call(srv))
        std::cout << "Failed to call server" << std::endl;
    else
        std::cout << "Got result: " << srv.response.sum << std::endl;
    return RTC::RTC_OK;
}

extern "C"
{
    void clientInit(RTC::Manager* manager)
    {
        RTC::Properties profile(client_spec);
        manager->registerFactory(profile,
                RTC::Create<Client>,
                RTC::Delete<Client>);
    }
};

