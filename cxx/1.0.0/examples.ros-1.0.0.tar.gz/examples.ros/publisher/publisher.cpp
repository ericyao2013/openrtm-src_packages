#include "publisher.h"

#include <iostream>

static const char* publisher_spec[] =
{
    "implementation_id", "Publisher",
    "type_name",         "Publisher",
    "description",       "Example ROS publisher",
    "version",           "1.0",
    "vendor",            "AIST",
    "category",          "Example",
    "activity_type",     "PERIODIC",
    "kind",              "DataFlowComponent",
    "max_instance",      "1",
    "language",          "C++",
    "lang_type",         "compile",
    "exec_cxt.periodic.rate", "1.0",
    ""
};

Publisher::Publisher(RTC::Manager* manager)
    : RTC::DataFlowComponentBase(manager),
    // The publisher port is initialised here. We pass in the topic name, node
    // name and the variable the port will source its data from.
    _numOut("number", "test_ros", _num)
{
}

Publisher::~Publisher()
{
}

RTC::ReturnCode_t Publisher::onInitialize()
{
    // Remember to add your port to your component - this is typically done in
    // onInitialize().
    addRosOutPort("number", _numOut);
    return RTC::RTC_OK;
}

RTC::ReturnCode_t Publisher::onExecute(RTC::UniqueId ec_id)
{
    // In onExecute, we can write data to the port by setting the value of our
    // source variable, then calling write() on the port.
    // It is also possible to write to the port by creating another variable
    // (of the correct type, of course), and passing that to the write() call.
    _num.num += 1;
    _numOut.write();
    std::cout << "Wrote " << _num.num << std::endl;
    return RTC::RTC_OK;
}


extern "C"
{
    void publisherInit(RTC::Manager* manager)
    {
        RTC::Properties profile(publisher_spec);
        manager->registerFactory(profile,
                RTC::Create<Publisher>,
                RTC::Delete<Publisher>);
    }
};

