// -*- C++ -*-
/*!
 * @file ConnectorBase.h
 * @brief Connector base class
 * @date $Date$
 * @author Noriaki Ando <n-ando@aist.go.jp>
 *
 * Copyright (C) 2009
 *     Noriaki Ando
 *     Task-intelligence Research Group,
 *     Intelligent Systems Research Institute,
 *     National Institute of
 *         Advanced Industrial Science and Technology (AIST), Japan
 *     All rights reserved.
 *
 * $Id$
 *
 */

#ifndef RTC_CONNECTORBASE_H
#define RTC_CONNECTORBASE_H

#include <coil/stringutil.h>
#include <coil/Properties.h>

#include <rtm/RTC.h>
#include <rtm/CdrBufferBase.h>
#include <rtm/DataPortStatus.h>
#include <rtm/SystemLogger.h>

namespace RTC
{
  /*!
   * @if jp
   * @class ConnectorInfo �N���X
   * @brief ConnectorInfo �N���X
   *
   * @class ConnectorInfo class
   * @brief ConnectorInfo class
   *
   * @endif
   */
  class ConnectorInfo
  {
  public:
    /*!
     * @if jp
     *
     * @brief �R���X�g���N�^
     * 
     * �R���X�g���N�^
     *
     * @param name_ �ڑ����O
     * @param id_ �ڑ�ID
     * @param ports_ �ڑ��|�[�gIOR
     * @param properties_ �v���p�e�B
     * 
     * @else
     *
     * @brief Constructor
     * 
     * Constructor
     *
     * @param name_ connection name
     * @param id_ connection ID
     * @param ports_ connection Ports
     * @param properties_ connection properties
     *
     * @endif
     */
    ConnectorInfo(const char* name_, const char* id_,
                  coil::vstring ports_, coil::Properties properties_)
      : name(name_), id(id_)
      , ports(ports_), properties(properties_)
    {
    }
    /*!
     * @if jp
     *
     * @brief �R���X�g���N�^
     * 
     * �R���X�g���N�^
     *
     * @else
     *
     * @brief Constructor
     * 
     * Constructor
     *
     * @endif
     */
    ConnectorInfo()
    {
    }
    /*!
     * @if jp
     * @brief  �ڑ����O
     * @else
     * @brief  Connection name
     * @endif
     */
    std::string name;
    /*!
     * @if jp
     * @brief  �ڑ�ID
     * @else
     * @brief  ConnectionID 
     * @endif
     */
    std::string id;
    /*!
     * @if jp
     * @brief  �ڑ��|�[�gIOR
     * @else
     * @brief  Connection ports
     * @endif
     */
    coil::vstring ports;
    /*!
     * @if jp
     * @brief  �v���p�e�B
     * @else
     * @brief  Connection properties 
     * @endif
     */
    coil::Properties properties;
  };

  typedef std::vector<ConnectorInfo> ConnectorInfoList;

  class ConnectorBase;
  typedef std::vector<ConnectorBase*> ConnectorList;
  

  /*!
   * @if jp
   * @class ConnectorBase
   * @brief Connector ���N���X
   *
   * InPort/OutPort, Push/Pull �e�� Connector ��h�������邽�߂�
   * ���N���X�B
   *
   * @since 1.0.0
   *
   * @else
   * @class ConnectorBase
   * @brief Connector Base class
   *
   * The base class to derive subclasses for InPort/OutPort,
   * Push/Pull Connectors
   *
   * @since 1.0.0
   *
   * @endif
   */
  class ConnectorBase
    : public DataPortStatus
  {
  public:
    DATAPORTSTATUS_ENUM

    /*!
     * @if jp
     * @class Profile
     * @brief Connector profile ���[�J���\����
     *
     * ConnectorBase ����т��̔h���N���X�ň��� ConnectorProfile �\���́B
     *
     * @since 1.0.0
     *
     * @else
     * @class Profile
     * @brief local representation of Connector profile
     *
     * ConnectorProfile struct for ConnectorBase and its subclasses.
     *
     * @since 1.0.0
     *
     * @endif
     */



    /*!
     * @if jp
     * @brief �f�X�g���N�^
     * @else
     * @brief Destructor
     * @endif
     */
    virtual ~ConnectorBase(){};

   /*!
     * @if jp
     * @brief Profile �擾
     *
     * Connector Profile ���擾����
     *
     * @else
     * @brief Getting Profile
     *
     * This operation returns Connector Profile
     *
     * @endif
     */
    virtual const ConnectorInfo& profile() = 0;

    /*!
     * @if jp
     * @brief Connector ID �擾
     *
     * Connector ID ���擾����
     *
     * @else
     * @brief Getting Connector ID
     *
     * This operation returns Connector ID
     *
     * @endif
     */
    virtual const char* id() = 0;

    /*!
     * @if jp
     * @brief Connector ���擾
     *
     * Connector �����擾����
     *
     * @else
     * @brief Getting Connector name
     *
     * This operation returns Connector name
     *
     * @endif
     */
    virtual const char* name() = 0;

    /*!
     * @if jp
     * @brief �ڑ������֐�
     *
     * Connector ���ێ����Ă���ڑ�����������
     *
     * @else
     * @brief Disconnect connection
     *
     * This operation disconnect this connection
     *
     * @endif
     */
    virtual ReturnCode disconnect() = 0;

    /*!
     * @if jp
     * @brief Buffer ���擾����
     *
     * Connector ���ێ����Ă��� Buffer ��Ԃ�
     *
     * @else
     * @brief Getting Buffer
     *
     * This operation returns this connector's buffer
     *
     * @endif
     */
    virtual CdrBufferBase* getBuffer() = 0;

    /*!
     * @if jp
     * @brief �A�N�e�B�u��
     *
     * ���̃R�l�N�^���A�N�e�B�u������
     *
     * @else
     *
     * @brief Connector activation
     *
     * This operation activates this connector
     *
     * @endif
     */
    virtual void activate() = 0;

    /*!
     * @if jp
     * @brief ��A�N�e�B�u��
     *
     * ���̃R�l�N�^���A�N�e�B�u������
     *
     * @else
     *
     * @brief Connector deactivation
     *
     * This operation deactivates this connector
     *
     * @endif
     */
    virtual void deactivate() = 0;

  private:
    // non-copyable class
    //    ConnectorBase(const ConnectorBase& x);
    //    ConnectorBase& operator=(const ConnectorBase& x);
  };
}; // namespace RTC

#endif // RTC_CONNECTORBASE_H
