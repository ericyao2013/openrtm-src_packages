// -*- C++ -*-

#include "OpenHRPExecutionContext.h"
#include <rtm/ECFactory.h>

namespace RTC
{
  /*!
   * @if jp
   * @brief �R���X�g���N�^
   * @else
   * @brief Constructor
   * @endif
   */
  OpenHRPExecutionContext::OpenHRPExecutionContext()
    : PeriodicExecutionContext()
  {
  }

  /*!
   * @if jp
   * @brief �f�X�g���N�^
   * @else
   * @brief Destructor 
   * @endif
   */
  OpenHRPExecutionContext::~OpenHRPExecutionContext()
  {
  }

  /*!
   * @if jp
   * @brief ExecutionContext�̏�����i�߂�
   * @else
   * @brief Proceed with tick of ExecutionContext
   * @endif
   */
  void OpenHRPExecutionContext::tick()
    throw (CORBA::SystemException)
  {
    std::for_each(m_comps.begin(), m_comps.end(), invoke_worker());
    return;
  }

  /*!
   * @if jp
   * @brief ExecutionContext �̃X���b�h���s�t���O
   * @else
   * @brief The thread running flag of ExecutionContext
   * @endif
   */
  int OpenHRPExecutionContext::svc(void)
  {
    return 0;
  }
};


extern "C"
{
  /*!
   * @if jp
   * @brief ECFactory�ւ̓o�^�̂��߂̏������֐�
   * @else
   * @brief Initialization function to register to ECFactory
   * @endif
   */
  void OpenHRPExecutionContextInit(RTC::Manager* manager)
  {
    manager->registerECFactory("SynchExtTriggerEC",
			       RTC::ECCreate<RTC::OpenHRPExecutionContext>,
			       RTC::ECDelete<RTC::OpenHRPExecutionContext>);
    
  }
};
