// -*- C++ -*-
/*!
 * @file ConfigurationListener.h
 * @brief Configuration related event listener classes
 * @date $Date$
 * @author Noriaki Ando <n-ando@aist.go.jp>
 *
 * Copyright (C) 2011
 *     Noriaki Ando
 *     Intelligent Systems Research Institute,
 *     National Institute of
 *         Advanced Industrial Science and Technology (AIST), Japan
 *     All rights reserved.
 *
 * $Id$
 *
 */

#ifndef RTC_CONFIGURATIONLISTENER_H
#define RTC_CONFIGURATIONLISTENER_H

#include <vector>
#include <coil/Properties.h>
#include <coil/Mutex.h>
#include <coil/Guard.h>

namespace RTC
{
  //============================================================
  /*!
   * @if jp
   * @brief ConfigurationParamListener �̃^�C�v
   *
   * - ON_UPDATE_CONFIG_PARAM,
   *
   * @else
   * @brief The types of ConnectorDataListener
   * 
   * - ON_UPDATE_CONFIG_PARAM,
   *
   * @endif
   */
  enum ConfigurationParamListenerType
    {
      ON_UPDATE_CONFIG_PARAM,
      CONFIG_PARAM_LISTENER_NUM
    };


  /*!
   * @if jp
   * @class ConfigurationParamListener �N���X
   * @brief ConfigurationParamListener �N���X
   *
   * Configuration �p�����[�^�̕ύX�Ɋւ��郊�X�i�N���X�B
   * �ȉ��̃C�x���g�ɑ΂��ăR�[���o�b�N�����B
   *
   * - ON_UPDATE_CONFIG_PARAM
   *
   * @else
   * @class ConfigurationParamListener class
   * @brief ConfigurationParamListener class
   *
   * This class is abstract base class for listener classes that
   * provides callbacks for various events for Configuration parameter.
   * The listener will be called on the following event.
   *
   * - ON_UPDATE_CONFIG_PARAM
   *
   * @endif
   */
  class ConfigurationParamListener
  {
  public:
    /*!
     * @if jp
     *
     * @brief ConfigurationParamListenerType �𕶎���ɕϊ�
     *
     * ConfigurationParamListenerType �𕶎���ɕϊ�����
     *
     * @param type �ϊ��Ώ� ConfigurationParamListenerType
     *
     * @return ������ϊ�����
     *
     * @else
     *
     * @brief Convert ConfigurationParamListenerType into the string.
     *
     * Convert ConfigurationParamListenerType into the string.
     *
     * @param type The target ConfigurationParamListenerType for transformation
     *
     * @return Trnasformation result of string representation
     *
     * @endif
     */
    static const char* toString(ConfigurationParamListenerType type)
    {
      static const char* typeString[] =
        {
          "ON_UPDATE_CONFIG_PARAM",
          "CONFIG_PARAM_LISTENER_NUM"
        };
      if (type < CONFIG_PARAM_LISTENER_NUM)
        {
          return typeString[type];
        }
      return "";
    }

    /*!
     * @if jp
     * @brief �f�X�g���N�^
     * @else
     * @brief Destructor
     * @endif
     */
    virtual ~ConfigurationParamListener();

    /*!
     * @if jp
     *
     * @brief ���z�R�[���o�b�N�֐�
     *
     * ConfigurationParamListener �̃R�[���o�b�N�֐�
     *
     * @else
     *
     * @brief Virtual Callback function
     *
     * This is a the Callback function for ConfigurationParamListener.
     *
     * @endif
     */
    virtual void operator()(const char* config_set_name,
                            const char* config_param_name) = 0;
  };


  //============================================================
  /*!
   * @if jp
   * @brief ConfigurationSetListener �̃^�C�v
   *
   * - ON_SET_CONFIG_SET: ConfigurationSet �P�ʂŒl���Z�b�g���ꂽ
   * - ON_ADD_CONFIG_SET: ConfigurationSet ���ǉ����ꂽ
   *
   * @else
   * @brief The types of ConfigurationSetListener
   * 
   * - ON_SET_CONFIG_SET: Value list has been set as a configuration set 
   * - ON_ADD_CONFIG_SET: A new configuration set has been added
   *
   * @endif
   */

  enum ConfigurationSetListenerType
    {
      ON_SET_CONFIG_SET,
      ON_ADD_CONFIG_SET,
      CONFIG_SET_LISTENER_NUM
    };

  /*!
   * @if jp
   * @class ConfigurationSetListener �N���X
   * @brief ConfigurationSetListener �N���X
   *
   * Configuration�Z�b�g���ύX���ꂽ��ǉ����ꂽ�ꍇ�ɌĂяo����郊�X�i�N���X�B
   * �ȉ���Configuration�Z�b�g�Ɋ֘A����C�x���g�ɑ΂��郊�X�i�B
   *
   * - ON_SET_CONFIG_SET: ConfigurationSet �P�ʂŒl���Z�b�g���ꂽ
   * - ON_ADD_CONFIG_SET: ConfigurationSet ���ǉ����ꂽ
   *
   * @else
   * @class ConfigurationSetListener class
   * @brief ConfigurationSetListener class
   *
   * This class is abstract base class for listener classes that
   * provides callbacks for configuration set's related events.
   *
   * - ON_SET_CONFIG_SET: Value list has been set as a configuration set 
   * - ON_ADD_CONFIG_SET: A new configuration set has been added
   *
   * @endif
   */
  class ConfigurationSetListener
  {
  public:
    /*!
     * @if jp
     *
     * @brief ConfigurationSetNameListenerType �𕶎���ɕϊ�
     *
     * ConfigurationSetNameListenerType �𕶎���ɕϊ�����
     *
     * @param type �ϊ��Ώ� ConfigurationSetNameListenerType
     *
     * @return ������ϊ�����
     *
     * @else
     *
     * @brief Convert ConfigurationSetNameListenerType into the string.
     *
     * Convert ConfigurationSetNameListenerType into the string.
     *
     * @param type The target ConfigurationSetNameListenerType for
     *             transformation
     *
     * @return Trnasformation result of string representation
     *
     * @endif
     */
    static const char* toString(ConfigurationSetListenerType type)
    {
      static const char* typeString[] =
        {
          "ON_SET_CONFIG_SET",
          "ON_ADD_CONFIG_SET",
          "CONFIG_SET_LISTENER_NUM"
        };
      if (type < CONFIG_SET_LISTENER_NUM) { return typeString[type]; }
      return "";
    }

    /*!
     * @if jp
     * @brief �f�X�g���N�^
     * @else
     * @brief Destructor
     * @endif
     */
    virtual ~ConfigurationSetListener();

    /*!
     * @if jp
     *
     * @brief ���z�R�[���o�b�N�֐�
     *
     * ConfigurationSetListener �̃R�[���o�b�N�֐�
     *
     * @else
     *
     * @brief Virtual Callback function
     *
     * This is a the Callback function for ConfigurationSetListener
     *
     * @endif
     */
    virtual void operator()(const coil::Properties& config_set) = 0;
  };


  //============================================================
  /*!
   * @if jp
   * @brief ConfigurationSetNameListenerType
   *
   *
   * @else
   * @brief The types of ConfigurationSetNameListener
   * 
   * @endif
   */
  enum ConfigurationSetNameListenerType
    {
      ON_UPDATE_CONFIG_SET,
      ON_REMOVE_CONFIG_SET,
      ON_ACTIVATE_CONFIG_SET,
      CONFIG_SET_NAME_LISTENER_NUM
    };

  /*!
   * @if jp
   * @class ConfigurationSetNameListener �N���X
   * @brief ConfigurationSetNameListener �N���X
   *
   * ConfigurationSet�Ɋւ���C�x���g�Ɋւ��郊�X�i�[�N���X�B
   *
   * - ON_UPDATE_CONFIG_SET:
   * - ON_REMOVE_CONFIG_SET:
   * - ON_ACTIVATE_CONFIG_SET:
   *
   * @else
   * @class ConfigurationSetNameListener class
   * @brief ConfigurationSetNameListener class
   *
   * This class is abstract base class for listener classes that
   * provides callbacks for various events for ConfigurationSet.
   *
   * - ON_UPDATE_CONFIG_SET:
   * - ON_REMOVE_CONFIG_SET:
   * - ON_ACTIVATE_CONFIG_SET:
   *
   * @endif
   */
  class ConfigurationSetNameListener
  {
  public:
    /*!
     * @if jp
     *
     * @brief ConfigurationSetNameListenerType �𕶎���ɕϊ�
     *
     * ConfigurationSetNameListenerType �𕶎���ɕϊ�����
     *
     * @param type �ϊ��Ώ� ConfigurationSetNameListenerType
     *
     * @return ������ϊ�����
     *
     * @else
     *
     * @brief Convert ConfigurationSetNameListenerType into the string.
     *
     * Convert ConfigurationSetNameListenerType into the string.
     *
     * @param type The target ConfigurationSetNameListenerType for
     *             transformation
     *
     * @return Trnasformation result of string representation
     *
     * @endif
     */
    static const char* toString(ConfigurationSetNameListenerType type)
    {
      static const char* typeString[] =
        {
          "ON_UPDATE_CONFIG_SET",
          "ON_REMOVE_CONFIG_SET",
          "ON_ACTIVATE_CONFIG_SET",
          "CONFIG_SET_NAME_LISTENER_NUM"
        };
      if (type < CONFIG_SET_NAME_LISTENER_NUM) { return typeString[type]; }
      return "";
    }

    /*!
     * @if jp
     * @brief �f�X�g���N�^
     * @else
     * @brief Destructor
     * @endif
     */
    virtual ~ConfigurationSetNameListener();

    /*!
     * @if jp
     *
     * @brief ���z�R�[���o�b�N�֐�
     *
     * ConfigurationSetNameListener �̃R�[���o�b�N�֐�
     *
     * @else
     *
     * @brief Virtual Callback function
     *
     * This is a the Callback function for ConfigurationSetNameListener.
     *
     * @endif
     */
    virtual void operator()(const char* config_set_name) = 0;
  };


  /*!
   * @if jp
   * @class ConfigurationParamListenerHolder
   * @brief ConfigurationParamListener �z���_�N���X
   *
   * ������ ConfigurationParamListener ��ێ����Ǘ�����N���X�B
   *
   * @else
   * @class ConfigurationParamListenerHolder
   * @brief ConfigurationParamListener holder class
   *
   * This class manages one ore more instances of
   * ConfigurationParamListener class.
   *
   * @endif
   */
  class ConfigurationParamListenerHolder
  {
    typedef std::pair<ConfigurationParamListener*, bool> Entry;
    typedef coil::Guard<coil::Mutex> Guard;
  public:
    /*!
     * @if jp
     * @brief �R���X�g���N�^
     * @else
     * @brief Constructor
     * @endif
     */
    ConfigurationParamListenerHolder();
    /*!
     * @if jp
     * @brief �f�X�g���N�^
     * @else
     * @brief Destructor
     * @endif
     */
    virtual ~ConfigurationParamListenerHolder();
    
    /*!
     * @if jp
     *
     * @brief ���X�i�[�̒ǉ�
     *
     * ���X�i�[��ǉ�����B
     *
     * @param listener �ǉ����郊�X�i
     * @param autoclean true:�f�X�g���N�^�ō폜����,
     *                  false:�f�X�g���N�^�ō폜���Ȃ�
     * @else
     *
     * @brief Add the listener.
     *
     * This method adds the listener. 
     *
     * @param listener Added listener
     * @param autoclean true:The listener is deleted at the destructor.,
     *                  false:The listener is not deleted at the destructor. 
     * @endif
     */
    void addListener(ConfigurationParamListener* listener, bool autoclean);
    
    /*!
     * @if jp
     *
     * @brief ���X�i�[�̍폜
     *
     * ���X�i���폜����B
     *
     * @param listener �폜���郊�X�i
     * @else
     *
     * @brief Remove the listener. 
     *
     * This method removes the listener. 
     *
     * @param listener Removed listener
     * @endif
     */
    void removeListener(ConfigurationParamListener* listener);
    
    /*!
     * @if jp
     *
     * @brief ���X�i�[�֒ʒm����
     *
     * �o�^����Ă��郊�X�i�̃R�[���o�b�N���\�b�h���Ăяo���B
     *
     * @param info ConnectorInfo
     * @param cdrdata �f�[�^
     * @else
     *
     * @brief Notify listeners. 
     *
     * This calls the Callback method of the registered listener. 
     *
     * @param info ConnectorInfo
     * @param cdrdata Data
     * @endif
     */
    void notify(const char* config_set_name, const char* config_param_name);
    
  private:
    std::vector<Entry> m_listeners;
    coil::Mutex m_mutex;
  };


  //============================================================
  /*!
   * @if jp
   * @class ConfigurationSetListenerHolder
   * @brief ConfigurationSetListener �z���_�N���X
   *
   * ������ ConfigurationSetListener ��ێ����Ǘ�����N���X�B
   *
   * @else
   * @class ConfigurationSetListenerHolder
   * @brief ConfigurationSetListener holder class
   *
   * This class manages one ore more instances of
   * ConfigurationSetListener class.
   *
   * @endif
   */
  class ConfigurationSetListenerHolder
  {
    typedef std::pair<ConfigurationSetListener*, bool> Entry;
    typedef coil::Guard<coil::Mutex> Guard;
  public:
    /*!
     * @if jp
     * @brief �R���X�g���N�^
     * @else
     * @brief Constructor
     * @endif
     */
    ConfigurationSetListenerHolder();
    /*!
     * @if jp
     * @brief �f�X�g���N�^
     * @else
     * @brief Destructor
     * @endif
     */
    virtual ~ConfigurationSetListenerHolder();
    
    /*!
     * @if jp
     *
     * @brief ���X�i�[�̒ǉ�
     *
     * ���X�i�[��ǉ�����B
     *
     * @param listener �ǉ����郊�X�i
     * @param autoclean true:�f�X�g���N�^�ō폜����,
     *                  false:�f�X�g���N�^�ō폜���Ȃ�
     * @else
     *
     * @brief Add the listener.
     *
     * This method adds the listener. 
     *
     * @param listener Added listener
     * @param autoclean true:The listener is deleted at the destructor.,
     *                  false:The listener is not deleted at the destructor. 
     * @endif
     */
    void addListener(ConfigurationSetListener* listener, bool autoclean);
    
    /*!
     * @if jp
     *
     * @brief ���X�i�[�̍폜
     *
     * ���X�i���폜����B
     *
     * @param listener �폜���郊�X�i
     * @else
     *
     * @brief Remove the listener. 
     *
     * This method removes the listener. 
     *
     * @param listener Removed listener
     * @endif
     */
    void removeListener(ConfigurationSetListener* listener);
    
    /*!
     * @if jp
     *
     * @brief ���X�i�[�֒ʒm����
     *
     * �o�^����Ă��郊�X�i�̃R�[���o�b�N���\�b�h���Ăяo���B
     *
     * @param info ConnectorInfo
     * @param cdrdata �f�[�^
     * @else
     *
     * @brief Notify listeners. 
     *
     * This calls the Callback method of the registered listener. 
     *
     * @param info ConnectorInfo
     * @param cdrdata Data
     * @endif
     */
    void notify(const coil::Properties& config_set);
    
  private:
    std::vector<Entry> m_listeners;
    coil::Mutex m_mutex;
  };


  //============================================================
  /*!
   * @if jp
   * @class ConfigurationSetNameListenerHolder 
   * @brief ConfigurationSetNameListener �z���_�N���X
   *
   * ������ ConfigurationSetNameListener ��ێ����Ǘ�����N���X�B
   *
   * @else
   * @class ConfigurationSetNameListenerHolder
   * @brief ConfigurationSetNameListener holder class
   *
   * This class manages one ore more instances of
   * ConfigurationSetNameListener class.
   *
   * @endif
   */
  class ConfigurationSetNameListenerHolder
  {
    typedef std::pair<ConfigurationSetNameListener*, bool> Entry;
    typedef coil::Guard<coil::Mutex> Guard;
  public:
    /*!
     * @if jp
     * @brief �R���X�g���N�^
     * @else
     * @brief Constructor
     * @endif
     */
    ConfigurationSetNameListenerHolder();
    
    /*!
     * @if jp
     * @brief �f�X�g���N�^
     * @else
     * @brief Destructor
     * @endif
     */
    virtual ~ConfigurationSetNameListenerHolder();
    
    /*!
     * @if jp
     *
     * @brief ���X�i�[�̒ǉ�
     *
     * ���X�i�[��ǉ�����B
     *
     * @param listener �ǉ����郊�X�i
     * @param autoclean true:�f�X�g���N�^�ō폜����,
     *                  false:�f�X�g���N�^�ō폜���Ȃ�
     * @else
     *
     * @brief Add the listener.
     *
     * This method adds the listener. 
     *
     * @param listener Added listener
     * @param autoclean true:The listener is deleted at the destructor.,
     *                  false:The listener is not deleted at the destructor. 
     * @endif
     */
    void addListener(ConfigurationSetNameListener* listener, bool autoclean);
    
    /*!
     * @if jp
     *
     * @brief ���X�i�[�̍폜
     *
     * ���X�i���폜����B
     *
     * @param listener �폜���郊�X�i
     * @else
     *
     * @brief Remove the listener. 
     *
     * This method removes the listener. 
     *
     * @param listener Removed listener
     * @endif
     */
    void removeListener(ConfigurationSetNameListener* listener);

    /*!
     * @if jp
     *
     * @brief ���X�i�[�֒ʒm����
     *
     * �o�^����Ă��郊�X�i�̃R�[���o�b�N���\�b�h���Ăяo���B
     *
     * @param info ConnectorInfo
     * @else
     *
     * @brief Notify listeners. 
     *
     * This calls the Callback method of the registered listener. 
     *
     * @param info ConnectorInfo
     * @endif
     */
    void notify(const char* config_set_name);
      
  private:
    std::vector<Entry> m_listeners;
    coil::Mutex m_mutex;
  };

  //------------------------------------------------------------
  /*!
   * @if jp
   * @class ConfigurationActionListeners
   * @brief ConfigurationActionListeners �N���X
   *
   *
   * @else
   * @class ConfigurationActionListeners
   * @brief ConfigurationActionListeners class
   *
   *
   * @endif
   */
  class ConfigurationListeners
  {
  public:
    /*!
     * @if jp
     * @brief ConfigurationParamType���X�i�z��
     * ConfigurationParamType���X�i���i�[
     * @else
     * @brief ConfigurationParamType listener array
     * The ConfigurationParamType listener is stored.
     * @endif
     */
    ConfigurationParamListenerHolder 
    configparam_[CONFIG_PARAM_LISTENER_NUM];
    /*!
     * @if jp
     * @brief ConfigurationSetType���X�i�z��
     * ConfigurationSetType���X�i���i�[
     * @else
     * @brief ConfigurationSetType listener array
     * The ConfigurationSetType listener is stored.
     * @endif
     */
    ConfigurationSetListenerHolder
    configset_[CONFIG_SET_LISTENER_NUM];
    /*!
     * @if jp
     * @brief ConfigurationSetNameListenerType���X�i�z��
     * ConfigurationSetNameListenerType���X�i���i�[
     * @else
     * @brief ConfigurationSetNameListenerType listener array
     * The ConfigurationSetNameListenerType listener is stored. 
     * @endif
     */
    ConfigurationSetNameListenerHolder 
    configsetname_[CONFIG_SET_NAME_LISTENER_NUM];
  };


}; // namespace RTC

#endif // RTC_CONFIGURATIONLISTENER_H
