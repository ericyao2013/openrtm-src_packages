// -*- C++ -*-
/*!
 * @file ComponentActionListener.h
 * @brief component action listener class
 * @date $Date$
 * @author Noriaki Ando <n-ando@aist.go.jp>
 *
 * Copyright (C) 2011
 *     Noriaki Ando
 *     Intelligent Systems Research Institute,
 *     National Institute of
 *         Advanced Industrial Science and Technology (AIST), Japan
 *     All rights reserved.
 *
 * $Id$
 *
 */

#ifndef RTC_COMPONENTACTIONLISTENER_H
#define RTC_COMPONENTACTIONLISTENER_H

#include <vector>
#include <utility>
#include <coil/Mutex.h>
#include <coil/Guard.h>
#include <rtm/RTC.h>
#include <rtm/idl/RTCSkel.h>
#include <rtm/ConnectorBase.h>

namespace RTC
{
  typedef ExecutionContextHandle_t UniqueId;
  //============================================================
  /*!
   * @if jp
   * @brief PreComponentActionListener �̃^�C�v
   *
   * - PRE_ON_INITIALIZE:    onInitialize ���O
   * - PRE_ON_FINALIZE:      onFinalize ���O
   * - PRE_ON_STARTUP:       onStartup ���O
   * - PRE_ON_SHUTDOWN:      onShutdown ���O
   * - PRE_ON_ACTIVATED:     onActivated ���O
   * - PRE_ON_DEACTIVATED:   onDeactivated ���O
   * - PRE_ON_ABORTING:      onAborted ���O
   * - PRE_ON_ERROR:         onError ���O
   * - PRE_ON_RESET:         onReset ���O
   * - PRE_ON_EXECUTE:       onExecute ���O
   * - PRE_ON_STATE_UPDATE:  onStateUpdate ���O
   * - PRE_ON_RATE_CHANGED:  onRateChanged ���O
   *
   * @else
   * @brief The types of ConnectorDataListener
   * 
   * @endif
   */

  enum PreComponentActionListenerType
    {
      PRE_ON_INITIALIZE,
      PRE_ON_FINALIZE,
      PRE_ON_STARTUP,
      PRE_ON_SHUTDOWN,
      PRE_ON_ACTIVATED,
      PRE_ON_DEACTIVATED,
      PRE_ON_ABORTING,
      PRE_ON_ERROR,
      PRE_ON_RESET,
      PRE_ON_EXECUTE,
      PRE_ON_STATE_UPDATE,
      PRE_ON_RATE_CHANGED,
      PRE_COMPONENT_ACTION_LISTENER_NUM
    };

  /*!
   * @if jp
   * @class PreComponentActionListener �N���X
   * @brief PreComponentActionListener �N���X
   *
   * OMG RTC�d�l�Œ�`����Ă���ȉ��̃R���|�[�l���g�A�N�V�����g�ɂ�
   * �āA
   *
   * - on_initialize()
   * - on_finalize()
   * - on_startup()
   * - on_shutdown()
   * - on_activated
   * - on_deactivated()
   * - on_aborted()
   * - on_error()
   * - on_reset()
   * - on_execute()
   * - on_state_update()
   * - on_rate_changed()
   *
   * �e�A�N�V�����ɑΉ����郆�[�U�[�R�[�h���Ă΂�钼�O�̃^�C�~���O
   * �ŃR�[������郊�X�i�N���X�̊��N���X�B
   *
   * - PRE_ON_INITIALIZE:
   * - PRE_ON_FINALIZE:
   * - PRE_ON_STARTUP:
   * - PRE_ON_SHUTDOWN:
   * - PRE_ON_ACTIVATED:
   * - PRE_ON_DEACTIVATED:
   * - PRE_ON_ABORTING:
   * - PRE_ON_ERROR:
   * - PRE_ON_RESET:
   * - PRE_IN_EXECUTE:
   * - PRE_ON_STATE_UPDATE:
   * - PRE_ON_RATE_CHANGED:
   *
   * @else
   * @class PreComponentActionListener class
   * @brief PreComponentActionListener class
   *
   * This class is abstract base class for listener classes that
   * provides callbacks for various events in rtobject.
   *
   * @endif
   */
  class PreComponentActionListener
  {
  public:
    /*!
     * @if jp
     *
     * @brief PreComponentActionListenerType �𕶎���ɕϊ�
     *
     * PreComponentActionListenerType �𕶎���ɕϊ�����
     *
     * @param type �ϊ��Ώ� PreComponentActionListenerType
     *
     * @return ������ϊ�����
     *
     * @else
     *
     * @brief Convert PreComponentActionListenerType into the string.
     *
     * Convert PreComponentActionListenerType into the string.
     *
     * @param type The target PreComponentActionListenerType for transformation
     *
     * @return Trnasformation result of string representation
     *
     * @endif
     */
    static const char* toString(PreComponentActionListenerType type)
    {
      static const char* typeString[] =
        {
          "PRE_ON_INITIALIZE",
          "PRE_ON_FINALIZE",
          "PRE_ON_STARTUP",
          "PRE_ON_SHUTDOWN",
          "PRE_ON_ACTIVATED",
          "PRE_ON_DEACTIVATED",
          "PRE_ON_ABORTING",
          "PRE_ON_ERROR",
          "PRE_ON_RESET",
          "PRE_ON_EXECUTE",
          "PRE_ON_STATE_UPDATE",
          "PRE_ON_RATE_CHANGED",
          "PRE_COMPONENT_ACTION_LISTENER_NUM"
        };
      if (type < PRE_COMPONENT_ACTION_LISTENER_NUM) { return typeString[type]; }
      return "";
    }

    /*!
     * @if jp
     * @brief �f�X�g���N�^
     * @else
     * @brief Destructor
     * @endif
     */
    virtual ~PreComponentActionListener();

    /*!
     * @if jp
     *
     * @brief ���z�R�[���o�b�N�֐�
     *
     * PreComponentActionListener �̃R�[���o�b�N�֐�
     *
     * @else
     *
     * @brief Virtual Callback function
     *
     * This is a the Callback function for PreComponentActionListener.
     *
     * @endif
     */
    virtual void operator()(UniqueId ec_id) = 0;
  };


  //============================================================
  /*!
   * @if jp
   * @brief PostCompoenntActionListener �̃^�C�v
   *
   * - POST_ON_INITIALIZE:
   * - POST_ON_FINALIZE:
   * - POST_ON_STARTUP:
   * - POST_ON_SHUTDOWN:
   * - POST_ON_ACTIVATED:
   * - POST_ON_DEACTIVATED:
   * - POST_ON_ABORTING:
   * - POST_ON_ERROR:
   * - POST_ON_RESET:
   * - POST_ON_EXECUTE:
   * - POST_ON_STATE_UPDATE:
   * - POST_ON_RATE_CHANGED:
   *
   * @else
   * @brief The types of ConnectorDataListener
   * 
   * @endif
   */
  enum PostComponentActionListenerType
    {
      POST_ON_INITIALIZE,
      POST_ON_FINALIZE,
      POST_ON_STARTUP,
      POST_ON_SHUTDOWN,
      POST_ON_ACTIVATED,
      POST_ON_DEACTIVATED,
      POST_ON_ABORTING,
      POST_ON_ERROR,
      POST_ON_RESET,
      POST_ON_EXECUTE,
      POST_ON_STATE_UPDATE,
      POST_ON_RATE_CHANGED,
      POST_COMPONENT_ACTION_LISTENER_NUM
    };


  /*!
   * @if jp
   * @class PostComponentActionListener �N���X
   * @brief PostComponentActionListener �N���X
   *
   * OMG RTC�d�l�Œ�`����Ă���ȉ��̃R���|�[�l���g�A�N�V�����g�ɂ�
   * �āA
   *
   * - on_initialize()
   * - on_finalize()
   * - on_startup()
   * - on_shutdown()
   * - on_activated
   * - on_deactivated()
   * - on_aborted()
   * - on_error()
   * - on_reset()
   * - on_execute()
   * - on_state_update()
   * - on_rate_changed()
   *
   * �e�A�N�V�����ɑΉ����郆�[�U�[�R�[�h���Ă΂�钼�O�̃^�C�~���O
   * �ŃR�[������郊�X�ȃN���X�̊��N���X�B
   *
   * - POST_ON_INITIALIZE:
   * - POST_ON_FINALIZE:
   * - POST_ON_STARTUP:
   * - POST_ON_SHUTDOWN:
   * - POST_ON_ACTIVATED:
   * - POST_ON_DEACTIVATED:
   * - POST_ON_ABORTING:
   * - POST_ON_ERROR:
   * - POST_ON_RESET:
   * - POST_ON_EXECUTE:
   * - POST_ON_STATE_UPDATE:
   * - POST_ON_RATE_CHANGED:
   *
   * @else
   * @class PostComponentActionListener class
   * @brief PostComponentActionListener class
   *
   * This class is abstract base class for listener classes that
   * provides callbacks for various events in rtobject.
   *
   * @endif
   */
  class PostComponentActionListener
  {
  public:
    /*!
     * @if jp
     *
     * @brief PostComponentActionListenerType �𕶎���ɕϊ�
     *
     * PostComponentActionListenerType �𕶎���ɕϊ�����
     *
     * @param type �ϊ��Ώ� PostComponentActionListenerType
     *
     * @return ������ϊ�����
     *
     * @else
     *
     * @brief Convert PostComponentActionListenerType into the string.
     *
     * Convert PostComponentActionListenerType into the string.
     *
     * @param type The target PostComponentActionListenerType for transformation
     *
     * @return Trnasformation result of string representation
     *
     * @endif
     */
    static const char* toString(PostComponentActionListenerType type)
    {
      static const char* typeString[] =
        {
          "POST_ON_INITIALIZE",
          "POST_ON_FINALIZE",
          "POST_ON_STARTUP",
          "POST_ON_SHUTDOWN",
          "POST_ON_ACTIVATED",
          "POST_ON_DEACTIVATED",
          "POST_ON_ABORTING",
          "POST_ON_ERROR",
          "POST_ON_RESET",
          "POST_ON_EXECUTE",
          "POST_ON_STATE_UPDATE",
          "POST_ON_RATE_CHANGED",
          "POST_COMPONENT_ACTION_LISTENER_NUM"
        };
      if (type < POST_COMPONENT_ACTION_LISTENER_NUM)
        {
          return typeString[type];
        }
      return "";
    }

    /*!
     * @if jp
     * @brief �f�X�g���N�^
     * @else
     * @brief Destructor
     * @endif
     */
    virtual ~PostComponentActionListener();

    /*!
     * @if jp
     *
     * @brief ���z�R�[���o�b�N�֐�
     *
     * PostComponentActionListener �̃R�[���o�b�N�֐�
     *
     * @else
     *
     * @brief Virtual Callback function
     *
     * This is a the Callback function for PostComponentActionListener.
     *
     * @endif
     */
    virtual void operator()(UniqueId ec_id,
                            ReturnCode_t ret) = 0;
  };

  //============================================================
  /*!
   * @if jp
   * @brief PortActionListener �̃^�C�v
   *
   * - ADD_PORT:             Port �ǉ���
   * - REMOVE_PORT:          Port �폜��
   *
   * @else
   * @brief The types of PortActionListener
   * 
   * @endif
   */

  enum PortActionListenerType
    {
      ADD_PORT,
      REMOVE_PORT,
      PORT_ACTION_LISTENER_NUM
    };

  /*!
   * @if jp
   * @class PortActionListener �N���X
   * @brief PortActionListener �N���X
   *
   * �e�A�N�V�����ɑΉ����郆�[�U�[�R�[�h���Ă΂�钼�O�̃^�C�~���O
   * �ŃR�[������郊�X�ȃN���X�̊��N���X�B
   *
   * - ADD_PORT:
   * - REMOVE_PORT:
   *
   * @else
   * @class PortActionListener class
   * @brief PortActionListener class
   *
   * This class is abstract base class for listener classes that
   * provides callbacks for various events in rtobject.
   *
   * @endif
   */
  class PortActionListener
  {
  public:
    /*!
     * @if jp
     *
     * @brief PreComponentActionListenerType �𕶎���ɕϊ�
     *
     * PreComponentActionListenerType �𕶎���ɕϊ�����
     *
     * @param type �ϊ��Ώ� PreComponentActionListenerType
     *
     * @return ������ϊ�����
     *
     * @else
     *
     * @brief Convert PreComponentActionListenerType into the string.
     *
     * Convert PreComponentActionListenerType into the string.
     *
     * @param type The target PreComponentActionListenerType for transformation
     *
     * @return Trnasformation result of string representation
     *
     * @endif
     */
    static const char* toString(PortActionListenerType type)
    {
      static const char* typeString[] =
        {
          "ADD_PORT",
          "REMOVE_PORT",
          "PORT_ACTION_LISTENER_NUM"
        };
      if (type < PORT_ACTION_LISTENER_NUM) { return typeString[type]; }
      return "";
    }

    /*!
     * @if jp
     * @brief �f�X�g���N�^
     * @else
     * @brief Destructor
     * @endif
     */
    virtual ~PortActionListener();

    /*!
     * @if jp
     *
     * @brief ���z�R�[���o�b�N�֐�
     *
     * PortActionListener �̃R�[���o�b�N�֐�
     *
     * @else
     *
     * @brief Virtual Callback function
     *
     * This is a the Callback function for PortActionListener
     *
     * @endif
     */
    virtual void operator()(const ::RTC::PortProfile& pprof) = 0;
  };


  //============================================================
  /*!
   * @if jp
   * @brief ExecutionContextActionListener �̃^�C�v
   *
   * - ADD_PORT:             ExecutionContext �ǉ���
   * - REMOVE_PORT:          ExecutionContext �폜��
   *
   * @else
   * @brief The types of ExecutionContextActionListener
   * 
   * @endif
   */

  enum ExecutionContextActionListenerType
    {
      EC_ATTACHED,
      EC_DETACHED,
      EC_ACTION_LISTENER_NUM
    };

  /*!
   * @if jp
   * @class ExecutionContextActionListener �N���X
   * @brief ExecutionContextActionListener �N���X
   *
   * �e�A�N�V�����ɑΉ����郆�[�U�[�R�[�h���Ă΂�钼�O�̃^�C�~���O
   * �ŃR�[������郊�X�ȃN���X�̊��N���X�B
   *
   * - ADD_PORT:
   * - REMOVE_PORT:
   *
   * @else
   * @class ExecutionContextActionListener class
   * @brief ExecutionContextActionListener class
   *
   * This class is abstract base class for listener classes that
   * provides callbacks for various events in rtobject.
   *
   * @endif
   */
  class ExecutionContextActionListener
  {
  public:
    /*!
     * @if jp
     *
     * @brief PreComponentActionListenerType �𕶎���ɕϊ�
     *
     * PreComponentActionListenerType �𕶎���ɕϊ�����
     *
     * @param type �ϊ��Ώ� PreComponentActionListenerType
     *
     * @return ������ϊ�����
     *
     * @else
     *
     * @brief Convert PreComponentActionListenerType into the string.
     *
     * Convert PreComponentActionListenerType into the string.
     *
     * @param type The target PreComponentActionListenerType for transformation
     *
     * @return Trnasformation result of string representation
     *
     * @endif
     */
    static const char* toString(ExecutionContextActionListenerType type)
    {
      static const char* typeString[] =
        {
          "ATTACH_EC",
          "DETACH_ECT",
          "EC_ACTION_LISTENER_NUM"
        };
      if (type < EC_ACTION_LISTENER_NUM) { return typeString[type]; }
      return "";
    }

    /*!
     * @if jp
     * @brief �f�X�g���N�^
     * @else
     * @brief Destructor
     * @endif
     */
    virtual ~ExecutionContextActionListener();

    /*!
     * @if jp
     *
     * @brief ���z�R�[���o�b�N�֐�
     *
     * ExecutionContextActionListener �̃R�[���o�b�N�֐�
     *
     * @else
     *
     * @brief Virtual Callback function
     *
     * This is a the Callback function for ExecutionContextActionListener
     *
     * @endif
     */
    virtual void operator()(UniqueId ec_id) = 0;
  };



  //============================================================
  /*!
   * @if jp
   * @class PreComponentActionListenerHolder 
   * @brief PreComponentActionListener �z���_�N���X
   *
   * ������ PreComponentActionListener ��ێ����Ǘ�����N���X�B
   *
   * @else
   * @class PreComponentActionListenerHolder
   * @brief PreComponentActionListener holder class
   *
   * This class manages one ore more instances of
   * PreComponentActionListener class.
   *
   * @endif
   */
  class PreComponentActionListenerHolder
  {
    typedef std::pair<PreComponentActionListener*, bool> Entry;
    typedef coil::Guard<coil::Mutex> Guard;
  public:
    /*!
     * @if jp
     * @brief �R���X�g���N�^
     * @else
     * @brief Constructor
     * @endif
     */
    PreComponentActionListenerHolder();
    
    /*!
     * @if jp
     * @brief �f�X�g���N�^
     * @else
     * @brief Destructor
     * @endif
     */
    virtual ~PreComponentActionListenerHolder();
    
    /*!
     * @if jp
     *
     * @brief ���X�i�[�̒ǉ�
     *
     * ���X�i�[��ǉ�����B
     *
     * @param listener �ǉ����郊�X�i
     * @param autoclean true:�f�X�g���N�^�ō폜����,
     *                  false:�f�X�g���N�^�ō폜���Ȃ�
     * @else
     *
     * @brief Add the listener.
     *
     * This method adds the listener. 
     *
     * @param listener Added listener
     * @param autoclean true:The listener is deleted at the destructor.,
     *                  false:The listener is not deleted at the destructor. 
     * @endif
     */
    void addListener(PreComponentActionListener* listener, bool autoclean);
    
    /*!
     * @if jp
     *
     * @brief ���X�i�[�̍폜
     *
     * ���X�i���폜����B
     *
     * @param listener �폜���郊�X�i
     * @else
     *
     * @brief Remove the listener. 
     *
     * This method removes the listener. 
     *
     * @param listener Removed listener
     * @endif
     */
    void removeListener(PreComponentActionListener* listener);

    /*!
     * @if jp
     *
     * @brief ���X�i�[�֒ʒm����
     *
     * �o�^����Ă��郊�X�i�̃R�[���o�b�N���\�b�h���Ăяo���B
     *
     * @param info ConnectorInfo
     * @else
     *
     * @brief Notify listeners. 
     *
     * This calls the Callback method of the registered listener. 
     *
     * @param info ConnectorInfo
     * @endif
     */
    void notify(UniqueId ec_id);
      
  private:
    std::vector<Entry> m_listeners;
    coil::Mutex m_mutex;
  };


  /*!
   * @if jp
   * @class PostComponentActionListenerHolder
   * @brief PostComponentActionListener �z���_�N���X
   *
   * ������ PostComponentActionListener ��ێ����Ǘ�����N���X�B
   *
   * @else
   * @class PostComponentActionListenerHolder
   * @brief PostComponentActionListener holder class
   *
   * This class manages one ore more instances of
   * PostComponentActionListener class.
   *
   * @endif
   */
  class PostComponentActionListenerHolder
  {
    typedef std::pair<PostComponentActionListener*, bool> Entry;
    typedef coil::Guard<coil::Mutex> Guard;
  public:
    /*!
     * @if jp
     * @brief �R���X�g���N�^
     * @else
     * @brief Constructor
     * @endif
     */
    PostComponentActionListenerHolder();
    /*!
     * @if jp
     * @brief �f�X�g���N�^
     * @else
     * @brief Destructor
     * @endif
     */
    virtual ~PostComponentActionListenerHolder();
    
    /*!
     * @if jp
     *
     * @brief ���X�i�[�̒ǉ�
     *
     * ���X�i�[��ǉ�����B
     *
     * @param listener �ǉ����郊�X�i
     * @param autoclean true:�f�X�g���N�^�ō폜����,
     *                  false:�f�X�g���N�^�ō폜���Ȃ�
     * @else
     *
     * @brief Add the listener.
     *
     * This method adds the listener. 
     *
     * @param listener Added listener
     * @param autoclean true:The listener is deleted at the destructor.,
     *                  false:The listener is not deleted at the destructor. 
     * @endif
     */
    void addListener(PostComponentActionListener* listener, bool autoclean);
    
    /*!
     * @if jp
     *
     * @brief ���X�i�[�̍폜
     *
     * ���X�i���폜����B
     *
     * @param listener �폜���郊�X�i
     * @else
     *
     * @brief Remove the listener. 
     *
     * This method removes the listener. 
     *
     * @param listener Removed listener
     * @endif
     */
    void removeListener(PostComponentActionListener* listener);
    
    /*!
     * @if jp
     *
     * @brief ���X�i�[�֒ʒm����
     *
     * �o�^����Ă��郊�X�i�̃R�[���o�b�N���\�b�h���Ăяo���B
     *
     * @param info ConnectorInfo
     * @param cdrdata �f�[�^
     * @else
     *
     * @brief Notify listeners. 
     *
     * This calls the Callback method of the registered listener. 
     *
     * @param info ConnectorInfo
     * @param cdrdata Data
     * @endif
     */
    void notify(UniqueId ec_id, ReturnCode_t ret);
    
  private:
    std::vector<Entry> m_listeners;
    coil::Mutex m_mutex;
  };


  //============================================================
  /*!
   * @if jp
   * @class PortActionListenerHolder
   * @brief PortActionListener �z���_�N���X
   *
   * ������ PortActionListener ��ێ����Ǘ�����N���X�B
   *
   * @else
   * @class PortActionListenerHolder
   * @brief PortActionListener holder class
   *
   * This class manages one ore more instances of
   * PortActionListener class.
   *
   * @endif
   */
  class PortActionListenerHolder
  {
    typedef std::pair<PortActionListener*, bool> Entry;
    typedef coil::Guard<coil::Mutex> Guard;
  public:
    /*!
     * @if jp
     * @brief �R���X�g���N�^
     * @else
     * @brief Constructor
     * @endif
     */
    PortActionListenerHolder();
    /*!
     * @if jp
     * @brief �f�X�g���N�^
     * @else
     * @brief Destructor
     * @endif
     */
    virtual ~PortActionListenerHolder();
    
    /*!
     * @if jp
     *
     * @brief ���X�i�[�̒ǉ�
     *
     * ���X�i�[��ǉ�����B
     *
     * @param listener �ǉ����郊�X�i
     * @param autoclean true:�f�X�g���N�^�ō폜����,
     *                  false:�f�X�g���N�^�ō폜���Ȃ�
     * @else
     *
     * @brief Add the listener.
     *
     * This method adds the listener. 
     *
     * @param listener Added listener
     * @param autoclean true:The listener is deleted at the destructor.,
     *                  false:The listener is not deleted at the destructor. 
     * @endif
     */
    void addListener(PortActionListener* listener, bool autoclean);
    
    /*!
     * @if jp
     *
     * @brief ���X�i�[�̍폜
     *
     * ���X�i���폜����B
     *
     * @param listener �폜���郊�X�i
     * @else
     *
     * @brief Remove the listener. 
     *
     * This method removes the listener. 
     *
     * @param listener Removed listener
     * @endif
     */
    void removeListener(PortActionListener* listener);
    
    /*!
     * @if jp
     *
     * @brief ���X�i�[�֒ʒm����
     *
     * �o�^����Ă��郊�X�i�̃R�[���o�b�N���\�b�h���Ăяo���B
     *
     * @param info ConnectorInfo
     * @param cdrdata �f�[�^
     * @else
     *
     * @brief Notify listeners. 
     *
     * This calls the Callback method of the registered listener. 
     *
     * @param info ConnectorInfo
     * @param cdrdata Data
     * @endif
     */
    void notify(const RTC::PortProfile& pprofile);
    
  private:
    std::vector<Entry> m_listeners;
    coil::Mutex m_mutex;
  };

  /*!
   * @if jp
   * @class ExecutionContextActionListenerHolder
   * @brief ExecutionContextActionListener �z���_�N���X
   *
   * ������ ExecutionContextActionListener ��ێ����Ǘ�����N���X�B
   *
   * @else
   * @class ExecutionContextActionListenerHolder
   * @brief ExecutionContextActionListener holder class
   *
   * This class manages one ore more instances of
   * ExecutionContextActionListener class.
   *
   * @endif
   */
  class ExecutionContextActionListenerHolder
  {
    typedef std::pair<ExecutionContextActionListener*, bool> Entry;
    typedef coil::Guard<coil::Mutex> Guard;
  public:
    /*!
     * @if jp
     * @brief �R���X�g���N�^
     * @else
     * @brief Constructor
     * @endif
     */
    ExecutionContextActionListenerHolder();
    /*!
     * @if jp
     * @brief �f�X�g���N�^
     * @else
     * @brief Destructor
     * @endif
     */
    virtual ~ExecutionContextActionListenerHolder();
    
    /*!
     * @if jp
     *
     * @brief ���X�i�[�̒ǉ�
     *
     * ���X�i�[��ǉ�����B
     *
     * @param listener �ǉ����郊�X�i
     * @param autoclean true:�f�X�g���N�^�ō폜����,
     *                  false:�f�X�g���N�^�ō폜���Ȃ�
     * @else
     *
     * @brief Add the listener.
     *
     * This method adds the listener. 
     *
     * @param listener Added listener
     * @param autoclean true:The listener is deleted at the destructor.,
     *                  false:The listener is not deleted at the destructor. 
     * @endif
     */
    void addListener(ExecutionContextActionListener* listener, bool autoclean);
    
    /*!
     * @if jp
     *
     * @brief ���X�i�[�̍폜
     *
     * ���X�i���폜����B
     *
     * @param listener �폜���郊�X�i
     * @else
     *
     * @brief Remove the listener. 
     *
     * This method removes the listener. 
     *
     * @param listener Removed listener
     * @endif
     */
    void removeListener(ExecutionContextActionListener* listener);
    
    /*!
     * @if jp
     *
     * @brief ���X�i�[�֒ʒm����
     *
     * �o�^����Ă��郊�X�i�̃R�[���o�b�N���\�b�h���Ăяo���B
     *
     * @param info ConnectorInfo
     * @param cdrdata �f�[�^
     * @else
     *
     * @brief Notify listeners. 
     *
     * This calls the Callback method of the registered listener. 
     *
     * @param info ConnectorInfo
     * @param cdrdata Data
     * @endif
     */
    void notify(UniqueId ec_id);
    
  private:
    std::vector<Entry> m_listeners;
    coil::Mutex m_mutex;
  };


  /*!
   * @if jp
   * @class ComponentActionListeners
   * @brief ComponentActionListeners �N���X
   *
   *
   * @else
   * @class ComponentActionListeners
   * @brief ComponentActionListeners class
   *
   *
   * @endif
   */
  class ComponentActionListeners
  {
  public:
    /*!
     * @if jp
     * @brief PreComponentActionListenerType���X�i�z��
     * PreComponentActionListenerType���X�i���i�[
     * @else
     * @brief PreComponentActionListenerType listener array
     * The PreComponentActionListenerType listener is stored. 
     * @endif
     */
    PreComponentActionListenerHolder 
    preaction_[PRE_COMPONENT_ACTION_LISTENER_NUM];
    /*!
     * @if jp
     * @brief PostComponentActionType���X�i�z��
     * PostComponentActionType���X�i���i�[
     * @else
     * @brief PostComponentActionType listener array
     * The PostComponentActionType listener is stored.
     * @endif
     */
    PostComponentActionListenerHolder 
    postaction_[POST_COMPONENT_ACTION_LISTENER_NUM];
    /*!
     * @if jp
     * @brief PortActionType���X�i�z��
     * PortActionType���X�i���i�[
     * @else
     * @brief PortActionType listener array
     * The PortActionType listener is stored.
     * @endif
     */
    PortActionListenerHolder
    portaction_[PORT_ACTION_LISTENER_NUM];
    /*!
     * @if jp
     * @brief ExecutionContextActionType���X�i�z��
     * ExecutionContextActionType���X�i���i�[
     * @else
     * @brief ExecutionContextActionType listener array
     * The ExecutionContextActionType listener is stored.
     * @endif
     */
   ExecutionContextActionListenerHolder
    ecaction_[EC_ACTION_LISTENER_NUM];
  };


}; // namespace RTC

#endif // RTC_COMPONENTACTIONLISTENER_H
