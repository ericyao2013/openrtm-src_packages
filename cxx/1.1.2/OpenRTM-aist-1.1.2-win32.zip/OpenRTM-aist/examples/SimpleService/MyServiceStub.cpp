// -*- C++ -*-
/*!
 *
 * THIS FILE IS GENERATED AUTOMATICALLY!! DO NOT EDIT!!
 *
 * @file MyServiceStub.cpp 
 * @brief MyService client stub wrapper code
 * @date Thu Feb  8 10:21:08 2018 
 *
 */

#include "MyServiceStub.h"

#if   defined ORB_IS_TAO
#  include "MyServiceC.cpp"
#elif defined ORB_IS_OMNIORB
#  include "MyServiceSK.cc"
#  include "MyServiceDynSK.cc"
#elif defined ORB_IS_MICO
#  include "MyService.cc"
#elif defined ORB_IS_ORBIT2
#  include "MyService-cpp-stubs.cc"
#elif defined ORB_IS_RTORB
#  include "OpenRTM-aist-decls.h"
#  include "MyService-common.c"
#  include "MyService-stubs.c"
#else
#  error "NO ORB defined"
#endif

// end of MyServiceStub.cpp
