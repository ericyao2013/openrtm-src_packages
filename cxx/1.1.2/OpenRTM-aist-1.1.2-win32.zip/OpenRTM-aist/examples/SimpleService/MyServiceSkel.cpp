// -*- C++ -*-
/*!
 *
 * THIS FILE IS GENERATED AUTOMATICALLY!! DO NOT EDIT!!
 *
 * @file MyServiceSkel.cpp 
 * @brief MyService server skeleton wrapper
 * @date Thu Feb  8 10:21:08 2018 
 *
 */

#include "MyServiceSkel.h"

#if defined ORB_IS_TAO
#  include "MyServiceC.cpp"
#  include "MyServiceS.cpp"
#elif defined ORB_IS_OMNIORB
#  include "MyServiceSK.cc"
#  include "MyServiceDynSK.cc"
#elif defined ORB_IS_MICO
#  include "MyService.cc"
#  include "MyService_skel.cc"
#elif defined ORB_IS_ORBIT2
#  include "MyService-cpp-stubs.cc"
#  include "MyService-cpp-skels.cc"
#elif defined ORB_IS_RTORB
#  include "OpenRTM-aist-decls.h"
#  include "MyService-common.c"
#  include "MyService-stubs.c"
#  include "MyService-skels.c"
#  include "MyService-skelimpl.c"
#else
#  error "NO ORB defined"
#endif

// end of MyServiceSkel.cpp
