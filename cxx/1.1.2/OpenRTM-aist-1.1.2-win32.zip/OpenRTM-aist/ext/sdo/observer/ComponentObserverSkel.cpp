// -*- C++ -*-
/*!
 *
 * THIS FILE IS GENERATED AUTOMATICALLY!! DO NOT EDIT!!
 *
 * @file ComponentObserverSkel.cpp 
 * @brief ComponentObserver server skeleton wrapper
 * @date Thu Feb  8 10:20:54 2018 
 *
 */

#include "ComponentObserverSkel.h"

#if defined ORB_IS_TAO
#  include "idl/ComponentObserverC.cpp"
#  include "idl/ComponentObserverS.cpp"
#elif defined ORB_IS_OMNIORB
#  include "idl/ComponentObserverSK.cc"
#  include "idl/ComponentObserverDynSK.cc"
#elif defined ORB_IS_MICO
#  include "idl/ComponentObserver.cc"
#  include "idl/ComponentObserver_skel.cc"
#elif defined ORB_IS_ORBIT2
#  include "idl/ComponentObserver-cpp-stubs.cc"
#  include "idl/ComponentObserver-cpp-skels.cc"
#elif defined ORB_IS_RTORB
#  include "OpenRTM-aist-decls.h"
#  include "idl/ComponentObserver-common.c"
#  include "idl/ComponentObserver-stubs.c"
#  include "idl/ComponentObserver-skels.c"
#  include "idl/ComponentObserver-skelimpl.c"
#else
#  error "NO ORB defined"
#endif

// end of ComponentObserverSkel.cpp
