// -*- C++ -*-
/*!
 *
 * THIS FILE IS GENERATED AUTOMATICALLY!! DO NOT EDIT!!
 *
 * @file ComponentObserverStub.cpp 
 * @brief ComponentObserver client stub wrapper code
 * @date Thu Feb  8 10:20:54 2018 
 *
 */

#include "ComponentObserverStub.h"

#if   defined ORB_IS_TAO
#  include "idl/ComponentObserverC.cpp"
#elif defined ORB_IS_OMNIORB
#  include "idl/ComponentObserverSK.cc"
#  include "idl/ComponentObserverDynSK.cc"
#elif defined ORB_IS_MICO
#  include "idl/ComponentObserver.cc"
#elif defined ORB_IS_ORBIT2
#  include "idl/ComponentObserver-cpp-stubs.cc"
#elif defined ORB_IS_RTORB
#  include "OpenRTM-aist-decls.h"
#  include "idl/ComponentObserver-common.c"
#  include "idl/ComponentObserver-stubs.c"
#else
#  error "NO ORB defined"
#endif

// end of ComponentObserverStub.cpp
